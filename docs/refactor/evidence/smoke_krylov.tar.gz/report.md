# phase0-smoke-krylov

Termination: completed
Legacy gate: True

Compatibility smoke only. New-protocol correctness and score are null; C01–C06 pending.
OS sandbox: not_validated. Only reviewed builtins/mock executed.

Temperature/heat flux are element integrals; vdf axes: direction, element, nodal DOF.
The old gate checks temperature and transport residual; heat flux is recorded without a new gate.

This run is in an ignored directory. Export evidence before relying on its preservation.
