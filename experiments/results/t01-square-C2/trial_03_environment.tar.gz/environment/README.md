# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, preconditioned Krylov acceleration of the
transport sweep.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/kn_1e-3.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte run cases/F1_1e-3.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

    sweep()                 # exact transport solve, one direction at a time,
                            # in a topological order of the element graph
    compute_moments()       # T, qx, qy from the distribution

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.  Because the order is topological, the inflow is
*always* the value from the current pass, so the outgoing distribution
depends on the incoming moments alone.  One pass is therefore an affine map

    x  ->  F(x) = A x + b,      x = (T_s, qx_s, qy_s [, diffuse wall emission])

on 3600 numbers for the shipped cases, and the converged state is the
solution of the linear system `(I - A) x = b`.

## How the solve works

Repeating `x <- F(x)` -- source iteration, which is what the Fortran does --
is Richardson on that system.  Its error contracts by `rho(A)`, and `rho`
tends to 1 in two separate limits the cases cover:

* **optically thick** (`tau_R = 1e-3`): every spatial mode of the temperature
  is damped by only `1 - O((k tau_C)^2)`, so `rho = 1 - 3e-6` -- a million
  sweeps, against a cap of 30 000.  The stopping test measures the *step*
  between iterates rather than the error, so it reports `1.6e-5` while the
  answer is still 60% wrong;
* **hydrodynamic** (`tau_N << tau_R`): normal scattering conserves momentum,
  so the drift moment is damped by only `1 - tau_C/tau_R = 1 - 1e-3`, at
  every wavelength.

`Solver.run` instead solves `(I - A) x = b` with GMRES -- one sweep per
iteration, no change to the sweep, the discretisation or the fixed point --
preconditioned by a synthetic acceleration built from the *same* discrete
operator projected onto polynomials of low degree in `(cx, cy)`.  Degree 1 is
textbook diffusion synthetic acceleration; degree 2 is bought automatically
when `tau_C/tau_N` says the drift mode is the slow one, and the solve
escalates on its own if that guess was wrong.  Ten to thirty sweeps covers
every case in `cases/`, and the residual GMRES drives to zero is the true
residual of the transport system, not a preconditioned surrogate.

`Solver.source_iteration` is the Fortran outer loop, kept verbatim; `run`
falls back to it if a direction's sweep graph ever needs a cycle broken,
since a lagged inflow would make `F` non-affine.

## Cases

Two boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)

Sweeps to convergence, source iteration versus the accelerated solve:

    case          tau_R   tau_N   source iteration   accelerated
    F1_1e-3       1e-3      1e5   >30000 (60% off)            11
    F1_1e-2       1e-2      1e5    16830                      12
    F1_1e-1       1e-1      1e5      317                      13
    F1_1_1           1        1       33                      20
    F1_10_1e-2      10     1e-2     2706                      16
    F2_1e-3       1e-3      1e5   >30000 (78% off)            11
    F2_1e-2       1e-2      1e5   >30000                      14
    F2_1e-1       1e-1      1e5      643                      17
    F2_1_1           1        1       75                      26
    F2_10_1e-2      10     1e-2     2444                      16

`cases/kn_1e-3.yaml` is the reference cavity at the package defaults
(`DEG = 3`, a `20 x 40` angular mesh); the test suite builds from it.

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accelerate.py the moment fixed point and the linear solve around it
      loworder.py   the angular projection used as the preconditioner
      krylov.py     right-preconditioned GMRES
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `iteration.tol` is the Fortran stopping test and only `source_iteration`
  uses it.  `iteration.krylov_tol` is what `run` drives to zero, and it is a
  bound on the *error*, not on the step between iterates.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
