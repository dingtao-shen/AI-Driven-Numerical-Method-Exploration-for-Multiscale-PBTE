"""The angular projection that the preconditioner is built from.

These are sharp tests, not smoke tests.  The low-order operator is only
useful if it is the *shipped* transport operator seen through a truncated
angular basis, and two exact identities pin that down:

* the collision block must come out as the Callaway relaxation rates
  ``diag(0, 1/tau_R, 1/tau_R, 1/tau_C, ...)`` -- energy exactly conserved,
  momentum relaxed by resistive scattering only, everything above relaxed by
  the combined rate.  A sign slip or a misnormalised basis function breaks
  this immediately;
* a spatially uniform temperature with no heat flux must be annihilated
  exactly, element by element, wherever the element does not see an
  isothermal wall.  That one contraction involves the mass tensor, both
  stiffness tensors, both half-range face weights, the neighbour coupling and
  the diffuse-wall closure, so it catches essentially any indexing error.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.accelerate import MomentSystem
from pybte.constants import BC_NONTHERMALISING, BC_THERMALISING
from pybte.loworder import LowOrderAccelerator, angular_basis

from ..conftest import CASES


def _build(case_name, pdeg):
    case = Case.from_yaml(CASES / case_name)
    case.output.field = case.output.run_record = case.output.runtime_log = False
    s = Solver(case)
    ms = MomentSystem(s)
    acc = LowOrderAccelerator(
        s.ctx, s.integrals, s.mesh, case.flow.cv, case.flow.vg, case.tau_c,
        case.flow.tau_n, ms.wall_faces, ms.wall_tri, ms.wall_lfc, pdeg=pdeg)
    return case, s, ms, acc


@pytest.mark.parametrize("pdeg", [1, 2, 3])
def test_angular_basis_is_orthonormal(pdeg):
    case = Case.from_yaml(CASES / "F1_1e-2.yaml")
    s = Solver(case)
    p = angular_basis(s.ctx.cxv, s.ctx.cyv, s.ctx.domega, pdeg)
    gram = (s.ctx.domega * p) @ p.T
    assert np.abs(gram - np.eye(p.shape[0])).max() < 1e-12
    # the first three must be 1, cx, cy -- the solver's own moments read
    # straight off those coefficients
    assert np.allclose(p[0], p[0, 0])
    assert np.abs(p[1] / s.ctx.cxv - p[1, 0] / s.ctx.cxv[0]).max() < 1e-12
    assert np.abs(p[2] - p[2, 0] * s.ctx.cyv / s.ctx.cyv[0]).max() < 1e-12


@pytest.mark.parametrize("case_name", ["F1_10_1e-2.yaml", "F1_1e-2.yaml"])
def test_collision_block_is_the_callaway_rates(case_name):
    case, s, ms, acc = _build(case_name, 2)
    coll = np.eye(acc.nk) / case.tau_c - acc.scat
    want = np.full(acc.nk, 1.0 / case.tau_c)
    want[0] = 0.0                                   # energy is conserved
    want[1] = want[2] = 1.0 / case.flow.tau_r       # momentum: R channel only
    assert np.abs(coll - np.diag(want)).max() <= 1e-9 / case.tau_c


@pytest.mark.parametrize("case_name", ["F1_1e-2.yaml", "F2_1e-2.yaml"])
def test_uniform_temperature_is_annihilated(case_name):
    """No gradient, no flux, no wall to lose energy to -> no residual."""
    case, s, ms, acc = _build(case_name, 1)
    nd, nt, nk = acc.nd, acc.n_tris, acc.nk
    x = np.zeros((nt, nk, nd))
    x[:, 0, :] = 1.0 / acc.pmom[0, 0]                # phi = 1 everywhere
    out = (acc.matrix @ x.reshape(-1)).reshape(nt, nk, nd)

    # elements that touch an isothermal wall legitimately have a residual:
    # the wall is at a different temperature.  Everything else must be zero.
    bc = case.bc_codes()
    open_ = np.zeros(nt, dtype=bool)
    for i in range(nt):
        for il in range(3):
            b = int(s.mesh.face_bc[s.mesh.tri_faces[i, il]])
            if b >= 0 and bc[b] == BC_THERMALISING:
                open_[i] = True
    assert open_.any() and not open_.all()
    scale = np.abs(out).max()
    assert np.abs(out[~open_, 0]).max() <= 1e-11 * scale


def test_diffuse_wall_closure_is_wired_in():
    """Drop the wall term and the interior identity above must break.

    Guards against the reflecting-wall block being silently zero, which would
    still give a plausible-looking preconditioner and a much worse F2.
    """
    case, s, ms, acc = _build("F2_1e-2.yaml", 1)
    assert acc.wall_faces.size == 20
    assert np.abs(acc.gwall).max() > 0.0
    assert np.all(s.bcdata.bc_type[s.mesh.face_bc[acc.wall_faces]]
                  == BC_NONTHERMALISING)


@pytest.mark.parametrize("case_name,pdeg",
                         [("F1_1e-3.yaml", 1), ("F1_10_1e-2.yaml", 2)])
def test_preconditioner_contracts_the_error(case_name, pdeg):
    """``P^-1`` really is an approximate inverse of ``I - A``.

    ``|| (I - A) P^-1 v - v || / ||v||`` is the quantity GMRES converges at,
    so on the two stiff regimes it has to be well below 1 -- unpreconditioned
    it is ``1 - O(1e-6)`` on the first case.
    """
    case, s, ms, acc = _build(case_name, pdeg)
    pre = ms._preconditioner(pdeg)
    b = ms.apply(np.zeros(ms.n)).copy()
    rng = np.random.default_rng(7)
    v = rng.normal(size=ms.n) * np.abs(b).max()
    z = pre(v)
    w = z - ms.apply(z) + b
    assert np.linalg.norm(w - v) / np.linalg.norm(v) < 0.5
