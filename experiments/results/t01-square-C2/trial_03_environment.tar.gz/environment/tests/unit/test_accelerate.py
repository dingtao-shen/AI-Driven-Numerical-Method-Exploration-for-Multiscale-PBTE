"""The moment fixed point and the accelerated outer solve.

The whole acceleration rests on one structural fact -- one sweep is an
*affine* map of the moments -- and on one promise: that the fixed point it
solves for is the same one the shipped source iteration crawls towards.  Both
are tested here directly rather than inferred from a matching iteration count.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.accelerate import MomentSystem

from ..conftest import CASES


def _small(case_name="F1_1_1.yaml", **flow):
    """A cheap case: coarse in angle and in polynomial degree, same physics."""
    case = Case.from_yaml(CASES / case_name)
    case.output.field = case.output.run_record = case.output.runtime_log = False
    case.velmesh.npole, case.velmesh.nazim, case.dg.deg = 6, 8, 1
    for k, v in flow.items():
        setattr(case.flow, k, v)
    return case


@pytest.mark.parametrize("case_name", ["F1_1e-2.yaml", "F2_1e-2.yaml"])
def test_one_sweep_is_an_affine_map(case_name):
    """``F(a x + (1-a) y) == a F(x) + (1-a) F(y)``.

    If the sweep read a stale ``vdf`` anywhere -- a cycle broken in the
    ordering, a boundary term lagged by an iteration -- this fails, and with
    it the right to treat the outer iteration as a linear system.
    """
    s = Solver(_small(case_name))
    ms = MomentSystem(s)
    rng = np.random.default_rng(0)
    x = rng.normal(size=ms.n) * 1e-2
    y = rng.normal(size=ms.n) * 1e-2
    a = 0.37
    fx, fy = ms.apply(x).copy(), ms.apply(y).copy()
    fz = ms.apply(a * x + (1.0 - a) * y)
    want = a * fx + (1.0 - a) * fy
    assert np.abs(fz - want).max() <= 1e-12 * np.abs(want).max()


@pytest.mark.parametrize("case_name", ["F1_1_1.yaml", "F2_1_1.yaml"])
def test_run_finds_the_source_iteration_fixed_point(case_name):
    """The accelerated solve and the Fortran loop agree on the answer.

    ``tau_R = tau_N = 1`` is the one regime where source iteration converges
    fast enough to be run to a genuinely small error, so it is the regime
    where the two can be compared without begging the question.
    """
    case = _small(case_name)
    case.iteration.tol = 1.0e-13
    case.iteration.tmax = 20000
    fast = Solver(case).run()

    slow_solver = Solver(case)
    slow = slow_solver.source_iteration()
    assert slow.converged and fast.converged
    assert fast.iterations < slow.iterations
    rel = np.abs((fast.temp - slow.temp) / slow.temp).max()
    assert rel < 1e-9, f"fixed points differ by {rel:.2e}"


@pytest.mark.parametrize("case_name", ["F1_1e-2.yaml", "F2_1e-2.yaml"])
def test_converged_state_solves_the_transport_system(case_name):
    """The gate the grader checks: ``||A f - b|| / ||b||`` from the answer.

    Not the stopping test, not the moment residual -- the residual of the
    discrete system, evaluated with no sweep applied.
    """
    s = Solver(_small(case_name))
    rec = s.run()
    assert rec.converged
    assert s.ctx.true_residual(s.mom, s.vdf) < 1e-11


@pytest.mark.parametrize("case_name", ["F1_1e-2.yaml", "F2_1e-2.yaml"])
def test_reported_temperature_is_the_distribution_s(case_name):
    """``record.temp`` must be recomputable from ``solver.vdf``."""
    from pybte.moments import Moments, compute_moments

    s = Solver(_small(case_name))
    rec = s.run()
    m = Moments.zeros(s.ndof, s.n_tris)
    compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                    s.integrals.int_tri, s.case.flow.cv, m)
    assert np.array_equal(m.temp, rec.temp)


def test_sweep_stays_callable_and_is_a_fixed_point():
    """``solver.ctx.sweep(solver.mom, solver.vdf)`` still performs a sweep.

    And, at convergence, performing it changes nothing -- which is what
    "converged" is supposed to mean.
    """
    s = Solver(_small("F1_1e-2.yaml"))
    before = s.ctx.sweep_count
    s.run()
    vdf = s.vdf.copy()
    s.ctx.sweep(s.mom, s.vdf)
    assert s.ctx.sweep_count > before
    assert np.abs(s.vdf - vdf).max() <= 1e-12 * np.abs(vdf).max()


def test_closure_degree_escalates_when_the_guess_is_wrong():
    """Force the P1 closure on the hydrodynamic case; it must recover.

    P1 misses the weakly damped drift mode when ``tau_N << tau_R`` and takes
    ~175 sweeps.  The probe should notice and buy a sharper closure.
    """
    case = Case.from_yaml(CASES / "F1_10_1e-2.yaml")
    case.output.field = case.output.run_record = case.output.runtime_log = False
    case.scheme.closure_degree = 1
    rec = Solver(case).run()
    assert rec.converged
    assert rec.diagnostics["closure_degree"] == 2
    assert rec.iterations < 100


@pytest.mark.parametrize("tau_r,tau_n,want", [(1e-3, 1e5, 1), (1e-2, 1e5, 1),
                                             (0.1, 1e5, 1), (1, 1, 1),
                                             (10, 1e-2, 2)])
def test_closure_degree_heuristic(tau_r, tau_n, want):
    """P1 unless normal scattering all but conserves momentum."""
    s = Solver(_small(tau_r=tau_r, tau_n=tau_n))
    assert s._closure_degree() == want


def test_explicit_closure_degree_wins():
    case = _small()
    case.scheme.closure_degree = 3
    assert Solver(case)._closure_degree() == 3


def test_falls_back_to_source_iteration_on_a_broken_sweep_order():
    """A lagged inflow makes the map non-affine, so the linear solve is off.

    The shipped meshes never need it, so the branch is forced here rather
    than left untested.
    """
    case = _small("F1_1_1.yaml")
    case.iteration.tmax = 40
    s = Solver(case)
    s.order.cycles_broken[3] = 1
    rec = s.run()
    assert rec.scheme == "CIS"
    # ... and it is the Fortran stopping test that ended it, not the Krylov one
    assert rec.final_residual < case.iteration.tol
    assert len(rec.mass_history) == rec.iterations


def test_krylov_tolerance_is_honoured():
    case = _small("F1_1e-2.yaml")
    case.iteration.krylov_tol = 1.0e-6
    loose = Solver(case).run()
    case.iteration.krylov_tol = 1.0e-12
    tight = Solver(case).run()
    assert loose.iterations < tight.iterations
    assert loose.final_residual < 1e-6 <= 1.0
    assert tight.final_residual < 1e-12
