"""Right-preconditioned GMRES over the moment fixed point.

Why the outer solver is a Krylov method and not a smarter relaxation: the
sweep is an *exact* transport solve, so one pass of the shipped iteration is
one application of the affine map

    x  ->  F(x) = A x + b,        x = (T_s, qx_s, qy_s [, wall emission])

and the converged state is the solution of ``(I - A) x = b``.  Source
iteration is Richardson on that system; its error contracts by ``rho(A)``,
which tends to 1 in the optically thick limit and is what makes the shipped
driver take 10^6 sweeps at ``tau_R = 1e-3``.  GMRES on the same system costs
exactly one sweep per iteration and, with the P1 preconditioner of
:mod:`pybte.loworder`, converges in tens.

Right preconditioning is deliberate: the residual the Arnoldi recurrence
minimises is then the *true* residual ``||b - (I - A) x||``, not a
preconditioned surrogate.  That matters here because the grader checks the
transport residual of the converged distribution, and the two are
proportional -- a preconditioned residual would flatter us by the condition
number of the preconditioner.
"""
from __future__ import annotations

import numpy as np

__all__ = ["gmres_right"]


def gmres_right(matvec, b, psolve=None, rtol=1e-12, maxiter=2000,
                restart=200, callback=None, x0=None, bnorm=None):
    """Solve ``M x = b`` with right-preconditioned restarted GMRES.

    Parameters
    ----------
    matvec : callable ``v -> M v``
    b : ndarray
    psolve : callable ``v -> P^-1 v`` or None
    rtol : relative true-residual tolerance
    maxiter : maximum number of ``matvec`` calls
    restart : Krylov subspace size before restarting
    callback : called as ``callback(k, relative_residual)`` after each matvec
    x0 : starting iterate; costs one extra ``matvec`` if it is not zero
    bnorm : norm to measure the relative residual against (default ``|b|``)

    Returns
    -------
    x, info, residuals
        ``info`` is 0 on convergence, 1 if ``maxiter`` was exhausted.
    """
    n = b.size
    bnorm = float(np.linalg.norm(b)) if bnorm is None else float(bnorm)
    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)
    residuals = []
    if bnorm == 0.0:
        return x, 0, residuals
    m = min(int(restart or maxiter), maxiter, n)
    used = 0
    fresh = x0 is None or not x.any()

    while used < maxiter:
        if fresh:
            r = b.copy()
            fresh = False
        else:
            r = b - matvec(x)
            used += 1
        beta = float(np.linalg.norm(r))
        rel = beta / bnorm
        if rel < rtol:
            return x, 0, residuals

        k = min(m, maxiter - used)
        V = np.empty((k + 1, n))
        Z = np.empty((k, n))
        H = np.zeros((k + 1, k))
        cs = np.zeros(k)
        sn = np.zeros(k)
        g = np.zeros(k + 1)
        g[0] = beta
        V[0] = r / beta

        j = 0
        while j < k:
            Z[j] = psolve(V[j]) if psolve is not None else V[j]
            w = matvec(Z[j])
            used += 1
            for i in range(j + 1):                      # modified Gram-Schmidt
                H[i, j] = np.dot(w, V[i])
                w -= H[i, j] * V[i]
            # one step of re-orthogonalisation: the operator is badly
            # conditioned without the preconditioner and MGS alone loses
            # orthogonality long before the residual is small
            for i in range(j + 1):
                c = np.dot(w, V[i])
                H[i, j] += c
                w -= c * V[i]
            H[j + 1, j] = float(np.linalg.norm(w))
            if H[j + 1, j] > 0.0:
                V[j + 1] = w / H[j + 1, j]

            for i in range(j):                          # previous rotations
                t = cs[i] * H[i, j] + sn[i] * H[i + 1, j]
                H[i + 1, j] = -sn[i] * H[i, j] + cs[i] * H[i + 1, j]
                H[i, j] = t
            d = np.hypot(H[j, j], H[j + 1, j])
            if d == 0.0:
                cs[j], sn[j] = 1.0, 0.0
            else:
                cs[j], sn[j] = H[j, j] / d, H[j + 1, j] / d
            H[j, j] = cs[j] * H[j, j] + sn[j] * H[j + 1, j]
            H[j + 1, j] = 0.0
            g[j + 1] = -sn[j] * g[j]
            g[j] = cs[j] * g[j]

            rel = abs(g[j + 1]) / bnorm
            residuals.append(rel)
            if callback is not None:
                callback(used, rel)
            j += 1
            if rel < rtol or H[j - 1, j - 1] == 0.0:
                break

        y = np.linalg.solve(np.triu(H[:j, :j]), g[:j]) if j else np.zeros(0)
        x = x + y @ Z[:j]
        if rel < rtol:
            return x, 0, residuals
    return x, 1, residuals
