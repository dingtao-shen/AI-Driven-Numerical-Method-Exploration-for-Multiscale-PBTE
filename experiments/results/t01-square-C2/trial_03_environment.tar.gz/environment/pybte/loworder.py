"""Synthetic acceleration: a low-order angular model used as a preconditioner.

Source iteration converges at a rate set by how weakly the medium damps each
moment of the distribution.  Two separate mechanisms make that rate approach
1 on the shipped cases, and a usable preconditioner has to handle both:

* **optically thick, R-dominated** (``tau_R = 1e-3``): every *spatial* mode
  of the energy density is damped by only ``1 - O((k tau_C)^2)``, so all
  1200 mesh modes survive ~10^6 sweeps.  This is the classic case for
  diffusion synthetic acceleration.
* **hydrodynamic, N-dominated** (``tau_R = 10, tau_N = 0.01``): normal
  scattering conserves momentum, so the *drift* moment is damped by only
  ``1 - tau_C/tau_R = 1 - 1e-3`` at every wavelength.  Here the slow mode is
  the heat flux, not the temperature, and a diffusion-only correction does
  not see it.

Both are captured by the same construction: project the shipped discrete
transport operator onto polynomials of degree ``pdeg`` in ``(cx, cy)`` and
invert the projection exactly.  ``pdeg = 1`` is textbook DSA -- P1, i.e. the
(phi, J) drift-diffusion system.  Raising ``pdeg`` refines the angular
closure where P1 is not sharp enough; at ``pdeg = 1`` the model closes the
second angular moment as ``phi/3``, which is a 5% error at ``k tau_C ~ 0.3``
and, because the eigenvalue of interest is ``1 - 3 tau_C A2 / tau_N``, a
factor-40 error in the thing that actually matters when ``tau_C ~ tau_N``.

The projection is *exact*, not a re-derivation: the angular weights multiply
the shipped element tensors (``INT_NODFUNC_*``), the shipped upwind
half-range weights and the shipped diffuse-wall closure, so the low-order
operator inherits the solver's own discretisation and its own diffusion
limit.  The only approximation is the angular shape of the *correction* --
which is all a synthetic acceleration is ever allowed to approximate, since
the Krylov solver wrapped around it is what delivers the answer.

The algebra behind :meth:`LowOrderAccelerator.apply`.  With
``A = Mhat L^-1 Shat`` the moment-space iteration operator, solving
``(I - A) e = r`` is *equivalent* to

    (L - Shat Mhat) h = Shat r,        e = Mhat h + r

-- a transport solve for ``h`` with a frozen source.  Replacing that solve by
its angular projection is the whole method.  Note what is absent: no
relaxation factor, no lagging, no damping of the physics.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import PI, BC_PERIODIC

__all__ = ["LowOrderAccelerator", "angular_basis"]


def angular_basis(cxv, cyv, domega, pdeg: int, rtol: float = 1e-10):
    """Orthonormal polynomials in ``(cx, cy)`` up to total degree ``pdeg``.

    Orthonormal in the discrete angular inner product
    ``<u, v> = sum_d dOmega_d u_d v_d``, and built by modified Gram-Schmidt
    from the monomials ordered ``1, cx, cy, cx^2, ...``.  That order matters:
    it makes ``p_0 ~ 1``, ``p_1 ~ cx``, ``p_2 ~ cy``, so the three moments the
    solver actually carries read straight off the first three coefficients.

    Nearly dependent monomials (they appear once the quadrature can no
    longer resolve the degree) are dropped rather than inverted.
    """
    mono = []
    for k in range(pdeg + 1):
        for j in range(k + 1):
            mono.append((k - j, j))
    # 1, cx, cy first -- degree order already does that for pdeg >= 1
    raw = np.stack([cxv ** a * cyv ** b for a, b in mono])       # (K, ndir)

    basis = []
    for v in raw:
        v = v.copy()
        for p in basis:
            v -= (domega * p) @ v * p
        for p in basis:                       # reorthogonalise once
            v -= (domega * p) @ v * p
        nrm = np.sqrt((domega * v) @ v)
        if nrm > rtol * np.sqrt(np.abs(domega @ (raw[0] ** 2))):
            basis.append(v / nrm)
    return np.stack(basis)


def _factorise(mat):
    """Sparse LU of the low-order operator.

    The matrix has the sparsity of the element graph, which is symmetric even
    though the values are not, so a minimum-degree ordering on ``A + A^T``
    beats COLAMD by a factor of three in fill.  Partial pivoting is switched
    off with it: the operator is block diagonally dominant (upwind fluxes
    plus a positive collision term), and in any case this is a
    *preconditioner* -- a 1e-13 relative error in its solve costs nothing,
    while the factorisation is a third of the setup budget.  If SuperLU
    refuses the static pivots we fall back to the safe defaults.
    """
    try:
        return spla.splu(mat, permc_spec="MMD_AT_PLUS_A",
                         diag_pivot_thresh=0.0,
                         options=dict(SymmetricMode=True))
    except RuntimeError:                      # pragma: no cover - safety net
        return spla.splu(mat)


class LowOrderAccelerator:
    """Approximate inverse of ``I - A`` in moment space.

    Assembled once per solve; applying it is one sparse triangular solve.
    """

    def __init__(self, ctx, integrals, mesh, cv, vg, tau_c, tau_n,
                 wall_faces, wall_tri, wall_lfc, pdeg=1):
        self.cv = float(cv)
        self.pdeg = int(pdeg)
        self.nd = int(integrals.int_tri_tri.shape[0])
        self.n_tris = int(mesh.n_tris)
        self.wall_faces = wall_faces
        self.wall_tri = wall_tri
        self.wall_lfc = wall_lfc
        self._angular(ctx, mesh, float(vg), float(tau_c), float(tau_n))
        self._assemble(ctx, integrals, mesh, float(tau_c))

    # -- angular moment tables ---------------------------------------------
    def _angular(self, ctx, mesh, vg, tau_c, tau_n) -> None:
        cxv, cyv, dom = ctx.cxv, ctx.cyv, ctx.domega
        nt = self.n_tris

        p = angular_basis(cxv, cyv, dom, self.pdeg)             # (K, ndir)
        self.nk = nk = p.shape[0]
        pw = dom[None, :] * p                                    # (K, ndir)

        self.cxm = pw @ (cxv[:, None] * p.T)                     # <p_a, cx p_b>
        self.cym = pw @ (cyv[:, None] * p.T)

        # the Callaway source, written on (phi, qx, qy)
        f4 = 1.0 / (4.0 * PI)
        chit = np.stack([np.full(cxv.size, f4 / tau_c),
                         3.0 * cxv * f4 / (vg * vg * tau_n),
                         3.0 * cyv * f4 / (vg * vg * tau_n)])    # (3, ndir)
        self.dsrc = pw @ chit.T                                  # (K, 3)
        # (phi, qx, qy) of each basis function.  Because the Gram-Schmidt
        # started from 1, cx, cy, this is [[m0,0,..],[0,m1,0,..],[0,0,m1,..]]
        # -- the solver's three moments are the first three coefficients.
        self.pmom = np.stack([dom @ p.T, dom @ (cxv[:, None] * p.T),
                              dom @ (cyv[:, None] * p.T)])       # (3, K)
        self.scat = self.dsrc @ self.pmom                        # (K, K)

        # half-range edge weights: s = c . n_out for every (element, edge)
        nx = np.ascontiguousarray(mesh.tri_normal[:, :, 0]).reshape(-1)
        ny = np.ascontiguousarray(mesh.tri_normal[:, :, 1]).reshape(-1)
        s = cxv[:, None] * nx[None, :] + cyv[:, None] * ny[None, :]
        wp = 0.5 * (s + np.abs(s))
        wm = 0.5 * (s - np.abs(s))

        pab = (p[:, None, :] * p[None, :, :]).reshape(nk * nk, -1) * dom
        self.fp = (pab @ wp).reshape(nk, nk, nt, 3)
        self.fm = (pab @ wm).reshape(nk, nk, nt, 3)
        self.fm1 = (pw @ wm).reshape(nk, nt, 3)

        # a diffusely reflecting wall re-emits what hits it: the low-order
        # image of ``_kernels.wall_flux_kernel``
        self.gwall = np.zeros((nk, nt, 3))
        if self.wall_faces.size:
            num = (pw @ wp).reshape(nk, nt, 3)
            den = (dom @ wm).reshape(nt, 3)
            t, l = self.wall_tri, self.wall_lfc
            self.gwall[:, t, l] = num[:, t, l] / den[t, l]

    # -- assembly ----------------------------------------------------------
    def _assemble(self, ctx, integrals, mesh, tau_c) -> None:
        nd, nt, nk = self.nd, self.n_tris, self.nk
        nblk = nk * nd

        mass = np.ascontiguousarray(
            integrals.int_tri_tri.transpose(2, 0, 1))            # (nt, m, l)
        gx = np.ascontiguousarray(integrals.int_tri_tri_x)
        gy = np.ascontiguousarray(integrals.int_tri_tri_y)
        fcm = np.ascontiguousarray(integrals.int_tri_fc)         # (nt, 3, m, l)
        ttfc = np.ascontiguousarray(integrals.int_tri_tri_fc)

        # collision minus scattering: exactly the Callaway relaxation rates,
        # diag(0, 1/tau_R, 1/tau_R, 1/tau_C, ...) in the orthonormal basis
        coll = np.eye(nk) / tau_c - self.scat
        self_blk = (np.einsum("ab,iml->iambl", coll, mass)
                    - np.einsum("ab,iml->iambl", self.cxm, gx)
                    - np.einsum("ab,iml->iambl", self.cym, gy)
                    + np.einsum("abik,ikml->iambl", self.fp, fcm))
        if self.wall_faces.size:
            # ``subtract.at``, not ``self_blk[t] -=``: a corner element can
            # carry two reflecting faces and fancy-index assignment would
            # keep only the last of them
            t, l = self.wall_tri, self.wall_lfc
            np.subtract.at(self_blk, t,
                           np.einsum("ka,kml,kb->kambl", self.fm1[:, t, l].T,
                                     fcm[t, l], self.gwall[:, t, l].T))

        nb_blk = np.einsum("abik,ikml->ikambl", self.fm, ttfc)

        base = np.arange(nt) * nblk
        loc = np.arange(nblk)
        rr = base[:, None] + loc[None, :]
        rows = [np.repeat(rr, nblk, axis=1).ravel()]
        cols = [np.tile(rr, (1, nblk)).ravel()]
        vals = [self_blk.reshape(nt, nblk, nblk).ravel()]

        for il in range(3):
            faces = mesh.tri_faces[:, il]
            nbr = mesh.tri_neighbour[:, il].astype(np.int64).copy()
            bc = mesh.face_bc[faces]
            if ctx.bc_type.size:
                per = (bc >= 0) & (ctx.bc_type[np.maximum(bc, 0)] == BC_PERIODIC)
                if per.any():
                    nbr[per] = ctx.periodic_tri[faces[per]]
            keep = np.flatnonzero(nbr >= 0)
            if keep.size == 0:
                continue
            r = base[keep][:, None] + loc[None, :]
            c = nbr[keep][:, None] * nblk + loc[None, :]
            rows.append(np.repeat(r, nblk, axis=1).ravel())
            cols.append(np.tile(c, (1, nblk)).ravel())
            vals.append(nb_blk[keep, il].reshape(-1, nblk, nblk).ravel())

        n = nt * nblk
        mat = sp.csc_matrix((np.concatenate(vals),
                             (np.concatenate(rows), np.concatenate(cols))),
                            shape=(n, n))
        self.n = n
        self.matrix = mat
        self.lu = _factorise(mat)

        self._srcw = np.einsum("ab,iml->iambl", self.dsrc, mass).reshape(
            nt, nblk, 3 * nd)
        self._fcm_wall = (fcm[self.wall_tri, self.wall_lfc]
                          if self.wall_faces.size else None)

    # -- application -------------------------------------------------------
    def apply(self, rt, rqx, rqy, rw, out_t, out_qx, out_qy, out_w) -> None:
        """``out <- P^-1 r``.

        ``rt``/``rqx``/``rqy`` are ``(ndof, n_tris)`` as the solver stores
        moments; ``rw`` is ``(n_wall_faces, ndof)`` or ``None``.
        """
        nd, nt, nk, nblk = self.nd, self.n_tris, self.nk, self.nk * self.nd
        rho = np.ascontiguousarray(
            np.stack([self.cv * rt, rqx, rqy]).transpose(2, 0, 1)
        ).reshape(nt, 3 * nd)
        rhs = np.einsum("iab,ib->ia", self._srcw, rho)

        if rw is not None and self.wall_faces.size:
            t, l = self.wall_tri, self.wall_lfc
            add = self.fm1[:, t, l].T[:, :, None] * rw[:, None, :]
            np.add.at(rhs, t, add.reshape(-1, nblk))

        h = self.lu.solve(rhs.reshape(-1)).reshape(nt, nk, nd)

        mom = np.einsum("ab,ibl->ial", self.pmom, h)             # (nt, 3, nd)
        out_t[:] = mom[:, 0].T / self.cv + rt
        out_qx[:] = mom[:, 1].T + rqx
        out_qy[:] = mom[:, 2].T + rqy
        if rw is not None and self.wall_faces.size:
            t, l = self.wall_tri, self.wall_lfc
            coef = np.einsum("bk,kbl->kl", self.gwall[:, t, l], h[t])
            out_w[:] = np.einsum("kml,kl->km", self._fcm_wall, coef) + rw
