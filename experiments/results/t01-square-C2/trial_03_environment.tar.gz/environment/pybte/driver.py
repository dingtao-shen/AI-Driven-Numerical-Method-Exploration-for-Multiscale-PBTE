"""The outer iteration.

The Fortran original is Richardson iteration on the moment fixed point::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

and it is kept verbatim as :meth:`Solver.source_iteration`.  It is also
hopeless outside a narrow band of relaxation times: its error contracts by
``rho(A)``, which tends to 1 both in the optically thick limit (``tau_R``
small: every spatial mode of the temperature is barely damped) and in the
hydrodynamic limit (``tau_N << tau_R``: the drift moment is barely damped).
On the shipped ``tau_R = 1e-3`` cases that is ``rho = 1 - 3e-6`` -- a million
sweeps -- and the stopping test, which measures the *step* between iterates
rather than the error, declares victory long before then.

:meth:`Solver.run` therefore solves the same fixed point as what it is, a
linear system.  One sweep is one application of an affine map (see
:mod:`pybte.accelerate`), so ``(I - A) x = b`` is solved by GMRES
preconditioned with the angular projection of the very same discrete
operator (see :mod:`pybte.loworder`).  Same discretisation, same fixed point,
same sweep -- tens of sweeps instead of millions, and the answer is the
converged one rather than the one the step test was willing to accept.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .accelerate import MomentSystem
from .mesh import build_mesh
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        self.vdf = np.ascontiguousarray(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof))
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Solve the moment fixed point ``(I - A) x = b`` to convergence.

        Falls back to :meth:`source_iteration` when the map is not affine,
        which happens only if a direction's sweep graph had to have a cycle
        broken (``scheme.on_cycle='break'``) and the sweep therefore reads a
        stale ``vdf``.
        """
        if int(self.order.cycles_broken.sum()):
            return self.source_iteration(callback=callback,
                                         progress_every=progress_every)

        c = self.case
        guess = self._closure_degree()
        t0 = time.perf_counter()
        system = MomentSystem(self)

        def cb(nsweep, rel):
            if progress_every and nsweep % progress_every == 0:
                print(f"  sweep {nsweep:6d}  residual {rel:.6e}", flush=True)
            if callback is not None:
                callback(nsweep, rel, self)

        # two sweeps of the budget are not Krylov iterations: one builds the
        # constant term b = F(0), one lands on the fixed point at the end
        _, info, residuals = system.solve(
            rtol=c.iteration.krylov_tol, maxiter=max(1, c.iteration.tmax - 2),
            restart=c.iteration.restart, pdeg=guess, callback=cb)
        wall = time.perf_counter() - t0
        self.t_old[:] = self.mom.temp
        true_res = ([self.ctx.true_residual(self.mom, self.vdf)]
                    if c.iteration.true_residual else None)
        return self._record(system.sweeps, info == 0, residuals,
                            [self.mom.mass], true_res, wall, scheme="GMRES-SA",
                            extra={"closure_degree": system.pdeg_used,
                                   "closure_degree_guess": guess,
                                   "krylov_tol": c.iteration.krylov_tol})

    def _closure_degree(self) -> int:
        """Angular degree of the synthetic-acceleration closure.

        P1 is textbook DSA and is all the R-dominated regimes need: normal
        scattering is then so weak that the drift moment is damped at
        ``1/tau_R`` anyway.  Once ``tau_C/tau_N`` approaches 1 the drift
        moment is nearly conserved, the eigenvalue that matters is
        ``1 - 3 tau_C A2 / tau_N``, and P1's 5%-accurate closure of ``A2``
        becomes a factor-40 error in it -- so buy a sharper closure there.
        The extra degree costs one sparse factorisation of a matrix twice as
        wide, and pays for itself an order of magnitude over where it is
        needed: 175 sweeps -> 16 on ``F1_10_1e-2``.  Where it is not, it is
        pure loss, so the threshold sits at ``tau_C/tau_N > 0.9``; the
        Krylov solve escalates on its own if that guess turns out wrong.
        """
        c = self.case
        if c.scheme.closure_degree:
            return int(c.scheme.closure_degree)
        return 2 if c.tau_c / c.flow.tau_n > 0.9 else 1

    def source_iteration(self, callback=None, progress_every: int = 0) -> RunRecord:
        """The Fortran outer loop: ``Calculate_Residual_T < tol``, verbatim."""
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
