"""The moment fixed point, and the accelerated solve built on it.

One pass of the shipped outer iteration is

    refresh the diffuse-wall emission from the distribution
    sweep                       (an *exact* transport solve for the source)
    recompute the moments

The sweep visits elements in a topological order of the element graph, so an
element's inflow is always read from a neighbour already updated in the same
pass.  That is what makes the pass exact -- and it also means the outgoing
distribution depends on the *incoming moments alone*, not on the previous
distribution.  So the pass is an affine map

    x  ->  F(x) = A x + b,        x = (T_s, qx_s, qy_s [, wall emission])

on a space of ``3 * NDOF * N_TRIS`` (+ wall) numbers -- 3600 for the shipped
cases -- and the converged state is the solution of ``(I - A) x = b``, one
linear system.  ``b = F(0)`` costs one sweep; every ``(I - A) v`` costs one
more.

:class:`MomentSystem` is that map.  :meth:`MomentSystem.solve` hands it to
GMRES with the P1 preconditioner of :mod:`pybte.loworder`.

Two properties are load-bearing and are checked by the test suite:

* ``F`` really is affine -- the sweep is not allowed to read stale ``vdf``.
  It does not, as long as the sweep ordering is acyclic; if a direction's
  graph had a cycle (``scheme.on_cycle='break'``) the broken edges would lag
  the previous iterate and the map would no longer be affine.  The solver
  detects that and falls back to plain source iteration.
* the fixed point is *the same* fixed point the shipped source iteration
  converges to, because it is the same map.  Nothing is relaxed, damped or
  re-discretised.
"""
from __future__ import annotations

import numpy as np

from ._kernels import wall_flux_kernel
from .constants import BC_NONTHERMALISING
from .krylov import gmres_right
from .moments import compute_moments

__all__ = ["MomentSystem"]


class MomentSystem:
    """The affine map ``F`` of one outer iteration, and its linear solve."""

    def __init__(self, solver):
        self.s = solver
        mesh, bd = solver.mesh, solver.bcdata
        self.nd = int(solver.ndof)
        self.nt = int(solver.n_tris)

        fb = mesh.face_bc
        if bd.has_nonthermalising:
            faces = np.flatnonzero(
                (fb >= 0) & (bd.bc_type[np.maximum(fb, 0)] == BC_NONTHERMALISING))
        else:
            faces = np.zeros(0, dtype=np.int64)
        self.wall_faces = faces.astype(np.int64)
        pairs = [mesh.adjacent(int(f)) for f in self.wall_faces]
        self.wall_tri = np.array([p[0] for p in pairs], dtype=np.int64)
        self.wall_lfc = np.array([p[1] for p in pairs], dtype=np.int64)

        k = self.nd * self.nt
        self.nw = int(self.wall_faces.size)
        self.n = 3 * k + self.nw * self.nd
        self._k = k

        # arrays ``wall_flux_kernel`` wants, converted once instead of per call
        self._wf_args = None
        if self.nw:
            self._wf_args = (
                np.ascontiguousarray(solver.integrals.int_tri_fc),
                np.ascontiguousarray(mesh.tri_normal[:, :, 0]),
                np.ascontiguousarray(mesh.tri_normal[:, :, 1]),
                mesh.face_bc.astype(np.int32),
                mesh.face_tri.astype(np.int32),
                mesh.face_lfc.astype(np.int32),
            )
        self.sweeps = 0
        self.pdeg_used = 0
        self.accel = None

    # -- packing -----------------------------------------------------------
    def scatter(self, x) -> None:
        """Load ``x`` into the solver's moment and wall-emission storage."""
        s, k, nd, nt = self.s, self._k, self.nd, self.nt
        s.mom.ts[:] = x[:k].reshape(nd, nt)
        s.mom.qxs[:] = x[k:2 * k].reshape(nd, nt)
        s.mom.qys[:] = x[2 * k:3 * k].reshape(nd, nt)
        if self.nw:
            s.bcdata.flux_wall[self.wall_faces] = x[3 * k:].reshape(self.nw, nd)

    def gather(self, out=None) -> np.ndarray:
        s, k, nd, nt = self.s, self._k, self.nd, self.nt
        out = np.empty(self.n) if out is None else out
        out[:k] = s.mom.ts.ravel()
        out[k:2 * k] = s.mom.qxs.ravel()
        out[2 * k:3 * k] = s.mom.qys.ravel()
        if self.nw:
            out[3 * k:] = s.bcdata.flux_wall[self.wall_faces].ravel()
        return out

    def _refresh_wall(self) -> None:
        s = self.s
        wall_flux_kernel(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                         *self._wf_args, s.bcdata.bc_type, s.bcdata.flux_wall)

    # -- the map -----------------------------------------------------------
    def apply(self, x, out=None) -> np.ndarray:
        """``F(x)``: one sweep from the moments in ``x``, then remoment."""
        s = self.s
        self.scatter(x)
        s.ctx.sweep(s.mom, s.vdf)
        self.sweeps += 1
        if s.ctx.mode == "onthefly":
            s.factorisation_count += s.ndir * s.n_tris
        compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                        s.integrals.int_tri, s.case.flow.cv, s.mom)
        if self.nw:
            self._refresh_wall()
        return self.gather(out)

    # -- the linear solve --------------------------------------------------
    #: matvecs to spend on a closure before deciding it is the wrong one
    PROBE = 40
    #: the residual drop that counts as "this preconditioner is working"
    PROBE_DROP = 1.0e-3
    #: highest angular degree the escalation will buy
    MAX_PDEG = 3

    def solve(self, rtol=1e-12, maxiter=2000, restart=200, callback=None,
              pdeg=1):
        """Solve ``(I - A) x = b`` and leave the solver at that state.

        Returns ``(x, info, residuals)``.  On return ``solver.vdf`` is the
        distribution produced by a sweep from ``x`` and ``solver.mom`` its
        moments, so the pair jointly satisfies the discrete transport system.

        ``pdeg`` is only the opening guess at the angular closure the
        preconditioner needs.  If the first :attr:`PROBE` matvecs have not
        moved the residual by :attr:`PROBE_DROP`, the closure is refined and
        the solve continues from where it got to -- so a relaxation-time pair
        that the heuristic in ``Solver._closure_degree`` misreads costs a few
        dozen sweeps, not a few hundred.
        """
        zero = np.zeros(self.n)
        b = self.apply(zero).copy()
        bnorm = float(np.linalg.norm(b))

        def matvec(v):
            return v - self.apply(v) + b

        x = None
        residuals: list[float] = []
        info, pre, built = 1, None, None
        while True:
            budget = maxiter - (self.sweeps - 1)
            if budget <= 0:
                break
            if pdeg != built:
                pre, built = self._preconditioner(pdeg), pdeg
                self.pdeg_used = pdeg if pre is not None else 0
            probing = pre is not None and pdeg < self.MAX_PDEG and budget > self.PROBE
            # unpreconditioned, the spectrum is clustered at 1 and a short
            # Arnoldi basis stalls; give the fallback room to breathe
            window = restart if pre is not None else max(restart, 1500)
            x, info, res = gmres_right(
                matvec, b, pre, rtol=rtol,
                maxiter=min(self.PROBE, budget) if probing else budget,
                restart=window, callback=callback, x0=x, bnorm=bnorm)
            residuals.extend(res)
            if info == 0 or not probing:
                break
            if not res or res[-1] > self.PROBE_DROP:
                pdeg += 1

        # land on the fixed point: one last sweep so that vdf and mom are
        # mutually consistent and solve the transport system together
        self.apply(x if x is not None else zero)
        return self.gather(), info, residuals

    def _preconditioner(self, pdeg=1):
        """``P^-1`` for a closure of degree ``pdeg``, or None if it will not
        build -- GMRES still converges without one, just slowly."""
        from .loworder import LowOrderAccelerator

        s = self.s
        try:
            self.accel = LowOrderAccelerator(
                s.ctx, s.integrals, s.mesh, s.case.flow.cv, s.case.flow.vg,
                s.case.tau_c, s.case.flow.tau_n, self.wall_faces,
                self.wall_tri, self.wall_lfc, pdeg=pdeg)
        except (RuntimeError, ValueError, np.linalg.LinAlgError):
            return None                         # pragma: no cover - safety net
        accel = self.accel
        k, nd, nt, nw = self._k, self.nd, self.nt, self.nw
        out = np.empty(self.n)
        ot = out[:k].reshape(nd, nt)
        oqx = out[k:2 * k].reshape(nd, nt)
        oqy = out[2 * k:3 * k].reshape(nd, nt)
        ow = out[3 * k:].reshape(nw, nd) if nw else None

        def psolve(v):
            rw = v[3 * k:].reshape(nw, nd) if nw else None
            accel.apply(v[:k].reshape(nd, nt), v[k:2 * k].reshape(nd, nt),
                        v[2 * k:3 * k].reshape(nd, nt), rw, ot, oqx, oqy, ow)
            return out.copy()

        return psolve
