"""The outer iteration.

The Fortran's loop is::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

which is Richardson iteration on the linear system the sweep and the moment
update define between them (see :mod:`pybte.accel`).  It is kept, verbatim, as
:meth:`Solver.step` and :meth:`Solver._run_source_iteration`, and it is still
what drives the solve when ``scheme.accelerate`` is off.

By default the same system is solved instead by GMRES preconditioned with a
coarse-angle synthetic-acceleration operator.  Same sweep, same discrete
operator, same fixed point -- but the iteration count stops depending on
``tau_R`` and ``tau_N``, and the answer is the solution of the discrete
system rather than wherever a slowly converging sequence happened to be when
its *step* fell below ``tol``.  On the shipped cases that is the difference
between 15 sweeps and 30 000, and on the stiffest between a converged answer
and one that is 60% wrong.

Also added around the loop: an explicit restart contract, an optional true
residual, and a :class:`~pybte.io_output.RunRecord` complete enough that a
verifier never has to parse stdout.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .accel import LowOrderOperator, ReducedLayout, gmres
from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .constants import BC_NONTHERMALISING
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        # ``frombuffer`` is read-only and the transpose below is a view of it,
        # so ``ascontiguousarray`` would hand the sweep an array it cannot
        # write to; copy explicitly.
        self.vdf = np.array(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof),
            dtype=np.float64, order="C")
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Solve the case to the fixed point of the discrete transport system.

        ``scheme.accelerate`` (the default) picks the preconditioned Krylov
        path; turn it off for the Fortran's plain source iteration.  Both
        solve the same system and converge to the same state.
        """
        if self.case.scheme.accelerate:
            return self._run_krylov(callback, progress_every)
        return self._run_source_iteration(callback, progress_every)

    # -- the reduced system -------------------------------------------------
    def _wall_faces(self) -> np.ndarray:
        """Faces carrying a diffusely reflecting (type-2) wall."""
        if not self.bcdata.has_nonthermalising:
            return np.zeros(0, dtype=np.int64)
        bc = self.mesh.face_bc
        typ = np.where(bc >= 0, self.bcdata.bc_type[np.maximum(bc, 0)], -1)
        return np.flatnonzero(typ == BC_NONTHERMALISING).astype(np.int64)

    def _ncoarse(self) -> int:
        """How many ordinates the low-order operator needs.

        ``ncoarse`` equally spaced directions carry the angular harmonics up
        to order ``(ncoarse - 1) // 2``: three give P1, five give a complete
        P2.  Which one is enough is set by how many collisions a phonon's
        momentum survives, ``h = tau_R / tau_C = 1 + tau_R / tau_N``.

        At ``h ~ 1`` resistive scattering destroys momentum every collision,
        the slow modes are the diffusive ones, and P1 -- classical DSA -- is
        exactly the right low-order model and the cheapest to factorise.  As
        ``h`` grows the medium turns hydrodynamic: momentum is carried across
        many collisions, the slow modes become the viscous ones, and P1 stops
        seeing them.  Sweeping ``(tau_R, tau_N)`` over four decades each on
        the shipped mesh, three ordinates cost 14-29 iterations up to
        ``h ~ 2``, 51-79 at ``h ~ 11`` and 207-303 at ``h >= 100``, while five
        stay at 15-22 throughout; four sit in between and factorise faster
        than five.  Hence the thresholds below.
        """
        if self.case.scheme.ncoarse:
            return int(self.case.scheme.ncoarse)
        h = 1.0 + self.case.flow.tau_r / self.case.flow.tau_n
        if h < 3.0:
            return 3
        return 4 if h < 60.0 else 5

    def _run_krylov(self, callback=None, progress_every: int = 0) -> RunRecord:
        """GMRES on ``(I - K) x = c``, preconditioned by the low-order model.

        ``x`` is the scattering source (moments plus diffuse-wall emission);
        one application of ``K`` is one transport sweep followed by the moment
        update, i.e. exactly one iteration of the Fortran's loop.  Every sweep
        the run performs goes through :meth:`SweepContext.sweep` and is
        counted against ``iteration.tmax``.
        """
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        lay = ReducedLayout(self.ndof, self.n_tris, self._wall_faces())

        t0 = time.perf_counter()
        sweeps0 = self.ctx.sweep_count
        low, precond = self._build_preconditioner(lay)

        budget = [max(1, int(tmax))]
        int_tri = self.integrals.int_tri

        def apply_map(x):
            """One outer iteration as a map on the reduced unknown."""
            lay.scatter(x, self.mom, self.bcdata.flux_wall)
            self.ctx.sweep(self.mom, self.vdf)
            budget[0] -= 1
            if self.ctx.mode == "onthefly":
                self.factorisation_count += self.ndir * self.n_tris
            compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                            int_tri, c.flow.cv, self.mom)
            if lay.nwall:
                self.bcdata.update_wall_flux(
                    self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                    self.integrals.int_tri_fc, self.mesh)
            return lay.gather(self.mom, self.bcdata.flux_wall,
                              np.empty(lay.size))

        x = None
        if self.restart_info["enabled"]:
            # a restart file is a state, not a source: turn it into one, so
            # that it is a starting iterate rather than something the first
            # sweep quietly discards
            compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                            int_tri, c.flow.cv, self.mom)
            if lay.nwall:
                self.bcdata.update_wall_flux(
                    self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                    self.integrals.int_tri_fc, self.mesh)
            x = lay.gather(self.mom, self.bcdata.flux_wall, np.empty(lay.size))

        # x_{k+1} = K x_k + rhs, so rhs is one sweep from a zero source
        rhs = apply_map(np.zeros(lay.size))

        residuals: list[float] = []
        masses: list[float] = []

        def on_iter(res):
            residuals.append(res)
            masses.append(float("nan"))
            n = len(residuals)
            if progress_every and n % progress_every == 0:
                print(f"  krylov {n:6d}  residual {res:.6e}", flush=True)
            if callback is not None:
                callback(n, res, self)

        # three orders tighter than the case asks for, because what ``tol``
        # measures is a step and what the answer needs is an error
        rtol = max(1e-14, min(1e-11, tol * 1e-3))
        step = float("nan")
        krylov_res = float("nan")
        restarts = 0
        while budget[0] > 1:
            x, krylov_res, _ = gmres(
                lambda v: v - (apply_map(v) - rhs), rhs, precond, rtol,
                maxiter=min(budget[0] - 1, 400), x0=x, callback=on_iter)
            # The closing sweep.  It is what makes ``vdf`` the exact transport
            # solve for the converged source and the moments its own moments,
            # so that the state handed back is consistent whichever of the two
            # a verifier reads.  Its step is also the honest stopping test:
            # the Fortran's ``Calculate_Residual_T``, evaluated at the answer.
            t_src = np.einsum("li,li->i", lay.views(x)[0], int_tri)
            x = apply_map(x)
            step = residual_iterate(self.mom.temp, t_src)
            residuals.append(step)
            masses.append(self.mom.mass)
            if (step < tol and krylov_res <= rtol * 10.0) or budget[0] <= 1:
                break
            restarts += 1
            if restarts >= 50:                       # pragma: no cover
                break
        converged = bool(step < tol)

        self.t_old[:] = self.mom.temp
        wall = time.perf_counter() - t0
        true_res = None
        if c.iteration.true_residual:
            true_res = [self.ctx.true_residual(self.mom, self.vdf)]
        rec = self._record(self.ctx.sweep_count - sweeps0, converged, residuals,
                           masses, true_res, wall, scheme="KRYLOV-SA")
        rec.diagnostics.update(
            ncoarse=(low.nc if low is not None else 0),
            low_order_unknowns=(low.n if low is not None else 0),
            krylov_residual=float(krylov_res),
            krylov_restarts=restarts,
            residual_kind=("preconditioned Krylov residual per iteration, "
                           "then Calculate_Residual_T across the closing sweep"),
        )
        if not converged:
            rec = self._finish_by_source_iteration(rec, residuals, masses, t0,
                                                   sweeps0)
        return rec

    def _build_preconditioner(self, lay):
        """The low-order operator, or the identity if it cannot be built."""
        try:
            low = LowOrderOperator(self.ctx, self.mesh, lay,
                                   ncoarse=self._ncoarse())
        except Exception as exc:                       # pragma: no cover
            warnings.warn(f"low-order acceleration unavailable ({exc}); "
                          "falling back to unpreconditioned GMRES")
            return None, lambda r, out: np.copyto(out, r) or out
        return low, low.solve

    def _finish_by_source_iteration(self, rec, residuals, masses, t0, sweeps0=0):
        """Last resort: spend whatever sweeps are left the Fortran's way.

        Never reached on the shipped cases.  It exists so that a failure of
        the Krylov path can only ever cost time, never correctness.
        """
        c = self.case
        step = self.ctx.sweep_count - sweeps0
        while step < c.iteration.tmax:
            self.step()
            step += 1
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if res < c.iteration.tol:
                rec.converged = True
                break
        rec.iterations = self.ctx.sweep_count - sweeps0
        rec.sweep_count = self.ctx.sweep_count
        rec.residual_history = np.asarray(residuals)
        rec.mass_history = np.asarray(masses)
        rec.temp, rec.qx, rec.qy = (self.mom.temp.copy(), self.mom.qx.copy(),
                                    self.mom.qy.copy())
        rec.temp_dofs, rec.qx_dofs, rec.qy_dofs = (
            self.mom.ts.copy(), self.mom.qxs.copy(), self.mom.qys.copy())
        rec.wall_clock = time.perf_counter() - t0
        return rec

    def _run_source_iteration(self, callback=None, progress_every: int = 0):
        """Source iteration: ``Calculate_Residual_T < tol``, as the Fortran."""
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
