"""Acceleration of the source iteration.

The outer iteration in :mod:`pybte.driver` is a fixed-point map on a small
vector: everything the transport sweep needs to know about the previous
iterate is the scattering source, i.e. the moments ``(T_s, qx_s, qy_s)`` per
element DOF plus, when a diffusely reflecting wall is present, that wall's
emission.  Writing that vector as ``x``,

    x_{k+1} = K x_k + c,

with ``K x`` = "one sweep from the moments ``x``, then take moments of the
result" and ``c`` the same thing started from zero.  ``K`` is linear -- the
sweep is an exact solve for each direction and never reads the incoming
``vdf`` -- so the converged state is the solution of

    (I - K) x = c,

and source iteration is nothing but Richardson iteration on that system.  Its
rate is the spectral radius of ``K``, which tends to 1 in both stiff limits:
optically thick (``tau_R -> 0``, energy diffuses) and hydrodynamic
(``tau_N << tau_R``, momentum survives many collisions).  That is the entire
reason the shipped solver needs tens of thousands of sweeps, or never gets
there at all.

Two things fix it, and both leave the discrete system untouched:

* solve ``(I - K) x = c`` with GMRES instead of Richardson -- same fixed
  point, and the Krylov space handles a clustered spectrum far better than a
  power iteration;
* precondition with a *low-order* transport model -- the same DG spatial
  discretisation, the same collision operator, the same boundary treatment,
  but a handful of discrete ordinates instead of ``NPOLE * NAZIM``.  The
  coarse angular set is chosen to reproduce ``int dOmega``, ``int c dOmega``
  and ``int c c dOmega`` exactly, so the low-order model has the *same*
  diffusion limit and the *same* momentum-relaxation rate as the transport
  problem it accelerates.  That is the classical synthetic-acceleration
  argument (Alcouffe's DSA, in its S_N-consistent form); here the low-order
  system is small enough -- a few thousand unknowns, sparse -- to be LU
  factorised once and applied directly.

The preconditioner only has to be *effective*; it cannot move the answer,
because it never touches the operator or the right-hand side.  What pins the
answer is the residual of ``(I - K) x - c``, which :meth:`Solver.run` drives
to round-off.
"""
from __future__ import annotations

import numpy as np

from .constants import BC_PERIODIC, PI

__all__ = ["ReducedLayout", "LowOrderOperator", "coarse_directions",
           "best_phase", "gmres"]


# ---------------------------------------------------------------------------
def coarse_directions(ncoarse: int, vg: float, phase: float):
    """``(cx, cy, w)``: an in-plane ordinate set with exact P1 moments.

    ``ncoarse`` directions equally spaced in the transport plane, one speed,
    equal weights.  For any ``ncoarse >= 3`` this reproduces

        sum w = 4 pi,   sum w c = 0,   sum w c_i c_j = (4 pi / 3) vg^2 d_ij,

    the last one fixing the speed at ``sqrt(2/3) vg``.  Those are exactly the
    moments that decide the diffusion limit (``kappa = Cv vg^2 tau_R / 3``)
    and the momentum relaxation rate (``1 / tau_R``), so the low-order model
    built on this set is asymptotically consistent with the fine one in both
    stiff limits.

    ``phase`` rotates the set; :func:`best_phase` picks it.
    """
    k = np.arange(ncoarse)
    psi = phase + 2.0 * PI * k / ncoarse
    w = np.full(ncoarse, 4.0 * PI / ncoarse)
    speed = np.sqrt(2.0 / 3.0) * vg
    return speed * np.cos(psi), speed * np.sin(psi), w


def best_phase(nx, ny, ncoarse: int, ntry: int = 96) -> float:
    """Rotate the coarse ordinate set away from the mesh's face planes.

    A direction lying *in* a face's plane has zero upwind weight there, so
    that face contributes nothing to the low-order operator and the coupling
    across it is simply missing -- on a structured triangulation, where whole
    families of faces share a normal, that can cost the preconditioner a
    large part of its job.  Three ordinates on a right-triangle mesh hit this
    exactly: the natural 30-degree offset puts one of them along ``-y``,
    which is parallel to every vertical face.

    Scan one period and take the rotation that maximises the smallest
    ``|c . n|`` over all (ordinate, face) pairs.
    """
    ang = np.arctan2(ny.ravel(), nx.ravel())
    trial = np.linspace(0.0, 2.0 * PI / ncoarse, ntry, endpoint=False)
    psi = trial[:, None] + 2.0 * PI * np.arange(ncoarse)[None, :] / ncoarse
    worst = np.abs(np.cos(psi[:, :, None] - ang[None, None, :])).min(axis=(1, 2))
    return float(trial[int(np.argmax(worst))])


# ---------------------------------------------------------------------------
class ReducedLayout:
    """Index bookkeeping for the reduced unknown ``x``.

    ``x`` is ``[T_s, qx_s, qy_s]`` -- each ``(ndof, n_tris)`` in C order --
    followed by the diffuse-wall emission on the type-2 faces, ``(nwall,
    ndof)``.  Everything else the sweep needs is iteration-invariant.
    """

    def __init__(self, ndof: int, n_tris: int, wall_faces: np.ndarray):
        self.ndof = ndof
        self.n_tris = n_tris
        self.wall_faces = wall_faces
        self.nblk = ndof * n_tris
        self.nmom = 3 * self.nblk
        self.nwall = int(wall_faces.size)
        self.size = self.nmom + self.nwall * ndof

    def views(self, x: np.ndarray):
        """``(ts, qxs, qys, fw)`` as views into ``x`` -- no copy."""
        n = self.nblk
        nd = self.ndof
        return (x[0:n].reshape(nd, self.n_tris),
                x[n:2 * n].reshape(nd, self.n_tris),
                x[2 * n:3 * n].reshape(nd, self.n_tris),
                x[self.nmom:].reshape(self.nwall, nd))

    def gather(self, mom, flux_wall, out: np.ndarray) -> np.ndarray:
        ts, qxs, qys, fw = self.views(out)
        ts[:] = mom.ts
        qxs[:] = mom.qxs
        qys[:] = mom.qys
        if self.nwall:
            fw[:] = flux_wall[self.wall_faces]
        return out

    def scatter(self, x: np.ndarray, mom, flux_wall) -> None:
        ts, qxs, qys, fw = self.views(x)
        mom.ts[:] = ts
        mom.qxs[:] = qxs
        mom.qys[:] = qys
        if self.nwall:
            flux_wall[self.wall_faces] = fw


# ---------------------------------------------------------------------------
class LowOrderOperator:
    """``(I - K_c)^{-1}``, the synthetic-acceleration solve.

    ``K_c`` is the fixed-point map of the same discrete problem carried on
    ``ncoarse`` ordinates instead of ``NPOLE * NAZIM``.  Everything else --
    the DG space, the collision operator, the upwind fluxes, the wall
    treatment -- is the fine scheme's.

    Applying ``(I - K_c)^{-1}`` to a residual ``r`` means: solve the coarse
    transport problem whose scattering source is built from ``r`` (no
    incoming wall flux -- ``r`` is a correction, not a state), then return
    its moments plus ``r``.  With ``f`` the coarse distribution and ``M`` the
    moment operator, that problem is

        A f + (inflow) f - S M f - (diffuse wall) f = S r + (wall) r_w,

    assembled here as one sparse matrix and factorised once.

    The coarsening is in *angle only*.  Coarsening space as well -- the same
    model on a lower DG degree, with L2 projection and embedding as the
    transfer pair -- was tried and is not viable here: at ``tau_R = 1e-3`` a
    cell is a hundred mean free paths thick, the slow modes have real
    within-cell structure, and a ``DEG = 1`` low-order model takes the
    ``tau_R = 1e-3`` case from 9 iterations to 292.  Synthetic acceleration in
    the thick limit needs the *fine* spatial discretisation; what it does not
    need is the fine angular one.
    """

    def __init__(self, ctx, mesh, layout: ReducedLayout, ncoarse: int = 5,
                 phase: float | None = None):
        import scipy.sparse as sp
        import scipy.sparse.linalg as spla

        if phase is None:
            phase = best_phase(ctx.nx, ctx.ny, ncoarse)

        self.layout = layout
        self.cv = ctx.cv
        self._iso = (1.0 / ctx.tau_r + 1.0 / ctx.tau_n) / (4.0 * PI)
        self._drift = 3.0 / (4.0 * PI * ctx.tau_n * ctx.vg * ctx.vg)

        nd = layout.ndof
        nt = layout.n_tris
        self.nd, self.nt, self.nc = nd, nt, ncoarse
        mass, gx, gy = ctx.mass, ctx.gx, ctx.gy
        fcm, ttfc = ctx.fcm, ctx.ttfc

        cx, cy, w = coarse_directions(ncoarse, ctx.vg, phase)
        self.cx, self.cy, self.w = cx, cy, w

        mass_lm = np.ascontiguousarray(np.transpose(mass, (2, 1, 0)))
        self.mass_lm = mass_lm                    # [i, m, l] = INT phi_l phi_m

        # per-(direction, element) upwind weights
        s = cx[:, None, None] * ctx.nx[None] + cy[:, None, None] * ctx.ny[None]
        wplus = 0.5 * (s + np.abs(s))             # (nc, nt, 3)
        wminus = 0.5 * (s - np.abs(s))
        self.wminus = wminus

        # ---- A_SOL, one block per (direction, element) -------------------
        blocks_r, blocks_c, blocks_v = [], [], []
        tri = np.arange(nt)
        for d in range(ncoarse):
            a = ((1.0 / ctx.tau_c) * np.transpose(mass, (2, 0, 1))
                 - cx[d] * gx - cy[d] * gy)
            a = a + np.einsum("ik,ikml->iml", wplus[d], fcm)
            blocks_r.append(d * nt + tri)
            blocks_c.append(d * nt + tri)
            blocks_v.append(a)

        # ---- upwind inflow from the neighbour, same direction ------------
        # A periodic face's partner counts as a neighbour here exactly as it
        # does in the sweep; ``ttfc`` already carries the geometric offset.
        upwind = ctx.neighbour.astype(np.int64).copy()
        if np.any(ctx.bc_type == BC_PERIODIC):
            per = ctx.periodic_tri[ctx.tri_faces]                 # (nt, 3)
            upwind = np.where(per >= 0, per, upwind)
        for d in range(ncoarse):
            for il in range(3):
                nb = upwind[:, il]
                take = (nb >= 0) & (wminus[d, :, il] != 0.0)
                if not take.any():
                    continue
                idx = np.flatnonzero(take)
                blocks_r.append(d * nt + idx)
                blocks_c.append(d * nt + nb[idx])
                blocks_v.append(wminus[d, idx, il, None, None] * ttfc[idx, il])

        # ---- scattering source, -S M --------------------------------------
        # Scat_d[m] = sum_l INT(phi_l phi_m) * [ Cv T_s/(4 pi tau_C)
        #                                        + 3 (q . c_d)/(4 pi tau_N vg^2) ]
        # with T_s, q themselves quadrature sums over the coarse directions.
        coef = w[None, :] * (self._iso
                             + self._drift * (cx[:, None] * cx[None, :]
                                              + cy[:, None] * cy[None, :]))
        for d in range(ncoarse):
            for dp in range(ncoarse):
                if coef[d, dp] == 0.0:
                    continue
                blocks_r.append(d * nt + tri)
                blocks_c.append(dp * nt + tri)
                blocks_v.append(-coef[d, dp] * mass_lm)

        # ---- diffusely reflecting walls, -(wall) W ------------------------
        self.wall_tri = np.empty(layout.nwall, dtype=np.int64)
        self.wall_lfc = np.empty(layout.nwall, dtype=np.int64)
        for j, f in enumerate(layout.wall_faces):
            self.wall_tri[j], self.wall_lfc[j] = mesh.adjacent(int(f))
        if layout.nwall:
            wtri, wlfc = self.wall_tri, self.wall_lfc
            # outward normal speeds on each wall face, per coarse direction
            u = (cx[:, None] * ctx.nx[wtri, wlfc][None, :]
                 + cy[:, None] * ctx.ny[wtri, wlfc][None, :])       # (nc, nwall)
            self.area_wall = np.einsum("d,dj->j", w, np.maximum(-u, 0.0))
            if np.any(self.area_wall <= 0.0):        # pragma: no cover
                raise ValueError("a diffuse wall face sees no incoming coarse "
                                 "ordinate; rotate the coarse set (phase)")
            self.emit = -(u * w[:, None]).clip(min=0.0) / self.area_wall[None, :]
            self.fcm_wall = fcm[wtri, wlfc]
            for d in range(ncoarse):
                wm = wminus[d, wtri, wlfc]
                take = np.flatnonzero(wm != 0.0)
                if take.size == 0:
                    continue
                for dp in range(ncoarse):
                    g = wm[take] * self.emit[dp, take]
                    hit = np.flatnonzero(g != 0.0)
                    if hit.size == 0:
                        continue
                    sel = take[hit]
                    blocks_r.append(d * nt + wtri[sel])
                    blocks_c.append(dp * nt + wtri[sel])
                    blocks_v.append(-g[hit, None, None] * self.fcm_wall[sel])

        n = ncoarse * nt * nd
        rows, cols, vals = [], [], []
        eye = np.arange(nd)
        for br, bc, bv in zip(blocks_r, blocks_c, blocks_v):
            shape = (br.size, nd, nd)
            rows.append(np.broadcast_to(
                br[:, None, None] * nd + eye[None, :, None], shape).ravel())
            cols.append(np.broadcast_to(
                bc[:, None, None] * nd + eye[None, None, :], shape).ravel())
            vals.append(np.ascontiguousarray(np.broadcast_to(bv, shape)).ravel())
        mat = sp.csc_matrix(
            (np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
            shape=(n, n))
        self.matrix = mat
        # MMD on A^T A: the low-order operator is a DG transport matrix with
        # ncoarse * ndof unknowns per element, and the ordering choice is worth
        # a factor of three in both fill and factorisation time here.
        self.lu = spla.splu(mat, permc_spec="MMD_ATA")
        self.n = n
        self._rhs = np.empty((ncoarse, nt, nd))

    # -- the preconditioner -------------------------------------------------
    def solve(self, r: np.ndarray, out: np.ndarray) -> np.ndarray:
        """``out = (I - K_c)^{-1} r`` for a reduced-space vector ``r``."""
        lay = self.layout
        nc = self.nc
        r_ts, r_qx, r_qy, r_fw = lay.views(r)

        iso = (self.cv * self._iso) * r_ts
        b = self._rhs
        for d in range(nc):
            g = iso + self._drift * (r_qx * self.cx[d] + r_qy * self.cy[d])
            np.einsum("iml,li->im", self.mass_lm, g, out=b[d])
        if lay.nwall:
            for d in range(nc):
                wm = self.wminus[d, self.wall_tri, self.wall_lfc]
                np.add.at(b[d], self.wall_tri, wm[:, None] * r_fw)

        f = self.lu.solve(b.reshape(-1)).reshape(nc, self.nt, self.nd)

        o_ts, o_qx, o_qy, o_fw = lay.views(out)
        np.einsum("d,dil->li", self.w, f, out=o_ts)
        o_ts /= self.cv
        np.einsum("d,dil->li", self.w * self.cx, f, out=o_qx)
        np.einsum("d,dil->li", self.w * self.cy, f, out=o_qy)
        o_ts += r_ts
        o_qx += r_qx
        o_qy += r_qy
        if lay.nwall:
            trace = np.einsum("jml,djl->djm", self.fcm_wall, f[:, self.wall_tri])
            o_fw[:] = np.einsum("dj,djm->jm", self.emit, trace) + r_fw
        return out


# ---------------------------------------------------------------------------
def gmres(matvec, b, precond, rtol, maxiter, x0=None, callback=None):
    """Left-preconditioned GMRES, modified Gram-Schmidt, no restart.

    Returns ``(x, resid, iters)`` with ``resid`` the final
    ``||M (b - A x)|| / ||M b||``.

    Left preconditioning is deliberate.  ``(I - K)`` is ill-conditioned in
    exactly the regimes that make the problem hard -- 2e5 at ``tau_R = 1e-3``,
    2e9 for the diffuse-wall case -- so its residual says little about the
    error in ``x``, and it is the error that has to be small.  With
    ``M ~ A^{-1}`` the preconditioned residual tracks the error instead.  The
    unpreconditioned residual is not lost: the caller gets it for free from
    the sweep that closes the solve.

    No restart, because restarting discards exactly the slow modes the Krylov
    space was built to capture; the caller restarts only as a fallback, if a
    whole cycle failed to converge.
    """
    n = b.size
    z = precond(b, np.empty(n))
    beta0 = float(np.linalg.norm(z))
    if x0 is None:
        x0 = np.zeros(n)                     # then b is already the residual
    else:
        z = precond(b - matvec(x0), np.empty(n))
    if beta0 == 0.0:
        return x0.copy(), 0.0, 0
    beta = float(np.linalg.norm(z))
    if beta <= rtol * beta0 or maxiter < 1:
        return x0.copy(), beta / beta0, 0

    m = int(maxiter)
    # grown on demand: the preconditioned solve finishes in tens of
    # iterations, and ``maxiter`` is a ceiling, not an expectation
    chunk = min(m, 32)
    V = np.empty((chunk + 1, n))
    H = np.zeros((m + 1, m))
    cs = np.zeros(m)
    sn = np.zeros(m)
    g = np.zeros(m + 1)
    V[0] = z / beta
    g[0] = beta

    k = 0
    while k < m:
        if k + 1 >= V.shape[0]:
            V = np.concatenate([V, np.empty((min(V.shape[0], m + 1 - V.shape[0]),
                                             n))])
        w = precond(matvec(V[k]), np.empty(n))
        for j in range(k + 1):
            H[j, k] = V[j] @ w
            w -= H[j, k] * V[j]
        hk = float(np.linalg.norm(w))
        H[k + 1, k] = hk
        if hk > 0.0:
            V[k + 1] = w / hk
        for j in range(k):                       # replay the past rotations
            t = cs[j] * H[j, k] + sn[j] * H[j + 1, k]
            H[j + 1, k] = -sn[j] * H[j, k] + cs[j] * H[j + 1, k]
            H[j, k] = t
        d = np.hypot(H[k, k], H[k + 1, k])
        if d == 0.0:
            cs[k], sn[k] = 1.0, 0.0
        else:
            cs[k], sn[k] = H[k, k] / d, H[k + 1, k] / d
        H[k, k] = d
        H[k + 1, k] = 0.0
        g[k + 1] = -sn[k] * g[k]
        g[k] = cs[k] * g[k]
        k += 1
        if callback is not None:
            callback(abs(g[k]) / beta0)
        if abs(g[k]) <= rtol * beta0 or hk == 0.0:
            break

    y = np.linalg.solve(H[:k, :k], g[:k]) if k else np.zeros(0)
    return x0 + V[:k].T @ y, abs(g[k]) / beta0, k
