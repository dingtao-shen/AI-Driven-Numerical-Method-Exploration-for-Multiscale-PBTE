# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, transport sweeps driven by a
preconditioned Krylov solve of the outer system.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/F1_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte run cases/F1_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

    while True:
        sweep()                 # exact transport solve, one direction at a time,
                                # in a topological order of the element graph
        compute_moments()       # T, qx, qy from the distribution
        if residual < tol: break

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

## How the outer loop is actually solved

That loop is Richardson iteration.  The sweep never reads the incoming
distribution -- it is an exact per-direction solve, visited upwind-first --
so everything it needs from the previous iterate is the scattering source:
`(T_s, qx_s, qy_s)` per element DOF, plus the emission of any diffusely
reflecting wall.  Call that vector `x`; one iteration is the affine map

    x <- K x + c

and the converged state is the solution of the linear system `(I - K) x = c`.
The rate of the plain loop is the spectral radius of `K`, which goes to 1 in
both stiff limits -- optically thick (`tau_R -> 0`) and hydrodynamic
(`tau_N << tau_R`) -- which is why the shipped loop needs 17 000 sweeps at
`tau_R = 1e-2` and never arrives at `1e-3`.

`pybte.accel` solves the same system with GMRES instead, preconditioned by a
*low-order* copy of the discrete problem: same mesh, same DG space, same
collision operator, same boundary treatment, but three to five discrete
ordinates instead of two hundred.  The coarse ordinate set is built to
reproduce `INT dOmega`, `INT c dOmega` and `INT c c dOmega` exactly, so the
low-order model has the same diffusion limit and the same momentum
relaxation rate as the problem it accelerates; it is small enough and sparse
enough to LU-factorise once at setup and apply directly.  That is classical
synthetic acceleration (DSA), with the low-order model built by angular
coarsening rather than by hand.

Nothing in it touches the operator or the right-hand side, so the answer is
unchanged -- what changes is that every case now converges in 13 to 25
sweeps, and that "converged" means the residual of `(I - K) x - c` is at
round-off rather than that successive iterates stopped moving.  Those are
different statements: a step of `1e-8` at `rho = 1 - 1e-3` leaves an error of
`1e-5`.

`scheme.accelerate: false` restores the Fortran's loop verbatim.

## Cases

Two boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the reduced system, its preconditioner and GMRES
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `record.iterations` counts transport sweeps.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
