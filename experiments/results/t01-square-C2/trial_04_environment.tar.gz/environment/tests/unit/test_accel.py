"""The acceleration machinery: the coarse ordinate set, the reduced layout,
the low-order operator and the Krylov solver.

Gate: the low-order model must be *consistent* with the transport problem it
accelerates -- same zeroth and first angular moments -- and the Krylov solver
must actually solve.  A preconditioner cannot move the answer, but a coarse
set with the wrong moments silently stops accelerating in exactly the stiff
limits the whole thing exists for, and that failure looks like "slow", not
like "wrong".
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.accel import (LowOrderOperator, ReducedLayout, best_phase,
                         coarse_directions, gmres)
from pybte.constants import PI

from ..conftest import CASES


@pytest.mark.parametrize("ncoarse", [3, 4, 5, 6, 8])
def test_coarse_set_has_exact_p1_moments(ncoarse):
    """``sum w``, ``sum w c`` and ``sum w c c`` must match the sphere.

    These three fix the diffusion coefficient and the momentum relaxation
    rate of the low-order model.  Get them wrong and the preconditioner is
    asymptotically inconsistent in the thick limit -- which is where it is
    needed.
    """
    vg = 1.7
    cx, cy, w = coarse_directions(ncoarse, vg, 0.3)
    assert w.sum() == pytest.approx(4.0 * PI, rel=1e-14)
    assert (w * cx).sum() == pytest.approx(0.0, abs=1e-14)
    assert (w * cy).sum() == pytest.approx(0.0, abs=1e-14)
    want = 4.0 * PI / 3.0 * vg * vg
    assert (w * cx * cx).sum() == pytest.approx(want, rel=1e-14)
    assert (w * cy * cy).sum() == pytest.approx(want, rel=1e-14)
    assert (w * cx * cy).sum() == pytest.approx(0.0, abs=1e-14)


@pytest.mark.parametrize("ncoarse", [3, 4, 5, 6, 8])
def test_best_phase_beats_the_unrotated_set(shipped_mesh, ncoarse):
    """Every coarse ordinate keeps a nonzero projection on every face.

    A direction lying *in* a face's plane carries no flux through it, which
    is physically right but leaves that face out of the low-order operator
    altogether.  On a structured mesh whole families of faces share a normal
    and the loss is systematic -- three ordinates at the natural 30-degree
    offset put one of them along -y, parallel to every vertical face.  The
    shipped mesh is unstructured, so its normals cover the circle and no
    rotation can do much; the requirement is only that the chosen one is no
    worse than not rotating at all.
    """
    nx = shipped_mesh.tri_normal[:, :, 0]
    ny = shipped_mesh.tri_normal[:, :, 1]

    def worst(phase):
        cx, cy, _ = coarse_directions(ncoarse, 1.0, phase)
        return np.abs(cx[:, None] * nx.ravel()[None, :]
                      + cy[:, None] * ny.ravel()[None, :]).min()

    chosen = best_phase(nx, ny, ncoarse)
    assert worst(chosen) > 0.0
    assert worst(chosen) >= worst(0.0)


def test_reduced_layout_round_trips():
    rng = np.random.default_rng(7)
    lay = ReducedLayout(6, 200, np.array([3, 11, 29], dtype=np.int64))
    assert lay.size == 3 * 6 * 200 + 3 * 6

    class Mom:
        ts = np.zeros((6, 200))
        qxs = np.zeros((6, 200))
        qys = np.zeros((6, 200))

    x = rng.normal(size=lay.size)
    fw = np.zeros((320, 6))
    lay.scatter(x, Mom, fw)
    assert np.array_equal(lay.gather(Mom, fw, np.empty(lay.size)), x)


def test_gmres_solves_a_dense_system():
    """The Arnoldi/Givens bookkeeping, checked away from the solver."""
    rng = np.random.default_rng(3)
    n = 40
    a = rng.normal(size=(n, n)) + 4.0 * np.eye(n)
    b = rng.normal(size=n)
    want = np.linalg.solve(a, b)

    def identity(r, out):
        out[:] = r
        return out

    x, res, its = gmres(lambda v: a @ v, b, identity, 1e-13, n + 5)
    assert its <= n
    assert res <= 1e-13
    assert np.allclose(x, want, rtol=1e-9, atol=1e-11)

    # ... and a warm start converges to the same place
    x2, _, _ = gmres(lambda v: a @ v, b, identity, 1e-13, n + 5,
                     x0=want + 1e-3 * rng.normal(size=n))
    assert np.allclose(x2, want, rtol=1e-9, atol=1e-11)


def _reduced(case):
    s = Solver(case)
    lay = ReducedLayout(s.ndof, s.n_tris, s._wall_faces())
    return s, lay


def _fixed_point_map(s, lay):
    """``x -> K x + c``: one sweep from the source ``x``, then its moments."""
    from pybte.moments import compute_moments

    def apply(x):
        lay.scatter(x, s.mom, s.bcdata.flux_wall)
        s.ctx.sweep(s.mom, s.vdf)
        compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                        s.integrals.int_tri, s.case.flow.cv, s.mom)
        if lay.nwall:
            s.bcdata.update_wall_flux(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                                      s.integrals.int_tri_fc, s.mesh)
        return lay.gather(s.mom, s.bcdata.flux_wall, np.empty(lay.size))
    return apply


def test_outer_map_is_affine_and_ignores_the_incoming_vdf():
    """The whole method rests on this.

    The sweep is an exact per-direction solve visited in a topological order,
    so it reads the incoming ``vdf`` only through neighbours it has already
    overwritten in the same pass.  That makes one outer iteration an *affine*
    map of the moments alone -- which is what turns source iteration into
    Richardson iteration on a linear system, and lets a Krylov method replace
    it without touching the physics.
    """
    case = Case.from_yaml(CASES / "F2_1e-1.yaml")
    case.output.field = case.output.run_record = case.output.runtime_log = False
    s, lay = _reduced(case)
    apply = _fixed_point_map(s, lay)
    rng = np.random.default_rng(0)

    c0 = apply(np.zeros(lay.size))
    u, v = rng.normal(size=lay.size), rng.normal(size=lay.size)

    # not a function of the state the sweep starts from
    s.vdf[:] = rng.normal(size=s.vdf.shape)
    assert np.array_equal(apply(u), apply(u))

    ku = apply(u) - c0
    kv = apply(v) - c0
    kuv = apply(2.0 * u - 3.0 * v) - c0
    scale = np.abs(kuv).max()
    assert np.abs(kuv - (2.0 * ku - 3.0 * kv)).max() <= 1e-12 * scale


def _coarse_ordinate_solver(case, ncoarse, phase):
    """A solver whose *fine* angular mesh is the coarse ordinate set.

    Same mesh, same DG space, same kernels -- only the ordinates change.  It
    lets the low-order operator be checked against the production sweep
    rather than against a second copy of its own arithmetic.
    """
    from pybte.bc import build_boundary_data
    from pybte.ordering import build_sweep_order
    from pybte.sweep import SweepContext
    from pybte.velocity import VelocityMesh

    s = Solver(case)
    cx, cy, w = coarse_directions(ncoarse, case.flow.vg, phase)
    vel = VelocityMesh(the=np.zeros(ncoarse), wthe=np.zeros(ncoarse),
                       phi=np.zeros(1), wphi=np.zeros(1),
                       domega=w[:, None], cx=cx[:, None], cy=cy[:, None])
    order = build_sweep_order(s.mesh, vel)
    s.bcdata = build_boundary_data(s.mesh, case.boundaries, case.ndof_tri)
    s.ctx = SweepContext.build(case, s.mesh, s.integrals, vel, order, s.bcdata)
    s.ndir = ncoarse
    s.vdf = np.zeros((ncoarse, s.n_tris, s.ndof))
    return s


@pytest.mark.parametrize("name", ["F1_1e-3", "F2_10_1e-2"])
def test_low_order_operator_inverts_the_coarse_transport_problem(name):
    """``solve`` is ``(I - K_c)^-1`` for the coarse-ordinate transport problem.

    ``K_c`` here is built the honest way -- by actually sweeping the coarse
    ordinate set with the production kernels -- so this checks the assembled
    sparse operator, the scattering source, the moment reduction and the
    diffuse-wall coupling against the scheme they are supposed to mirror.  A
    sign slip anywhere in the low-order model would leave the answer intact
    (a preconditioner cannot move it) and only show up as lost speed; this is
    what catches it instead.
    """
    case = Case.from_yaml(CASES / f"{name}.yaml")
    case.output.field = case.output.run_record = case.output.runtime_log = False
    ref = Solver(case)
    lay = ReducedLayout(ref.ndof, ref.n_tris, ref._wall_faces())
    nc = ref._ncoarse()
    phase = best_phase(ref.ctx.nx, ref.ctx.ny, nc)
    low = LowOrderOperator(ref.ctx, ref.mesh, lay, ncoarse=nc, phase=phase)

    sc = _coarse_ordinate_solver(case, nc, phase)
    step = _fixed_point_map(sc, lay)
    c0 = step(np.zeros(lay.size))

    rng = np.random.default_rng(11)
    r = rng.normal(size=lay.size)
    x = low.solve(r, np.empty(lay.size))
    residual = x - (step(x) - c0) - r            # (I - K_c) x - r
    assert np.abs(residual).max() <= 1e-9 * np.abs(x).max()
