"""End-to-end: every shipped case must converge to the solution of the
discrete transport system, not merely stop moving.

Gate: three separate things have to hold at the end of a run, and the usual
stopping test checks none of them.

1. ``||A f - b|| / ||b||`` must be at round-off, evaluated from the converged
   distribution with the moments recomputed from it -- the fixed point of the
   coupled system, not of whatever quantity the loop happened to watch.
2. ``record.temp`` must be the moments of ``solver.vdf``, so that reading the
   answer off the record and recomputing it from the distribution give the
   same field.
3. The two solve paths -- preconditioned Krylov and the Fortran's source
   iteration -- must land on the same state, because they are two ways of
   solving one linear system and nothing in the acceleration touches it.

Source iteration passes (1) only where it can afford the sweeps: at
``tau_R = 1e-3`` it reports a 1.6e-5 step after 30 000 of them with a mass of
0.0996 against a true 0.2500.  That is the failure these tests exist to
prevent regressing back into.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.bc import boundary_heat_flux
from pybte.moments import Moments, compute_moments

from ..conftest import CASES

ALL_CASES = ["F1_1e-1", "F1_1e-2", "F1_1e-3", "F1_1_1", "F1_10_1e-2",
             "F2_1e-1", "F2_1e-2", "F2_1e-3", "F2_1_1", "F2_10_1e-2"]

#: mass = INT T dA over the unit square.  Family F1 heats one wall of four,
#: F2 one of two; both are exact by symmetry in the diffusion limit and stay
#: within a few 1e-3 of it across the whole stiffness range.
EXPECTED_MASS = {"F1": 0.25, "F2": 0.5}


def _case(name, **over):
    case = Case.from_yaml(CASES / f"{name}.yaml")
    case.output.field = case.output.run_record = case.output.runtime_log = False
    for k, v in over.items():
        setattr(case.iteration, k, v)
    return case


def _moments_of(solver):
    """Recompute the moments from the converged distribution, from scratch."""
    mom = Moments.zeros(solver.ndof, solver.n_tris)
    compute_moments(solver.vdf, solver.ctx.cxv, solver.ctx.cyv, solver.ctx.domega,
                    solver.integrals.int_tri, solver.case.flow.cv, mom)
    return mom


@pytest.fixture(scope="module", params=ALL_CASES)
def solved(request):
    case = _case(request.param)
    solver = Solver(case)
    return request.param, solver, solver.run()


def test_converges_well_inside_tmax(solved):
    name, solver, rec = solved
    assert rec.converged, f"{name} did not converge"
    assert rec.iterations <= solver.case.iteration.tmax
    # the whole point: the sweep count stops depending on the stiffness
    assert rec.iterations < 60, f"{name} needed {rec.iterations} sweeps"


def test_converged_distribution_solves_the_transport_system(solved):
    """The residual of ``A f = b(moments(f))``, from the distribution alone."""
    name, solver, _ = solved
    mom = _moments_of(solver)
    if solver.bcdata.has_nonthermalising:
        solver.bcdata.update_wall_flux(
            solver.vdf, solver.ctx.cxv, solver.ctx.cyv, solver.ctx.domega,
            solver.integrals.int_tri_fc, solver.mesh)
    res = solver.ctx.true_residual(mom, solver.vdf)
    assert res < 1e-9, f"{name}: transport residual {res:.3e}"


def test_record_matches_the_distribution(solved):
    name, solver, rec = solved
    mom = _moments_of(solver)
    assert np.array_equal(rec.temp, mom.temp), name
    assert np.array_equal(rec.qx, mom.qx), name
    assert np.array_equal(rec.qy, mom.qy), name


def test_mass_is_the_symmetry_value(solved):
    """A physical check that does not go through the solver's own residual."""
    name, _, rec = solved
    want = EXPECTED_MASS[name.split("_")[0]]
    assert rec.mass == pytest.approx(want, abs=2e-3), name


def test_sweep_stays_callable_from_the_converged_state(solved):
    """``ctx.sweep(mom, vdf)`` is the interface; it must survive the run.

    And at the fixed point it must be a no-op to round-off: sweeping from the
    converged moments has to reproduce the converged distribution.
    """
    name, solver, _ = solved
    before = solver.vdf.copy()
    solver.ctx.sweep(solver.mom, solver.vdf)
    scale = np.abs(before).max()
    assert np.abs(solver.vdf - before).max() <= 1e-10 * scale, name


def test_diffuse_walls_are_adiabatic(solved):
    """Zero net normal energy flux on every type-2 face, to round-off."""
    name, solver, _ = solved
    if not solver.bcdata.has_nonthermalising:
        pytest.skip("no diffusely reflecting wall")
    flux = boundary_heat_flux(solver)
    walls = solver._wall_faces()
    assert np.abs(flux[walls]).max() < 1e-12, name


@pytest.mark.parametrize("name", ["F1_1e-1", "F2_1_1"])
def test_krylov_and_source_iteration_agree(name):
    """Two solvers, one linear system, one answer.

    Run on cases where source iteration can actually reach the fixed point;
    it is driven to round-off rather than to the shipped ``tol``, because
    ``tol`` measures a step and this is comparing answers.
    """
    fast = Solver(_case(name)).run()

    case = _case(name, tol=1e-15, tmax=40000)
    case.scheme.accelerate = False
    slow = Solver(case).run()

    err = np.abs(fast.temp - slow.temp) / np.abs(slow.temp)
    assert err.max() < 1e-8, f"{name}: worst element differs by {err.max():.2e}"
    assert fast.iterations * 4 < slow.iterations


def test_diffusion_limit_matches_the_fourier_solution():
    """At ``tau_R = 1e-3`` the answer must be Fourier's law.

    The cell averages are compared against the 200-term series ``analytic``
    carries, away from the two hot corners where the series itself rings.
    This is the check that the accelerated answer is *right*, not merely
    self-consistent: nothing in it refers to the solver's own residual.
    """
    from pybte.analytic import fourier_temperature

    solver = Solver(_case("F1_1e-3"))
    rec = solver.run()
    mesh = solver.mesh
    centroid = mesh.nodes[mesh.tri_nodes].mean(axis=1)
    cell_avg = rec.temp / mesh.tri_area
    want = fourier_temperature(centroid[:, 0], centroid[:, 1])

    interior = centroid[:, 1] < 0.85
    assert np.abs(cell_avg - want)[interior].max() < 0.02
    assert rec.mass == pytest.approx(0.25, abs=1e-4)
