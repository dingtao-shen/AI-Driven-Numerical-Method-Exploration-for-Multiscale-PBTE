"""The outer iteration -- the port of ``Callaway_2D_2V_DG.f90``.

The reference loop is::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

which is Richardson iteration on the fixed point ``y = G y + g`` in the
macroscopic unknowns.  It is kept verbatim as
:meth:`Solver.run_source_iteration`, and one pass of it is
:meth:`Solver.step`, but it is not what :meth:`Solver.run` does: Richardson's
contraction factor is ``1 - O((Vg tau_C k)^2)``, so on the optically thick
cases it needs upwards of a million sweeps.  :meth:`Solver.run` gives the
same system to the diffusion-preconditioned GMRES in :mod:`pybte.accel`
instead -- still one transport sweep per matvec, still the same fixed point,
but reached in a couple of dozen sweeps at every ``(tau_R, tau_N)`` in the
benchmark.

Also added around the loop: an explicit restart contract, an optional true
residual, and a :class:`~pybte.io_output.RunRecord` complete enough that a
verifier never has to parse stdout.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        # np.frombuffer gives a read-only array, and the transpose+reshape
        # below is a view of it, so this has to be a copy: the sweep writes
        # into VDF in place.
        self.vdf = np.array(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof),
            dtype=np.float64, order="C", copy=True)
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Solve the discrete transport system to the fixed point.

        The fixed point is the same one ``Calculate_Residual_T < tol`` was
        aiming at; how it is reached is not.  Source iteration is Richardson
        on ``(I - G) y = g`` in the macroscopic unknowns, and it stalls once
        the medium is optically thick.  :mod:`pybte.accel` hands the same
        system to a diffusion-preconditioned GMRES instead, one sweep per
        matvec.  ``run_source_iteration`` keeps the original loop for
        comparison, and is used as a fallback.
        """
        c = self.case
        if c.iteration.tmax < 4 or not self.case.scheme.accelerate:
            return self.run_source_iteration(callback, progress_every)
        try:
            return self._run_krylov(callback, progress_every)
        except (ImportError, np.linalg.LinAlgError, RuntimeError) as exc:  # pragma: no cover
            warnings.warn(f"Krylov acceleration unavailable ({exc}); "
                          "falling back to source iteration")
            return self.run_source_iteration(callback, progress_every)

    def _run_krylov(self, callback=None, progress_every: int = 0) -> RunRecord:
        from . import accel
        from .accel import DSAPreconditioner, MomentSystem, gmres_solve

        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        t0 = time.perf_counter()

        ms = MomentSystem(self)
        pre = DSAPreconditioner(self)

        # a restart file gives a starting state; otherwise start from zero
        x0 = np.zeros(ms.n)
        if np.any(self.vdf):
            if self.bcdata.has_nonthermalising:
                self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                             self.ctx.domega,
                                             self.integrals.int_tri_fc, self.mesh)
            compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                            self.integrals.int_tri, c.flow.cv, self.mom)
            x0 = ms.pack_current()

        masses: list[float] = []

        def phi(y):
            out = ms.apply(y)
            masses.append(self.mom.mass)
            if progress_every and ms.sweeps % progress_every == 0:
                print(f"  sweep {ms.sweeps:6d}  mass {self.mom.mass:.10f}", flush=True)
            return out

        g = phi(np.zeros(ms.n))

        def matvec(y):
            return y - (phi(y) - g)

        # a hundredth of the stopping tolerance, but never below the level
        # where the preconditioned residual bottoms out in round-off
        rtol = min(accel.KRYLOV_RTOL, max(1.0e-13, 1.0e-2 * tol))
        maxit = tmax - 2
        y, res_hist, ok = gmres_solve(matvec, pre.apply, g, x0, rtol, maxit)

        # one last sweep so that the VDF is the exact transport solve of the
        # converged moments: that is what the residual gate is computed from
        t_before = np.einsum("li,li->i", ms.unpack(y)[0], self.integrals.int_tri)
        phi(y)
        # Calculate_Residual_T divides by ||T||, which is 0/0 when every wall
        # is cold -- a legitimate solution, so call it converged rather than
        # letting the kernel divide by zero
        res = (residual_iterate(self.mom.temp, t_before)
               if np.any(self.mom.temp) else 0.0)
        self.t_old[:] = self.mom.temp

        residuals = list(res_hist) + [res]
        if callback is not None:
            callback(ms.sweeps, res, self)
        converged = bool(res < tol)
        krylov_sweeps = ms.sweeps

        # Safety net.  GMRES has never needed it on any of the shipped cases,
        # but if the preconditioner were to mislead it on some other one the
        # answer must still be right: spend whatever is left of TMAX on plain
        # source iteration rather than return a half-solved field.
        while not converged and ms.sweeps < tmax:
            self.step()
            ms.sweeps += 1
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if callback is not None:
                callback(ms.sweeps, res, self)
            converged = bool(res < tol)

        true_res = None
        if c.iteration.true_residual:
            true_res = [self.ctx.true_residual(self.mom, self.vdf)]
        if self.ctx.mode == "onthefly":
            # the fallback loop goes through step(), which counts its own
            self.factorisation_count += krylov_sweeps * self.ndir * self.n_tris
        wall = time.perf_counter() - t0
        rec = self._record(ms.sweeps, converged, residuals, masses, true_res, wall,
                           scheme="DSA-GMRES")
        rec.diagnostics["gmres_iterations"] = len(res_hist)
        rec.diagnostics["gmres_converged"] = bool(ok)
        rec.diagnostics["preconditioner"] = "coupled" if pre.coupled else "decoupled"
        return rec

    def run_source_iteration(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Source iteration: ``Calculate_Residual_T < tol``, as the Fortran."""
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
