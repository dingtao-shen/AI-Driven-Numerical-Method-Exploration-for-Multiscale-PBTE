"""The accelerated outer iteration must land on the reference fixed point.

Gate: whatever ``Solver.run`` does between sweeps, the distribution it stops
at has to satisfy the *same* discrete transport system that source iteration
is converging towards, to round-off and not to the stopping tolerance.  A
preconditioner that quietly damped the physics, or a stopping rule that
measured the wrong thing, would show up here and nowhere else.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.accel import MomentSystem
from pybte.moments import compute_moments

from ..conftest import CASES


def _case(name, **flow):
    c = Case.from_yaml(CASES / name)
    c.output.field = c.output.run_record = c.output.runtime_log = False
    c.velmesh.npole, c.velmesh.nazim = 6, 8
    c.dg.deg = 1
    for k, v in flow.items():
        setattr(c.flow, k, v)
    return c


def test_matches_source_iteration():
    """Same answer as the loop it replaces, on a case the loop can finish."""
    fast = Solver(_case("kn_1e-3.yaml", tau_r=0.1)).run()

    slow_case = _case("kn_1e-3.yaml", tau_r=0.1)
    slow_case.scheme.accelerate = False
    slow_case.iteration.tol = 1.0e-14
    slow_case.iteration.tmax = 200_000
    slow = Solver(slow_case).run()

    assert fast.converged and slow.converged
    assert fast.iterations < slow.iterations / 5
    rel = np.abs(fast.temp - slow.temp) / np.abs(slow.temp).max()
    assert rel.max() < 1e-9, f"worst element off by {rel.max():.3e}"


@pytest.mark.parametrize("tau_r", [1.0e-3, 10.0])
def test_converged_vdf_solves_the_transport_system(tau_r):
    """``||A f - b|| / ||b||`` from the shipped kernels, not from our own
    stopping criterion.  ``tau_R = 1e-3`` is the thick end, ``tau_R = 10``
    with ``tau_N = 1e-2`` the hydrodynamic one."""
    c = _case("kn_1e-3.yaml", tau_r=tau_r, tau_n=1.0e-2 if tau_r > 1 else 1.0e5)
    s = Solver(c)
    rec = s.run()
    assert rec.converged
    assert s.ctx.true_residual(s.mom, s.vdf) < 1e-9


def test_fixed_point_is_stationary_under_one_more_sweep():
    """G2: ``ctx.sweep(mom, vdf)`` still works, and at the answer it is the
    identity -- which is what "converged" is supposed to mean."""
    s = Solver(_case("kn_1e-3.yaml", tau_r=1.0e-3))
    rec = s.run()
    before = rec.temp.copy()
    s.ctx.sweep(s.mom, s.vdf)
    compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                    s.integrals.int_tri, s.case.flow.cv, s.mom)
    rel = np.abs(s.mom.temp - before) / np.abs(before).max()
    assert rel.max() < 1e-10


def test_moment_map_is_affine():
    """The acceleration is only legitimate because one sweep is an affine
    function of the moments.  If it ever stops being one -- a broken sweep
    cycle, say -- GMRES would be solving a system that does not exist."""
    s = Solver(_case("kn_1e-3.yaml", tau_r=0.5))
    ms = MomentSystem(s)
    rng = np.random.default_rng(7)
    a = rng.normal(size=ms.n)
    b = rng.normal(size=ms.n)

    g = ms.apply(np.zeros(ms.n)).copy()
    ga = ms.apply(a) - g
    gb = ms.apply(b) - g
    gab = ms.apply(a + b) - g
    scale = np.abs(gab).max()
    assert np.abs(gab - (ga + gb)).max() < 1e-11 * scale


def test_reflecting_wall_state_round_trips():
    """The diffuse-wall unknown is carried as a departure from the local
    blackbody value; packing and unpacking it must be the identity."""
    c = _case("kn_1e-3.yaml", tau_r=0.5)
    c.boundaries[2].type = c.boundaries[3].type = "nonthermalising"
    s = Solver(c)
    ms = MomentSystem(s)
    assert ms.nw > 0
    y = ms.apply(np.zeros(ms.n)).copy()
    assert np.array_equal(ms.pack_current(), y)
