# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, diffusion-accelerated Krylov iteration in
the macroscopic unknowns.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/F1_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte cases/F1_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

The transport sweep is unchanged from the reference:

    sweep()                 # exact transport solve, one direction at a time,
                            # in a topological order of the element graph
    compute_moments()       # T, qx, qy from the distribution

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

What changed is what surrounds it.  Everything the sweep reads is macroscopic
-- `T`, `qx`, `qy`, and the emission of any diffusely reflecting wall -- so
one sweep plus one moment update evaluates an *affine* map `y -> G y + g` on
a few thousand unknowns, at the cost of one sweep.  The reference loop is
Richardson iteration on `(I - G) y = g`:

    while True:
        y = G y + g
        if ||dy|| < tol: break

and it converges at `1 - O((Vg tau_C k)^2)` per sweep, which is why it needs
16 830 sweeps at `tau_R = 1e-2` and more than 30 000 at `tau_R = 1e-3`.
`Solver.run` hands the same system to GMRES instead, preconditioned by the
low-order (diffusion / phonon-hydrodynamic) operator that the transport
sweep tends to when the cells are optically thick -- see `accel.py` for the
derivation and for why the low-order operator has to be a *discontinuous*
Galerkin one.  Every matvec is still exactly one `ctx.sweep`, the fixed point
is bit-for-bit the one the reference loop is converging towards, and the
whole benchmark set lands in 14 to 25 sweeps:

| case | source iteration | this solver |
|---|---|---|
| `F1_1_1`      |     33 |  14 |
| `F1_1e-1`     |    317 |  14 |
| `F1_1e-2`     | 16 830 |  14 |
| `F1_1e-3`     | >30 000 (no convergence) | 16 |
| `F1_10_1e-2`  |  2 706 |  16 |
| `F2_1_1`      |     75 |  16 |
| `F2_1e-1`     |    643 |  18 |
| `F2_1e-2`     | >30 000 (no convergence) | 17 |
| `F2_1e-3`     | >30 000 (no convergence) | 19 |
| `F2_10_1e-2`  |  2 444 |  25 |

Sweep count is flat in the mesh too: 16-25 sweeps from 50 to 3200 elements.

`Solver.run_source_iteration` still runs the original loop, and
`scheme.accelerate: false` in a case file selects it.

## Cases

Two boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration, and `accel.py` carries it as
part of the unknown.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the Krylov/DSA acceleration and its low-order operators
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `record.iterations` counts transport sweeps.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
