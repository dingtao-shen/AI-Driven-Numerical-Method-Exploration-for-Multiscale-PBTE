# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, source iteration in time.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/F1_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte cases/F1_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How the sweep works

    sweep()                 # exact transport solve, one direction at a time,
                            # in a topological order of the element graph
    compute_moments()       # T, qx, qy from the distribution

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

## How the solve works

Because the sweep is exact, the distribution that comes out of it depends on
the one that went in *only* through the moments the scattering source is built
from -- `Ts`, `qx`, `qy` per element DOF, plus the emission of any diffusely
reflecting wall.  Call that stack `z`; one outer iteration is then an affine
map `z -> G z + g`, and the answer is the solution of

    (I - G) z = g

The Fortran's loop is Richardson iteration on that system.  Its contraction
factor is `1 - O((tau_C Vg / L)^2)`, so in the optically thick cases it needs
of order `10^6` sweeps -- and long before that it starts reporting a step size
below `tol` while still being most of the way from its own fixed point.  It is
kept, verbatim, as `Solver.run_source_iteration`.

`Solver.run` solves the system instead.  GMRES on `(I - G) z = g`, one
transport sweep per matrix-vector product, converging on the residual of the
real system rather than on the size of a step.  Optically thick cases get a
preconditioner: `pybte.accel` writes `I - G` out as a dense matrix by pushing
every unit source through the sweep at once, on a *reduced* angular quadrature
chosen so that its second moment -- and so its diffusion limit -- is exact.
The reduced operator is a few percent of the cost of the fine one and, since
it only preconditions, it sets the iteration count and never the answer.

All ten shipped cases converge in 11 to 43 sweeps this way, to a transport
residual of `1e-13` or better.

`performance.scheme` picks between `krylov` (the default), `krylov-plain`
(never preconditioned) and `source` (the Fortran's loop).

## Cases

Two boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the condensed system, its explicit form, and GMRES
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
* The jitted kernels are `cache=True`, so a first run in a tree whose
  `__pycache__` is missing -- or whose source timestamps have changed, which
  invalidates numba's cache -- pays several seconds of compilation before it
  does any work.  Copy the tree with timestamps preserved (`cp -a`, `rsync
  -a`, `tar`) to keep it.
* `integration.EXACT_POW` is off by default.  It buys face tensors bit-identical
  to the Fortran's at the price of a Python loop over every quadrature point,
  which is most of setup; what it costs to leave off is one ulp.
