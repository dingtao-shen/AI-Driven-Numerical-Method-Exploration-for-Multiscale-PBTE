"""Solving the outer iteration instead of iterating it.

The sweep is an *exact* transport solve: within a direction the elements are
visited in a topological order of the upwind graph, so every inflow term is
read after the neighbour that produces it has been written, and what comes out
of ``DG_Solver_VDF`` is ``f = L^-1 (scattering source + wall inflow)`` with no
dependence at all on the ``f`` that went in.  One outer iteration therefore
only ever communicates through the handful of fields the source is built from:

    Ts, qx, qy      per element DOF -- the moments of the previous iterate
    FLUX_WALL       per diffusely reflecting face -- its emission

Stack those into ``z`` and the whole outer loop is an *affine* map,
``z -> G z + g``, with ``G`` linear and ``g`` the wall-temperature drive.
Source iteration is then plain Richardson on ``(I - G) z = g``, and its
spectral radius goes to 1 as the medium becomes optically thick -- which is
exactly the pseudo-convergence the shipped solver runs into.  Nothing about
the discrete system is stiff; only that particular way of solving it is.

So we solve the system.  :class:`CondensedSystem` is ``(I - G)`` with one
matrix-vector product per transport sweep, and :func:`gmres` drives it to a
residual far below the level at which the answer is still moving.  For the
optically thick cases GMRES alone still needs hundreds of sweeps, so
:func:`condensed_matrix` builds ``I - G`` *explicitly* -- on a coarse angular
quadrature, which is cheap and, because both quadratures share the same
diffusion limit, captures precisely the modes that make the fine problem
slow.  It enters only as a preconditioner, so its accuracy sets the iteration
count and never the answer.
"""
from __future__ import annotations

import numpy as np

from . import _kernels
from .constants import BC_NONTHERMALISING, PI
from .moments import compute_moments
from .ordering import build_sweep_order
from .velocity import VelocityMesh

__all__ = ["CondensedSystem", "condensed_matrix", "coarse_velocity_mesh",
           "gmres", "estimate_krylov_iterations", "flux_feedback_strength"]


# ---------------------------------------------------------------------------
# the condensed map
# ---------------------------------------------------------------------------
class CondensedSystem:
    """``(I - G)`` for the outer iteration's affine map, one sweep per product.

    The state is ``z = (Ts, qx, qy, FLUX_WALL)`` flattened element-major, i.e.
    element ``i`` DOF ``l`` at ``i*ndof + l``, which is the order the response
    kernel writes its columns in.
    """

    def __init__(self, solver):
        self.solver = solver
        s = solver
        self.ndof = s.ndof
        self.n_tris = s.n_tris
        self.nmom = s.ndof * s.n_tris

        m = s.mesh
        if s.bcdata.has_nonthermalising:
            bc_type = s.bcdata.bc_type
            faces = [f for f in range(m.n_faces)
                     if m.face_bc[f] >= 0
                     and bc_type[m.face_bc[f]] == BC_NONTHERMALISING]
        else:
            faces = []
        self.wall_faces = np.array(faces, dtype=np.int32)
        self.nwall = self.wall_faces.size * self.ndof
        self.n = 3 * self.nmom + self.nwall
        self.bc_temp = s.ctx.bc_temp.copy()
        self.sweeps = 0

    # -- packing ----------------------------------------------------------
    def load(self, z) -> None:
        """Write ``z`` into the solver's moments and wall emission."""
        s = self.solver
        k, nd, nt = self.nmom, self.ndof, self.n_tris
        s.mom.ts[:] = z[:k].reshape(nt, nd).T
        s.mom.qxs[:] = z[k:2 * k].reshape(nt, nd).T
        s.mom.qys[:] = z[2 * k:3 * k].reshape(nt, nd).T
        if self.nwall:
            s.bcdata.flux_wall[:] = 0.0
            s.bcdata.flux_wall[self.wall_faces] = z[3 * k:].reshape(-1, nd)

    def store(self) -> np.ndarray:
        s = self.solver
        parts = [s.mom.ts.T.ravel(), s.mom.qxs.T.ravel(), s.mom.qys.T.ravel()]
        if self.nwall:
            parts.append(s.bcdata.flux_wall[self.wall_faces].ravel())
        return np.concatenate(parts)

    # -- the map ----------------------------------------------------------
    def apply(self, z, homogeneous: bool = False) -> np.ndarray:
        """One outer iteration started from ``z``: ``G z + g``.

        ``homogeneous`` zeroes the wall temperatures for the duration, which
        drops ``g`` and leaves the linear part alone.
        """
        s = self.solver
        self.load(z)
        if homogeneous:
            s.ctx.bc_temp[:] = 0.0
        try:
            s.ctx.sweep(s.mom, s.vdf)
            self.sweeps += 1
            if s.ctx.mode == "onthefly":
                s.factorisation_count += s.ndir * s.n_tris
            compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                            s.integrals.int_tri, s.case.flow.cv, s.mom)
            if self.nwall:
                s.bcdata.update_wall_flux(s.vdf, s.ctx.cxv, s.ctx.cyv,
                                          s.ctx.domega,
                                          s.integrals.int_tri_fc, s.mesh)
        finally:
            s.ctx.bc_temp[:] = self.bc_temp
        return self.store()

    def rhs(self) -> np.ndarray:
        """``g = Phi(0)`` -- what the walls alone drive into the domain."""
        return self.apply(np.zeros(self.n))

    def matvec(self, z) -> np.ndarray:
        return z - self.apply(z, homogeneous=True)


# ---------------------------------------------------------------------------
# reduced angular quadrature
# ---------------------------------------------------------------------------
def coarse_velocity_mesh(npole: int, nazim: int, vg: float = 1.0) -> VelocityMesh:
    """A small ordinate set with the *exact* moments the diffusion limit needs.

    Gauss-Legendre in ``mu = cos(theta)`` and the midpoint rule in ``phi``, so
    that ``sum dOmega``, ``sum dOmega c_i`` and ``sum dOmega c_i c_j`` are
    exact for any ``npole >= 2``, ``nazim >= 4``.  Getting the second moment
    right is what makes the coarse operator share a diffusion limit with the
    fine one, and that is the whole reason it preconditions well.

    The fields are laid out like :class:`~pybte.velocity.VelocityMesh` so that
    the ordering pass and the operator builder can be reused unchanged.
    """
    mu, wmu = np.polynomial.legendre.leggauss(npole)
    sin_the = np.sqrt(1.0 - mu * mu)
    the = np.arccos(mu)
    wthe = wmu / sin_the                       # so that sin(the)*wthe == wmu
    phi = (np.arange(nazim) + 0.5) * (2.0 * PI / nazim)
    wphi = np.full(nazim, 2.0 * PI / nazim)
    domega = (sin_the * wthe)[:, None] * wphi[None, :]
    cx = np.repeat((vg * mu)[:, None], nazim, axis=1)
    cy = (vg * sin_the)[:, None] * np.cos(phi)[None, :]
    return VelocityMesh(the=the, wthe=wthe, phi=phi, wphi=wphi,
                        domega=domega, cx=cx, cy=cy)


# ---------------------------------------------------------------------------
# the explicit response operator
# ---------------------------------------------------------------------------
def condensed_matrix(solver, npole: int, nazim: int, with_flux: bool,
                     blocksize: int = 32, dtype=np.float32):
    """``I - G`` written out as a dense matrix on a reduced angular set.

    Building it costs one propagation per unknown *per coarse direction*, which
    is why the angular set is coarse: the fine 200-ordinate problem would cost
    twenty times as much for a preconditioner that is no better.  What the
    coarse set has to get right is the second angular moment, because that is
    what fixes the diffusion limit the two operators have to share; see
    :func:`coarse_velocity_mesh`.

    ``with_flux`` decides whether the heat flux is carried as an unknown.
    Dropping it shrinks the matrix threefold in each direction, and it is only
    worth carrying when normal scattering is strong enough to feed ``q`` back
    into the source.

    Returns ``(matrix, index, ndir)``; ``index`` picks the rows of the
    condensed state the matrix corresponds to, and ``ndir`` is how many
    ordinates it was built on.
    """
    s = solver
    c = s.case
    nd, nt = s.ndof, s.n_tris
    nmom = nd * nt
    wall_faces = np.array(
        [f for f in range(s.mesh.n_faces)
         if s.mesh.face_bc[f] >= 0
         and s.bcdata.bc_type[s.mesh.face_bc[f]] == BC_NONTHERMALISING],
        dtype=np.int32)
    nwf = wall_faces.size
    nwall = nwf * nd

    wall_of_face = np.zeros(s.mesh.n_faces, dtype=np.int32)
    wall_of_face[wall_faces] = np.arange(nwf, dtype=np.int32)
    wall_tri = np.empty(nwf, dtype=np.int32)
    wall_lfc = np.empty(nwf, dtype=np.int32)
    for jf, f in enumerate(wall_faces):
        side = 0 if s.mesh.face_tri[f, 0] >= 0 else 1
        wall_tri[jf] = s.mesh.face_tri[f, side]
        wall_lfc[jf] = s.mesh.face_lfc[f, side]

    vel = coarse_velocity_mesh(npole, nazim, c.flow.vg)
    order = np.ascontiguousarray(build_sweep_order(s.mesh, vel).order,
                                 dtype=np.int32)
    cxv, cyv, domega = (np.ascontiguousarray(a) for a in vel.flat())
    ndir = cxv.size

    lu = np.empty((ndir, nt, nd, nd))
    piv = np.empty((ndir, nt, nd), dtype=np.int32)
    bad = _kernels.build_operators(order, cxv, cyv, 1.0 / c.tau_c,
                                   s.ctx.mass, s.ctx.gx, s.ctx.gy,
                                   s.ctx.fcm, s.ctx.nx, s.ctx.ny, lu, piv)
    if bad:
        raise np.linalg.LinAlgError(f"{bad} coarse element operators are singular")

    # the denominator of Calculate_FLUX_WALL, on this quadrature
    inv_wall_norm = np.empty(nwf)
    for jf in range(nwf):
        u = -cxv * s.ctx.nx[wall_tri[jf], wall_lfc[jf]] \
            - cyv * s.ctx.ny[wall_tri[jf], wall_lfc[jf]]
        inc = u > 0.0
        inv_wall_norm[jf] = 1.0 / float(np.sum(-u[inc] * domega[inc]))

    # moments -> scattering source: Ts enters with 1/tau_R + 1/tau_N, the flux
    # with 1/tau_N alone; the outgoing moments carry the 1/Cv of Ts
    cv, vg = c.flow.cv, c.flow.vg
    a_ts = cv / (4.0 * PI) * (1.0 / c.flow.tau_r + 1.0 / c.flow.tau_n)
    a_q = 3.0 / (4.0 * PI * c.flow.tau_n * vg * vg)
    if with_flux:
        row_scale = np.array([1.0 / cv, 1.0, 1.0])
        col_scale = np.array([a_ts, a_q, a_q])
        index = np.arange(3 * nmom + nwall)
    else:
        row_scale = np.array([1.0 / cv])
        col_scale = np.array([a_ts])
        index = np.concatenate([np.arange(nmom),
                                np.arange(3 * nmom, 3 * nmom + nwall)])
    n = row_scale.size * nmom + nwall
    out = np.zeros((n, n), dtype=dtype)
    out[np.diag_indices(n)] = 1.0
    _kernels.response_matrix(
        order, cxv, cyv, domega, lu, piv, s.ctx.mass, s.ctx.ttfc,
        s.ctx.nx, s.ctx.ny, s.ctx.tri_faces, s.ctx.face_bc, s.ctx.neighbour,
        s.ctx.periodic_tri, s.ctx.bc_type, wall_of_face, wall_tri, wall_lfc,
        np.ascontiguousarray(s.integrals.int_tri_fc), inv_wall_norm,
        nmom, blocksize, row_scale, col_scale, out)
    return out, index, ndir


# ---------------------------------------------------------------------------
# Krylov
# ---------------------------------------------------------------------------
def gmres(matvec, b, tol, maxiter, restart=120, precond=None, x0=None,
          callback=None):
    """Right-preconditioned restarted GMRES.

    Right preconditioning keeps the Arnoldi residual equal to the *true*
    residual of ``A x = b``, so the stopping test means what it says however
    good or bad the preconditioner is -- and lets a preconditioner be built
    halfway through a solve and applied to the iterate already reached.

    ``maxiter`` counts matrix-vector products, including the one each restart
    spends re-forming the residual, because here a product is a transport
    sweep and the caller is budgeting sweeps.  ``restart`` bounds the Krylov
    basis, and so the memory: without it a caller that passes ``tmax`` as the
    iteration limit asks for a basis of ``tmax`` vectors.

    Returns ``(x, residuals, converged)``; ``residuals[k]`` is
    ``||b - A x_k|| / ||b||`` and includes the starting point.
    """
    n = b.size
    bnorm = float(np.linalg.norm(b))
    if bnorm == 0.0:
        return np.zeros(n), [0.0], True
    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)
    seeded = x0 is not None
    m = max(1, min(int(restart), int(maxiter)))
    V = np.empty((m + 1, n))
    Z = np.empty((m, n))
    H = np.zeros((m + 1, m))
    cs = np.zeros(m)
    sn = np.zeros(m)
    g = np.zeros(m + 1)

    res: list[float] = []
    used = 0
    converged = False
    while True:
        if seeded:
            r = b - matvec(x)
            used += 1
        else:
            r = b.copy()
            seeded = True
        beta = float(np.linalg.norm(r))
        if not res:
            res.append(beta / bnorm)
        if beta / bnorm <= tol:
            converged = True
            break
        room = min(m, maxiter - used)
        if room <= 0:
            break

        H[:] = 0.0
        g[:] = 0.0
        g[0] = beta
        V[0] = r / beta
        k = 0
        while k < room:
            Z[k] = precond(V[k]) if precond is not None else V[k]
            w = matvec(Z[k])
            used += 1
            for i in range(k + 1):                  # modified Gram-Schmidt
                H[i, k] = float(V[i] @ w)
                w -= H[i, k] * V[i]
            H[k + 1, k] = float(np.linalg.norm(w))
            breakdown = H[k + 1, k] <= 0.0
            if not breakdown:
                V[k + 1] = w / H[k + 1, k]
            for i in range(k):                      # apply past rotations
                t = cs[i] * H[i, k] + sn[i] * H[i + 1, k]
                H[i + 1, k] = -sn[i] * H[i, k] + cs[i] * H[i + 1, k]
                H[i, k] = t
            d = np.hypot(H[k, k], H[k + 1, k])
            if d == 0.0:
                cs[k], sn[k] = 1.0, 0.0
            else:
                cs[k], sn[k] = H[k, k] / d, H[k + 1, k] / d
            H[k, k] = cs[k] * H[k, k] + sn[k] * H[k + 1, k]
            H[k + 1, k] = 0.0
            g[k + 1] = -sn[k] * g[k]
            g[k] = cs[k] * g[k]
            k += 1
            res.append(abs(g[k]) / bnorm)
            if callback is not None:
                callback(len(res) - 1, res[-1])
            if res[-1] <= tol:
                converged = True
                break
            if breakdown:        # the Krylov space is exhausted: x_k is exact
                converged = True
                break

        y = np.linalg.solve(np.triu(H[:k, :k]), g[:k])
        for i in range(k):
            x += y[i] * Z[i]
        if converged or used >= maxiter:
            break
    return x, res, converged


# ---------------------------------------------------------------------------
def estimate_krylov_iterations(case, mesh) -> float:
    """How many sweeps an unpreconditioned Krylov solve is likely to need.

    In the diffusion limit source iteration contracts by
    ``rho ~ 1 - (pi tau_C Vg / L)^2 / 3`` on the slowest spatial mode, so it
    needs ``O((L / tau_C Vg)^2)`` sweeps and a Krylov method the square root of
    that.  The prefactor is fitted to the shipped cavity and is only ever used
    to decide whether building a preconditioner will pay for itself -- if the
    guess is wrong the solve notices and switches anyway.
    """
    length = float(np.sqrt(mesh.tri_area.sum()))
    mfp = case.tau_c * case.flow.vg
    return 2.2 * length / max(mfp, 1e-300)


def flux_feedback_strength(case, mesh) -> float:
    """How strongly the heat flux feeds back into the scattering source.

    Normal scattering conserves momentum, so it returns ``q`` to the source
    with weight ``3 q.c / (4 pi tau_N Vg^2)``; against a diffusive
    ``q ~ Cv Vg^2 tau_R grad(T) / 3`` that is ``tau_C tau_R / (tau_N L)``
    relative to the temperature drive.  Below about ``1e-4`` the flux blocks of
    the preconditioner are dead weight.
    """
    length = float(np.sqrt(mesh.tri_area.sum()))
    return case.tau_c * case.flow.tau_r / (case.flow.tau_n * length)
