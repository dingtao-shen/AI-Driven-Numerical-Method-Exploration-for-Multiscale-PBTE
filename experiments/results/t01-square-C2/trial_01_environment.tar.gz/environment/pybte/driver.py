"""The outer iteration -- the port of ``Callaway_2D_2V_DG.f90``.

The Fortran's loop is::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

and :meth:`Solver.run_source_iteration` still is exactly that.  It is not what
:meth:`Solver.run` does, because that loop is Richardson iteration on a linear
system whose spectral radius goes to 1 as the medium becomes optically thick:
at ``tau_R = 1e-3`` it needs of order ``10^6`` sweeps, and long before that it
starts reporting a step size of ``1e-8`` while still being 90% away from its
own fixed point.

:meth:`Solver.run` solves that system instead of iterating it.  See
:mod:`pybte.accel` for what the system is; the short version is that a sweep
is an exact transport solve, so an outer iteration is an affine map on the
moments alone and the fixed point is the solution of ``(I - G) z = g``.  GMRES
gets it in tens of sweeps rather than millions, and -- the point of the
exercise -- it converges on the residual of the real system, so the answer is
the fixed point rather than wherever the iteration happened to stall.

What is added around it: an explicit restart contract, an optional true
residual, and a :class:`~pybte.io_output.RunRecord` complete enough that a
verifier never has to parse stdout.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np
from scipy.linalg import lu_factor, lu_solve

from .accel import (CondensedSystem, condensed_matrix,
                    estimate_krylov_iterations, flux_feedback_strength, gmres)
from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from ._numba import HAVE_NUMBA
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/F1_1e-3.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)
        #: element operators factorised for the preconditioner's coarse
        #: angular set; a different operator family, counted separately
        self.coarse_factorisation_count = 0

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        # np.array, not ascontiguousarray: the transposed view of a bytes
        # buffer can already be contiguous, and ascontiguousarray would then
        # hand back the read-only original, which the sweep cannot write to
        self.vdf = np.array(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris,
                                                    self.ndof), dtype=float)
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Solve the discrete transport system, to its own residual.

        The work is a Krylov solve of ``(I - G) z = g`` -- the fixed-point
        equation of the source iteration -- with one transport sweep per
        matrix-vector product.  Optically thick cases get a preconditioner
        built by writing out ``G`` on a reduced angular quadrature; see
        :mod:`pybte.accel`.

        ``record.iterations`` counts transport sweeps, so it is directly
        comparable with the source iteration's step count.
        """
        c = self.case
        p = c.performance
        if (p.scheme == "source" or self.order.cycles_broken.any()
                or c.iteration.tmax < 3):
            # A broken cycle lags an inflow to the previous iterate, so the
            # sweep is no longer an exact solve and the outer iteration is no
            # longer a map on the moments alone.  Under three sweeps there is
            # no room for one to evaluate the drive and one to leave VDF
            # consistent with the answer.  Either way, fall back.
            return self.run_source_iteration(callback=callback,
                                             progress_every=progress_every)

        t0 = time.perf_counter()
        system = CondensedSystem(self)
        tol = float(p.accel_tol)
        tmax = c.iteration.tmax

        def budget():
            """Sweeps left, keeping one back for the final consistency sweep."""
            return tmax - 1 - system.sweeps

        x0 = None
        if self.restart_info.get("enabled"):
            compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv,
                            self.ctx.domega, self.integrals.int_tri,
                            c.flow.cv, self.mom)
            if system.nwall:
                self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv,
                                             self.ctx.cyv, self.ctx.domega,
                                             self.integrals.int_tri_fc, self.mesh)
            x0 = system.store()

        g = system.rhs()

        def report(k, res):
            if progress_every and k % progress_every == 0:
                print(f"  sweep {system.sweeps:8d}  residual {res:.6e}", flush=True)
            if callback is not None:
                callback(system.sweeps, res, self)

        def solve(precond, cap, start):
            room = budget() - (1 if start is not None else 0)
            if room <= 0:
                return start, [], False
            return gmres(system.matvec, g, tol, min(room, cap),
                         restart=p.accel_restart, precond=precond,
                         x0=start, callback=report)

        # Building the preconditioner costs a few tens of sweeps, so it only
        # pays on problems that would need more than that without one.  The
        # estimate is a guess, and it is only ever used to skip an attempt that
        # would have been wasted: if it says easy and it is wrong, the plain
        # attempt hits its cap and the preconditioner gets built anyway.
        estimate = estimate_krylov_iterations(c, self.mesh)
        cap = max(int(4.0 * estimate), 40)
        preconditionable = p.scheme == "krylov" and budget() > 2 * p.accel_switch
        skip_plain = preconditionable and estimate > p.accel_switch

        prec = None
        residuals: list[float] = []
        z = x0
        converged = False
        if not skip_plain:
            z, res, converged = solve(None, cap if preconditionable else tmax, z)
            residuals += res
        if not converged and preconditionable:
            prec = self._build_preconditioner(probe=g)
            z, res, converged = solve(prec, tmax, z)
            residuals += res

        if z is None:
            z = np.zeros(system.n)

        # leave VDF, the moments and the wall emission mutually consistent
        z_out = system.apply(z)
        step = float(np.linalg.norm(z_out - z) / max(np.linalg.norm(z_out), 1e-300))
        residuals.append(step)
        self.t_old[:] = self.mom.temp

        wall = time.perf_counter() - t0
        true_res = None
        if c.iteration.true_residual:
            true_res = [np.nan] * (len(residuals) - 1)
            true_res.append(self.ctx.true_residual(self.mom, self.vdf))
        masses = [self.mom.mass]
        return self._record(system.sweeps, converged, residuals, masses,
                            true_res, wall, scheme="KRYLOV",
                            extra={"krylov_preconditioner":
                                   "none" if prec is None else prec.description,
                                   "condensed_unknowns": system.n})

    def _build_preconditioner(self, probe=None):
        """Factorised ``I - G`` on a reduced angular set, or ``None``.

        Two decisions are taken here.  The angular set is coarse because the
        cost is linear in the ordinate count while the quality is not: the
        coarse and fine operators agree in the diffusion limit as soon as the
        quadrature integrates ``c_i c_j`` exactly, and that is what the slow
        modes live in.  The heat-flux blocks are dropped when normal scattering
        is too weak to feed ``q`` back into the source, which shrinks the
        factorisation by a factor of nine on every case where ``tau_N`` is
        large.

        Anything that goes wrong here returns ``None`` rather than raising:
        the preconditioner is an optimisation, and a run that falls back to
        the unpreconditioned solve is slow, not wrong.  ``probe`` is a vector
        to test the factorisation on.
        """
        p = self.case.performance
        if not HAVE_NUMBA:
            # the response kernel would run as interpreted Python, which costs
            # far more than the sweeps it saves
            return None
        with_flux = flux_feedback_strength(self.case, self.mesh) > p.accel_flux_cutoff
        npole, nazim = p.accel_npole, p.accel_nazim
        if not with_flux:
            # without the flux blocks what is left is a diffusion-limit object,
            # and eight ordinates already integrate the second moment exactly
            npole, nazim = max(2, npole // 2), max(4, nazim // 2)
        try:
            block, idx, ndir = condensed_matrix(
                self, npole, nazim, with_flux, blocksize=p.accel_block,
                dtype=np.float32 if p.accel_single else np.float64)
            self.coarse_factorisation_count += ndir * self.n_tris
            dtype = block.dtype
            lu, piv = lu_factor(block, overwrite_a=True, check_finite=False)
        except (np.linalg.LinAlgError, ValueError) as exc:
            warnings.warn(f"no preconditioner: {exc}; solving unpreconditioned")
            return None

        def apply(r):
            out = r.copy()
            out[idx] = lu_solve((lu, piv), r[idx].astype(dtype),
                                check_finite=False)
            return out

        if probe is not None and not np.all(np.isfinite(apply(probe))):
            warnings.warn("the condensed operator factorised to a singular or "
                          "overflowing preconditioner; solving unpreconditioned")
            return None

        apply.description = (f"{ndir}-ordinate condensed operator, "
                             f"{idx.size} unknowns, "
                             f"{'with' if with_flux else 'without'} flux blocks")
        return apply

    def run_source_iteration(self, callback=None,
                             progress_every: int = 0) -> RunRecord:
        """The Fortran's loop, verbatim: sweep, moments, ``Calculate_Residual_T``.

        Kept because it is the reference behaviour, and because a mesh whose
        sweep graph has a cycle has no exact sweep for :meth:`run` to condense.
        """
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "coarse_factorisations": self.coarse_factorisation_count,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
