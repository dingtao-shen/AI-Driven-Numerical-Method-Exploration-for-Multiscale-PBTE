"""A right-preconditioned GMRES, specialised for the moment fixed point.

Nothing exotic -- Arnoldi with classical Gram-Schmidt applied twice (as
stable as modified Gram-Schmidt, but a pair of BLAS-2 calls instead of a
Python loop) and Givens rotations for the least-squares problem.  It is here
rather than taken from :mod:`scipy.sparse.linalg` for two reasons:

* every matrix-vector product is a transport sweep, so the per-iteration
  Python overhead of ``scipy``'s ``LinearOperator`` wrapper is a measurable
  fraction of the run;
* the stopping rule has to be stated in terms of the *solution* norm rather
  than the right-hand side.  ``(I - G)`` has a condition number of order
  ``(L/tau_C)^2`` -- ``1e6`` on the stiffest shipped case -- so a residual
  small relative to ``b`` says nothing about the error.  The caller supplies
  an absolute tolerance derived from a preconditioned estimate of the
  solution instead.
"""
from __future__ import annotations

import numpy as np

__all__ = ["gmres_right"]


#: a cycle is abandoned once ``STAG_WINDOW`` iterations have failed to cut the
#: residual by ``STAG_FACTOR``; without it an unreachable tolerance -- and
#: ``(I - G)`` can be conditioned badly enough that round-off puts one out of
#: reach -- would burn the whole iteration budget at the round-off floor
STAG_WINDOW = 60
STAG_FACTOR = 0.9


def gmres_right(matvec, b, precond, x0=None, tol=1e-12, maxiter=200,
                restart=None, callback=None):
    """Solve ``A x = b`` with ``A`` given by ``matvec`` and right
    preconditioner ``precond``.

    Returns ``(x, resid, history)`` where ``resid`` is the final residual norm
    estimate and ``history`` the norm after every iteration.  ``tol`` is
    absolute.
    """
    n = b.size
    restart = int(restart or maxiter)
    x = np.zeros(n) if x0 is None else x0.copy()
    history: list[float] = []
    total = 0

    while total < maxiter:
        r = b - matvec(x) if total or x0 is not None else b.copy()
        beta = float(np.linalg.norm(r))
        if beta <= tol:
            return x, beta, history
        m = min(restart, maxiter - total)
        v = np.empty((m + 1, n))
        z = np.empty((m, n))
        h = np.zeros((m + 1, m))
        cs = np.zeros(m)
        sn = np.zeros(m)
        g = np.zeros(m + 1)
        g[0] = beta
        v[0] = r / beta
        k = 0
        for j in range(m):
            z[j] = precond(v[j])
            w = matvec(z[j])
            total += 1
            # classical Gram-Schmidt, twice
            vj = v[:j + 1]
            c1 = vj @ w
            w -= c1 @ vj
            c2 = vj @ w
            w -= c2 @ vj
            h[:j + 1, j] = c1 + c2
            hn = float(np.linalg.norm(w))
            h[j + 1, j] = hn
            # apply the previous rotations to the new column
            for i in range(j):
                t = cs[i] * h[i, j] + sn[i] * h[i + 1, j]
                h[i + 1, j] = -sn[i] * h[i, j] + cs[i] * h[i + 1, j]
                h[i, j] = t
            d = np.hypot(h[j, j], h[j + 1, j])
            if d == 0.0:
                cs[j], sn[j] = 1.0, 0.0
            else:
                cs[j], sn[j] = h[j, j] / d, h[j + 1, j] / d
            h[j, j] = cs[j] * h[j, j] + sn[j] * h[j + 1, j]
            h[j + 1, j] = 0.0
            g[j + 1] = -sn[j] * g[j]
            g[j] = cs[j] * g[j]
            k = j + 1
            res = abs(g[j + 1])
            history.append(res)
            if callback is not None:
                callback(total, res)
            if res <= tol or hn <= 1e-300:
                break
            if (len(history) > STAG_WINDOW
                    and res > STAG_FACTOR * history[-1 - STAG_WINDOW]):
                break
            v[j + 1] = w / hn
        y = np.linalg.solve(np.triu(h[:k, :k]), g[:k])
        x += y @ z[:k]
        res = float(abs(g[k]))
        if res <= tol:
            return x, res, history
        if (len(history) > STAG_WINDOW
                and res > STAG_FACTOR * history[-1 - STAG_WINDOW]):
            return x, res, history          # stalled; the caller decides
    return x, float(history[-1]) if history else float("nan"), history
