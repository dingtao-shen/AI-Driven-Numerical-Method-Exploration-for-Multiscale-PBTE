"""Synthetic acceleration -- the low-order operators that make the source
iteration converge at a rate independent of the two relaxation times.

Why it is needed
----------------
Source iteration transports one collision mean free path per sweep, and the
Callaway collision operator conserves energy exactly, so its contraction
factor is ``1 - O(tau_C^2/L^2)``: at ``tau_R = 1e-3`` the shipped solver needs
of order a million sweeps to actually reach its fixed point.  The slow part of
the iteration error is the *fluid* limit of the transport operator, and it can
be removed by solving a cheap elliptic problem once per Krylov step.

The low-order model
-------------------
Take the zeroth, first and second angular moments of the discrete transport
equation after a sweep.  With ``phi = int f dOmega``, ``q = int c f dOmega``
and ``r = u - (G u + g)`` the residual of the moment fixed point, the first two
are exact:

    div q'              = r_phi / tau_C
    div P' + q'/tau_C   = q / tau_N

and the third, closed by the ``P1`` third moment, gives

    P' = (vg^2/3) phi I - nu (div q' I + grad q' + grad q'^T),  nu = tau_C vg^2/5.

Two slow families come out of that, and both have to be treated:

**the energy mode** -- eliminate ``q'`` through the isotropic part of ``P'``
and use ``1/tau_C - 1/tau_N = 1/tau_R`` (normal collisions conserve momentum,
so only the resistive channel damps the flux).  What is left is diffusion,

    -div(D grad phi') = r_phi / tau_C,   D = vg^2 tau_R / 3,   q' = -D grad phi'

with the Marshak conditions of the two wall types: ``D dphi'/dn +
(vg/2) phi' = 0`` at a thermalising wall, whose incoming half-space is
prescribed so its *error* vanishes, and ``D dphi'/dn = 0`` at a diffusely
reflecting one, which re-emits exactly what it receives.  This is textbook
DSA and it is what carries the diffusive and ballistic cases.

**the vorticity mode** -- when the normal channel dominates (``tau_N << tau_R``)
the slowest eigenvector of ``G`` is not the energy mode at all but a nearly
divergence-free ``q``, damped only by the resistive channel and by the
Guyer-Krumhansl viscosity.  For it the model above says nothing: it predicts
``q' = -D grad phi'``, a pure gradient.  Keeping the viscous part of ``P'``
instead gives, for a transverse ``q``,

    (1/tau_C - nu lap) q' = q / tau_N   =>   (I - G) q = tau_C (1/tau_R - nu lap) q

so the block that has to be inverted is a vector Helmholtz problem,

    e_q = (1/tau_R - nu lap)^-1 (1/tau_C - nu lap) r_q.

Its amplification is ``tau_R/tau_C`` at long wavelengths and falls to one at
the grid scale -- exactly the spread that a scalar factor cannot reproduce and
that made a constant ``tau_R/tau_N`` rescaling of ``r_q`` *worse* than leaving
it alone.  In the diffusive limit ``tau_C -> tau_R`` and it collapses to the
identity, so it is built only when ``tau_N`` is comparable with ``tau_R`` or
smaller.

Discretisation
--------------
Symmetric interior penalty on the *same* nodal DG space as the transport
solve, assembled from the tensors :mod:`pybte.integration` already builds, so
no new quadrature is introduced.  Each ``ndof_tri * n_tris`` matrix is sparse
and is LU-factorised once per case.
"""
from __future__ import annotations

import numpy as np

from .constants import BC_NONTHERMALISING, BC_THERMALISING, PI

__all__ = ["DiffusionOperator"]

#: interior-penalty weight; sigma_F = ALPHA * kappa * (deg+1)^2 / h_F
ALPHA = 4.0

#: build the vector-Helmholtz block only when the normal channel actually
#: competes with the resistive one; below this ratio it is the identity to
#: within its own truncation error
VISCOUS_THRESHOLD = 1.05

#: wall damping of the tangential flux in the viscous block, in units of vg;
#: a diffusely reflecting or thermalising wall re-emits isotropically and so
#: destroys the tangential momentum that reaches it
VISCOUS_ROBIN = 0.5


class _SIP:
    """Assembly of a symmetric-interior-penalty Laplacian on the DG space."""

    def __init__(self, mesh, integrals, case, bc_type):
        nd = case.ndof_tri
        nt = mesh.n_tris
        self.nd, self.nt = nd, nt
        self.deg = case.dg.deg
        self.vg = case.flow.vg

        self.mass = np.ascontiguousarray(
            np.transpose(integrals.int_tri_tri, (2, 0, 1)))
        ax = np.transpose(integrals.int_tri_tri_x, (0, 2, 1))  # int phi_m dphi_l/dx
        ay = np.transpose(integrals.int_tri_tri_y, (0, 2, 1))
        minv = np.linalg.inv(self.mass)
        self.dx = minv @ ax          # dphi_l/dx = sum_k dx[k, l] phi_k
        self.dy = minv @ ay

        fcm = integrals.int_tri_fc
        ttfc = integrals.int_tri_tri_fc
        nx = mesh.tri_normal[:, :, 0]
        ny = mesh.tri_normal[:, :, 1]
        bc_type = np.asarray(bc_type)

        # -- interior faces: geometry-only pieces of the SIP form ----------
        f = np.flatnonzero(mesh.face_bc < 0)
        self.ik1 = k1 = mesh.face_tri[f, 0]
        self.ik2 = k2 = mesh.face_tri[f, 1]
        l1 = mesh.face_lfc[f, 0]
        l2 = mesh.face_lfc[f, 1]
        n0 = nx[k1, l1][:, None, None]
        n1 = ny[k1, l1][:, None, None]
        ndp = n0 * self.dx[k1] + n1 * self.dy[k1]
        ndm = n0 * self.dx[k2] + n1 * self.dy[k2]
        self.fpp = fcm[k1, l1]
        self.fmm = fcm[k2, l2]
        self.fpm = ttfc[k1, l1]
        self.fmp = ttfc[k2, l2]
        self.gp = self.fpp @ ndp
        self.gpm = self.fpm @ ndm
        self.gm = self.fmm @ ndm
        self.gmp = self.fmp @ ndp
        self.hf = (np.minimum(mesh.tri_area[k1], mesh.tri_area[k2])
                   / mesh.face_len[f])

        # -- boundary faces ------------------------------------------------
        b = np.flatnonzero(mesh.face_bc >= 0)
        side = (mesh.face_tri[b, 0] < 0).astype(np.int64)
        self.bk = mesh.face_tri[b, side]
        self.bl = mesh.face_lfc[b, side]
        self.btyp = bc_type[mesh.face_bc[b]]
        self.btrace = fcm[self.bk, self.bl]
        self.bfaces = b
        self.has_thermalising = bool(np.any(bc_type == BC_THERMALISING))

    # ------------------------------------------------------------------
    def matrix(self, kappa: float, robin: float = 0.0, mass_coeff: float = 0.0,
               alpha: float = ALPHA, robin_all: bool = False):
        """``mass_coeff * M + kappa * K_SIP`` with a Robin term on the
        thermalising walls (natural, i.e. Neumann, on the others)."""
        import scipy.sparse as sp

        nd, nt = self.nd, self.nt
        tp = lambda a: np.transpose(a, (0, 2, 1))
        blocks = []
        vol = kappa * (tp(self.dx) @ self.mass @ self.dx
                       + tp(self.dy) @ self.mass @ self.dy)
        if mass_coeff:
            vol = vol + mass_coeff * self.mass
        blocks.append((np.arange(nt), np.arange(nt), vol))
        if self.ik1.size:
            sig = (alpha * kappa * (self.deg + 1) ** 2 / self.hf)[:, None, None]
            h = 0.5 * kappa
            blocks += [
                (self.ik1, self.ik1, -h * (self.gp + tp(self.gp)) + sig * self.fpp),
                (self.ik1, self.ik2, -h * (self.gpm - tp(self.gmp)) - sig * self.fpm),
                (self.ik2, self.ik1, h * (self.gmp - tp(self.gpm)) - sig * self.fmp),
                (self.ik2, self.ik2, h * (self.gm + tp(self.gm)) + sig * self.fmm),
            ]
        if robin:
            m = (np.ones_like(self.btyp, dtype=bool) if robin_all
                 else self.btyp == BC_THERMALISING)
            if np.any(m):
                blocks.append((self.bk[m], self.bk[m], robin * self.btrace[m]))

        eye = np.arange(nd)
        rows = np.concatenate([np.broadcast_to(
            (b[0][:, None] * nd + eye)[:, :, None], (b[0].size, nd, nd)).ravel()
            for b in blocks])
        cols = np.concatenate([np.broadcast_to(
            (b[1][:, None] * nd + eye)[:, None, :], (b[1].size, nd, nd)).ravel()
            for b in blocks])
        vals = np.concatenate([b[2].ravel() for b in blocks])
        a = sp.csr_matrix((vals, (rows, cols)), shape=(nd * nt, nd * nt))
        if not (robin and self.has_thermalising) and not mass_coeff:
            a = a + sp.eye(nd * nt, format="csr") * (kappa * 1e-8)
        return a.tocsc()


class DiffusionOperator:
    """The synthetic-acceleration solve: ``r -> (I - G)^-1 r``, approximately."""

    def __init__(self, mesh, integrals, case, bc_type, alpha: float = ALPHA):
        import scipy.sparse.linalg as spla

        vg = case.flow.vg
        self.nd = nd = case.ndof_tri
        self.nt = nt = mesh.n_tris
        self.cv = case.flow.cv
        self.tau_c = tau_c = case.tau_c
        self.tau_r = tau_r = case.flow.tau_r
        self.D = D = vg * vg * tau_r / 3.0

        sip = _SIP(mesh, integrals, case, bc_type)
        self.mass, self.dx, self.dy = sip.mass, sip.dx, sip.dy
        self.lu = spla.splu(sip.matrix(D, robin=0.5 * vg, alpha=alpha))

        # the vector-Helmholtz block, only where it is not the identity
        self.visc = None
        if tau_r / tau_c > VISCOUS_THRESHOLD:
            nu = tau_c * vg * vg / 5.0
            rb = VISCOUS_ROBIN * vg
            self.visc = spla.splu(sip.matrix(nu, mass_coeff=1.0 / tau_r,
                                             alpha=alpha, robin=rb,
                                             robin_all=True))
            self.visc_num = sip.matrix(nu, mass_coeff=1.0 / tau_c, alpha=alpha,
                                       robin=rb, robin_all=True)

        # diffusely reflecting walls: their emission follows the local phi
        m = sip.btyp == BC_NONTHERMALISING
        self.wall_faces = sip.bfaces[m]
        self.wall_tri = sip.bk[m]
        self.wall_trace = sip.btrace[m]
        self.has_wall = bool(self.wall_faces.size)

    # ------------------------------------------------------------------
    def solve(self, r_phi: np.ndarray) -> np.ndarray:
        """``phi'`` from ``-div(D grad phi') = r_phi / tau_C``; (nt, nd)."""
        rp = np.ascontiguousarray(r_phi.T)
        rhs = (self.mass @ rp[:, :, None])[:, :, 0] / self.tau_c
        return self.lu.solve(rhs.ravel()).reshape(self.nt, self.nd)

    def gradient(self, e: np.ndarray):
        """``grad phi'`` in the same DG space; ``e`` is (nt, nd)."""
        return ((self.dx @ e[:, :, None])[:, :, 0],
                (self.dy @ e[:, :, None])[:, :, 0])

    def flux(self, r_q: np.ndarray) -> np.ndarray:
        """``(1/tau_R - nu lap)^-1 (1/tau_C - nu lap) r_q``; ``r_q`` is
        (nt, nd), and the identity when the viscous block is switched off."""
        if self.visc is None:
            return r_q
        return self.visc.solve(self.visc_num @ r_q.ravel()).reshape(r_q.shape)

    def wall_emission(self, e: np.ndarray, out: np.ndarray) -> None:
        """Correction to ``FLUX_WALL``: a diffuse wall in local equilibrium
        emits ``phi/(4 pi)``, and ``FLUX_WALL`` stores ``-oint f_w phi_m ds``."""
        if not self.has_wall:
            return
        out[:] = (self.wall_trace @ e[self.wall_tri][:, :, None])[:, :, 0]
        out *= -1.0 / (4.0 * PI)
