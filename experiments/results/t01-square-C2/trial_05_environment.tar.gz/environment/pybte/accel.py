"""The accelerated outer solve.

Source iteration is a fixed point on a *small* vector.  A sweep reads the
distribution only through the three moment fields that build its scattering
source -- ``Cv*T``, ``qx``, ``qy``, one value per DG degree of freedom -- plus,
when a diffusely reflecting wall is present, that wall's emission.  Everything
else in the sweep is either fixed data or inflow from an element the same
sweep has already overwritten.  So with

    u = (phi, qx, qy, f_wall),      phi = Cv*T = int f dOmega

one sweep followed by the moment update is an *affine* map ``u -> G u + g``,
and the solver's fixed point is the solution of

    (I - G) u = g,      g = G 0 + g = one sweep from a zero source.

That system has 3*NDOF_TRI*N_TRIS + NDOF_TRI*N_WALLFACES unknowns -- 3720 for
the shipped case, against 240 000 for the distribution itself -- and each
matrix-vector product costs exactly one sweep.  Source iteration is plain
Richardson on it, which is why it crawls: ``||G|| -> 1`` as the medium becomes
optically thick, because the collision operator conserves energy exactly.
GMRES on the same operator, preconditioned by the diffusion limit
(:mod:`pybte.dsa`), converges in a few tens of sweeps at every stiffness.

What is *not* changed: the sweep, the moment reduction, the wall-flux update
and the discrete system they define.  The fixed point reached here is the same
one source iteration is walking towards, to round-off.
"""
from __future__ import annotations

import numpy as np

from .dsa import DiffusionOperator
from .krylov import gmres_right
from .moments import compute_moments

__all__ = ["MomentSystem"]


class MomentSystem:
    """The affine moment map ``u -> G u + g`` and its diffusion preconditioner."""

    def __init__(self, solver):
        self.solver = solver
        c = solver.case
        self.ctx = solver.ctx
        self.bcdata = solver.bcdata
        self.integrals = solver.integrals
        self.mesh = solver.mesh
        self.cv = c.flow.cv
        nd = self.nd = solver.ndof
        nt = self.nt = solver.n_tris
        self.nmom = nd * nt
        self.ndir_ntris = solver.ndir * nt

        self.prec = DiffusionOperator(solver.mesh, solver.integrals, c,
                                      solver.bcdata.bc_type)
        self.wall_faces = self.prec.wall_faces
        self.nfw = int(self.wall_faces.size) if self.bcdata.has_nonthermalising else 0
        self.size = 3 * self.nmom + self.nfw * nd

        from .moments import Moments
        self.mom_in = Moments.zeros(nd, nt)
        self.vdf = solver.vdf
        self.mom_out = solver.mom
        self._fw = np.zeros((max(self.nfw, 1), nd))
        self.sweeps = 0
        self._refactor = (self.ndir_ntris
                          if solver.ctx.mode == "onthefly" else 0)

    # -- packing -----------------------------------------------------------
    def _scatter(self, u: np.ndarray) -> None:
        nm, nd, nt = self.nmom, self.nd, self.nt
        m = self.mom_in
        np.multiply(u[:nm].reshape(nd, nt), 1.0 / self.cv, out=m.ts)
        m.qxs[:] = u[nm:2 * nm].reshape(nd, nt)
        m.qys[:] = u[2 * nm:3 * nm].reshape(nd, nt)
        if self.nfw:
            self.bcdata.flux_wall[self.wall_faces] = u[3 * nm:].reshape(self.nfw, nd)

    def _gather(self, out: np.ndarray) -> np.ndarray:
        nm = self.nmom
        m = self.mom_out
        np.multiply(m.ts.reshape(-1), self.cv, out=out[:nm])
        out[nm:2 * nm] = m.qxs.reshape(-1)
        out[2 * nm:3 * nm] = m.qys.reshape(-1)
        if self.nfw:
            out[3 * nm:] = self.bcdata.flux_wall[self.wall_faces].reshape(-1)
        return out

    # -- the affine map ----------------------------------------------------
    def apply(self, u: np.ndarray) -> np.ndarray:
        """One sweep plus the moment update: ``G u + g``."""
        self._scatter(u)
        self.ctx.sweep(self.mom_in, self.vdf)
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.cv, self.mom_out)
        if self.nfw:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.sweeps += 1
        self.solver.factorisation_count += self._refactor
        return self._gather(np.empty(self.size))

    def residual_of(self, u: np.ndarray) -> np.ndarray:
        """``g - (I - G) u = G u + g - u``; a sweep, and it leaves ``vdf``
        holding the distribution that goes with ``u``."""
        return self.apply(u) - u

    # -- preconditioner ----------------------------------------------------
    def precondition(self, r: np.ndarray) -> np.ndarray:
        nm, nd, nt = self.nmom, self.nd, self.nt
        p = self.prec
        e = p.solve(r[:nm].reshape(nd, nt))                  # (nt, nd)
        gx, gy = p.gradient(e)
        qx = p.flux(np.ascontiguousarray(r[nm:2 * nm].reshape(nd, nt).T))
        qy = p.flux(np.ascontiguousarray(r[2 * nm:3 * nm].reshape(nd, nt).T))
        out = np.empty_like(r)
        out[:nm] = r[:nm] + e.T.reshape(-1)
        out[nm:2 * nm] = (qx - p.D * gx).T.reshape(-1)
        out[2 * nm:3 * nm] = (qy - p.D * gy).T.reshape(-1)
        if self.nfw:
            self.prec.wall_emission(e, self._fw)
            out[3 * nm:] = r[3 * nm:] + self._fw.reshape(-1)
        return out

    # -- the solve ---------------------------------------------------------
    def state_from_vdf(self):
        """The moment vector of whatever is currently in ``vdf`` -- this is how
        a restart file becomes an initial guess for the Krylov solve."""
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.cv, self.mom_out)
        if self.nfw:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        return self._gather(np.empty(self.size))

    def solve(self, tol_rel: float = 1.0e-12, accept_rel: float = 1.0e-10,
              err_rel: float = 1.0e-9, maxiter: int = 400, restart: int = 200,
              x0=None, callback=None):
        """Drive ``(I - G) u = g`` to a *solution*-relative accuracy.

        Returns ``(u, history, converged)``.  On return ``vdf`` holds the
        distribution belonging to ``u`` and ``mom`` its moments, so the pair
        satisfies the discrete transport system to the residual reported.

        Two tolerances, because a residual is not an error: ``(I - G)`` has a
        condition number of order ``(L/tau_C)^2``, so the run is stopped on
        ``||r||`` *and* on the diffusion estimate ``||P^-1 r||`` of the
        distance to the fixed point, both relative to the size of the
        solution.
        """
        g = self.apply(np.zeros(self.size))
        scale = float(np.linalg.norm(self.precondition(g))) or 1.0
        tol = tol_rel * scale
        accept = accept_rel * scale
        matvec = lambda x: x - (self.apply(x) - g)
        hist: list[float] = [float(np.linalg.norm(g)) / scale]
        if callback is not None:
            callback(self.sweeps, hist[0])

        def cb(_it, res):
            hist.append(res / scale)
            if callback is not None:
                callback(self.sweeps, res / scale)

        u = x0
        converged = False
        stalled = False
        target = accept
        while True:
            left = maxiter - self.sweeps
            if left > 0 and not stalled:
                before = self.sweeps
                u, res, _ = gmres_right(matvec, g, self.precondition, x0=u,
                                        tol=target, maxiter=left,
                                        restart=min(restart, left), callback=cb)
                stalled = res > target and self.sweeps > before
            elif u is None:
                u = np.zeros(self.size)
            r = self.residual_of(u)          # leaves vdf/mom belonging to u
            rn = float(np.linalg.norm(r))
            err = float(np.linalg.norm(self.precondition(r))) / scale
            converged = rn <= accept and err <= err_rel
            if converged or self.sweeps >= maxiter or stalled:
                break
            # the residual is small but the error estimate is not: ask for more
            target = max(tol, min(target, rn) * 1.0e-2)
        return u, hist, converged
