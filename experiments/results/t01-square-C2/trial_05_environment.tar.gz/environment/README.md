# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, Krylov-accelerated source iteration for the
outer solve.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/F1_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte cases/F1_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

    while True:
        sweep()                 # exact transport solve, one direction at a time,
                                # in a topological order of the element graph
        compute_moments()       # T, qx, qy from the distribution
        if residual < tol: break

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

## How the outer solve works

A sweep reads the distribution only through the three moment fields that build
its scattering source -- `Cv*T`, `qx`, `qy`, one value per DG degree of freedom
-- plus, at a diffusely reflecting wall, that wall's emission.  So a sweep
followed by `compute_moments` is an **affine map on a small vector**,

    u = (phi, qx, qy, f_wall)        ->    G u + g,      phi = Cv*T,

and the solver's answer is the solution of `(I - G) u = g`: 3720 unknowns for
the shipped case, against 240 000 for the distribution itself.  The loop above
is plain Richardson on that system.  Because the Callaway collision operator
conserves energy exactly, `||G|| -> 1` as the medium becomes optically thick,
which is why the loop crawls -- and why its stopping rule stops being
informative long before it arrives: it measures the step between iterates, and
the remaining error is that step times `rho/(1-rho)`.

`Solver.run` runs GMRES on the same system instead (`pybte/accel.py`).  One
matrix-vector product is one sweep, so an iteration costs exactly what it cost
before; what changes is how many are needed.  The preconditioner
(`pybte/dsa.py`) is the fluid limit of the transport operator, discretised by
symmetric interior penalty on the same DG space and factorised once per case:

* a **diffusion** solve for the energy mode, `-div(D grad phi) = r/tau_C` with
  `D = Vg^2 tau_R/3` and the Marshak conditions of the two wall types.  This is
  classical DSA and it carries the diffusive and ballistic regimes;
* a **vector Helmholtz** solve for the vorticity mode,
  `(1/tau_R - nu lap)^-1 (1/tau_C - nu lap)` with the Guyer-Krumhansl viscosity
  `nu = tau_C Vg^2/5`.  When the normal channel dominates (`tau_N << tau_R`)
  the slowest eigenvector of `G` is not the energy mode at all but a nearly
  divergence-free heat flux, and diffusion alone does not see it.

Sweeps to convergence on the shipped cases, against the loop it replaces:

    case             source iteration   GMRES + fluid preconditioner
    F1_1_1                        33                             15
    F1_1e-1                      317                             13
    F1_1e-2                    16830                             21
    F1_1e-3               (>30000)                               33
    F1_10_1e-2                  2706                             64
    F2_1_1                        75                             19
    F2_1e-1                      643                             18
    F2_1e-2               (>30000)                               24
    F2_1e-3               (>30000)                               35
    F2_10_1e-2                  2444                             78

`Solver.run_source_iteration` keeps the original loop for comparison; `run`
falls back to it if a direction's element graph has a cycle, or if the Krylov
solve does not converge inside `TMAX`.

## Cases

Two boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the moment fixed point and its Krylov solve
      dsa.py        the fluid-limit preconditioner (diffusion + viscosity)
      krylov.py     right-preconditioned GMRES
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
