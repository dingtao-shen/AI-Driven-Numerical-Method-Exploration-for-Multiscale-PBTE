"""The transport sweep -- the port of ``Solvers.f90::DG_Solver_VDF``.

For each direction the elements are visited in ``TRI_ORDER`` and a dense
``NDOF_TRI x NDOF_TRI`` system is solved per element.  The inflow term reads
``VDF`` of the upwind neighbour *after* that neighbour has already been
overwritten in this same pass -- the sweep is Gauss-Seidel in the sweep
ordering, not Jacobi.  Reproducing that in-place semantics is mandatory: a
Jacobi port converges at a different rate and silently invalidates every
iteration count the benchmark grades on.

Two evaluation modes, numerically identical:

``precomputed``  ``A_SOL`` depends only on geometry, direction and ``TAU_C``,
                 all iteration-invariant, so it is LU-factorised once at setup
                 and the sweep is reduced to a triangular solve.  Costs
                 ``N_TRIS * NDIR * NDOF^2 * 8`` bytes (128 MB for the shipped
                 case at DEG=3).
``onthefly``     rebuild and re-factorise every element every iteration, as
                 the Fortran does.  Slower, constant memory.

``sweep_reference.py`` holds a third, pure-numpy/LAPACK implementation used
only to check the kernels.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import _ckernels, _kernels
from ._numba import HAVE_NUMBA, set_num_threads
from .constants import PI

__all__ = ["SweepContext"]


@dataclass
class SweepContext:
    """Contiguous arrays plus the factorised operators, ready for the kernels."""
    order: np.ndarray
    cxv: np.ndarray
    cyv: np.ndarray
    domega: np.ndarray
    cv: float
    vg: float
    tau_r: float
    tau_n: float
    tau_c: float
    mass: np.ndarray
    gx: np.ndarray
    gy: np.ndarray
    fcm: np.ndarray
    ttfc: np.ndarray
    nx: np.ndarray
    ny: np.ndarray
    tri_faces: np.ndarray
    face_bc: np.ndarray
    neighbour: np.ndarray
    periodic_tri: np.ndarray
    bc_type: np.ndarray
    bc_temp: np.ndarray
    flux_wall: np.ndarray
    mode: str = "precomputed"
    kernel: str = "numba"
    #: zeros in the shape of ``bc_temp``; see :meth:`sweep`
    _bc_temp_zero: np.ndarray | None = None
    lu: np.ndarray | None = field(default=None, repr=False)
    piv: np.ndarray | None = field(default=None, repr=False)
    #: (ndir, n_tris, ndof, ndof) inverses, for the compiled kernel
    inv: np.ndarray | None = field(default=None, repr=False)
    _qmass: np.ndarray | None = field(default=None, repr=False)
    _src3: np.ndarray | None = field(default=None, repr=False)
    sweep_count: int = 0

    # -- construction ------------------------------------------------------
    @classmethod
    def build(cls, case, mesh, integrals, vel, sweep_order, bcdata,
              precompute: bool | None = None, max_bytes: float = 8e9):
        cxv, cyv, domega = vel.flat()
        ctx = cls(
            order=np.ascontiguousarray(sweep_order.order, dtype=np.int32),
            cxv=np.ascontiguousarray(cxv), cyv=np.ascontiguousarray(cyv),
            domega=np.ascontiguousarray(domega),
            cv=float(case.flow.cv), vg=float(case.flow.vg),
            tau_r=float(case.flow.tau_r), tau_n=float(case.flow.tau_n),
            tau_c=float(case.tau_c),
            mass=np.ascontiguousarray(integrals.int_tri_tri),
            gx=np.ascontiguousarray(integrals.int_tri_tri_x),
            gy=np.ascontiguousarray(integrals.int_tri_tri_y),
            fcm=np.ascontiguousarray(integrals.int_tri_fc),
            ttfc=np.ascontiguousarray(integrals.int_tri_tri_fc),
            nx=np.ascontiguousarray(mesh.tri_normal[:, :, 0]),
            ny=np.ascontiguousarray(mesh.tri_normal[:, :, 1]),
            tri_faces=np.ascontiguousarray(mesh.tri_faces, dtype=np.int32),
            face_bc=np.ascontiguousarray(mesh.face_bc, dtype=np.int32),
            neighbour=np.ascontiguousarray(mesh.tri_neighbour, dtype=np.int32),
            periodic_tri=bcdata.periodic_tri,
            bc_type=bcdata.bc_type, bc_temp=bcdata.bc_temp,
            flux_wall=bcdata.flux_wall,
        )
        ctx._bc_temp_zero = np.zeros_like(ctx.bc_temp)
        set_num_threads(case.performance.threads)
        want = case.performance.kernel
        if want == "auto":
            want = "c" if _ckernels.HAVE_C else ("numba" if HAVE_NUMBA else "numpy")
        elif want == "c" and not _ckernels.HAVE_C:
            want = "numba" if HAVE_NUMBA else "numpy"
        elif want == "numba" and not HAVE_NUMBA:
            want = "numpy"
        ctx.kernel = want
        if want == "c":
            _ckernels.set_num_threads(case.performance.threads)

        if precompute is None:
            precompute = case.performance.precompute_inverse
        nbytes = ctx.operator_bytes(mesh.n_tris, case.ndof_tri)
        if precompute and nbytes <= max_bytes and ctx.kernel in ("numba", "c"):
            ctx.factorise()
        else:
            # the numpy reference kernel builds its own operators inline
            ctx.mode = "onthefly"
            if ctx.kernel == "c":
                ctx.kernel = "numba" if HAVE_NUMBA else "numpy"
        return ctx

    def operator_bytes(self, n_tris: int, ndof: int) -> float:
        return float(self.cxv.size) * n_tris * ndof * ndof * 8.0

    def factorise(self) -> None:
        """Prepare the element operators for every ``(direction, element)``.

        ``A_SOL`` depends only on geometry, direction and ``TAU_C`` -- all
        iteration-invariant -- so it is built once here rather than inside
        the sweep.  The compiled kernel stores the explicit inverse, which
        turns the per-element solve into a dense matrix-vector product; the
        jitted kernel stores the LU pair, as the Fortran's ``DGETRF`` /
        ``DGETRS`` do.
        """
        if self.kernel == "c":
            nd, _, n_tris = self.mass.shape
            self.inv = np.empty((self.cxv.size, n_tris, nd, nd))
            bad = _ckernels.build_inverse(
                self.cxv, self.cyv, 1.0 / self.tau_c, self.mass,
                self.gx, self.gy, self.fcm, self.nx, self.ny, self.inv)
            if bad:
                raise np.linalg.LinAlgError(
                    f"{bad} element operators are singular; check TAU_C "
                    "and the mesh")
            self.mode = "precomputed"
            return
        ndir = self.cxv.size
        nd, _, n_tris = self.mass.shape
        self.lu = np.empty((ndir, n_tris, nd, nd))
        self.piv = np.empty((ndir, n_tris, nd), dtype=np.int32)
        bad = _kernels.build_operators(
            self.order, self.cxv, self.cyv, 1.0 / self.tau_c,
            self.mass, self.gx, self.gy, self.fcm, self.nx, self.ny,
            self.lu, self.piv)
        if bad:
            raise np.linalg.LinAlgError(
                f"{bad} element operators are singular; check TAU_C and the mesh")
        self.mode = "precomputed"

    # -- the sweep ---------------------------------------------------------
    def sweep(self, mom, vdf, with_bc: bool = True) -> None:
        """One transport sweep, in place on ``vdf`` (ndir, n_tris, ndof).

        ``with_bc=False`` drops the *constant* part of the inflow -- the
        emission of the isothermal walls -- and keeps everything that depends
        on the current state (the scattering source, the interior and
        periodic inflow, the diffuse-wall emission).  That is exactly the
        splitting the outer solve needs: the sweep is affine in the moments,
        and its linear part is what a Krylov method multiplies by.
        """
        bc_temp = self.bc_temp if with_bc else self._bc_temp_zero
        if self.kernel == "c":
            sa, sb, sc = self.source_fields(mom)
            _ckernels.sweep(self, sa, sb, sc, bc_temp, vdf)
            self.sweep_count += 1
            return
        if self.kernel == "numpy":
            from .sweep_reference import sweep_reference

            sweep_reference(self, mom, vdf, bc_temp=bc_temp)
            self.sweep_count += 1
            return
        if self.mode == "precomputed":
            _kernels.sweep_precomputed(
                self.order, self.cxv, self.cyv, self.cv, self.vg,
                self.tau_r, self.tau_n, PI,
                self.mass, self.ttfc, self.nx, self.ny, self.tri_faces,
                self.face_bc, self.neighbour, self.periodic_tri,
                self.bc_type, bc_temp, self.flux_wall,
                mom.ts, mom.qxs, mom.qys, self.lu, self.piv, vdf)
        else:
            _kernels.sweep_onthefly(
                self.order, self.cxv, self.cyv, self.cv, self.vg,
                self.tau_r, self.tau_n, self.tau_c, PI,
                self.mass, self.gx, self.gy, self.fcm, self.ttfc,
                self.nx, self.ny, self.tri_faces, self.face_bc,
                self.neighbour, self.periodic_tri, self.bc_type,
                bc_temp, self.flux_wall, mom.ts, mom.qxs, mom.qys, vdf)
        self.sweep_count += 1

    # -- the scattering source, contracted -----------------------------------
    def source_fields(self, mom):
        """``(sa, sb, sc)``, each ``(n_tris, ndof)``: the scattering source
        with its angular dependence factored out.

        ``A_SRC(m) = sum_l INT_TRI_TRI(l,m,i) * (Cv T_l/(4 pi tau_C)
        + 3 (qx_l cx + qy_l cy)/(4 pi Vg^2 tau_N))`` is affine in ``(cx, cy)``
        for fixed moments, so the ``sum_l`` -- the only ``O(NDOF^2)`` part of
        the source -- can be done once for all directions instead of once per
        direction.
        """
        if self._qmass is None:
            # INT_NODFUNC_TRI_TRI as (i, m, l) with the (m, l) transposed:
            # the source contracts the *first* index of the mass matrix
            self._qmass = np.ascontiguousarray(np.transpose(self.mass, (2, 1, 0)))
            self._src3 = np.empty((self.mass.shape[2], self.mass.shape[0], 3))
        f0 = self.cv / (4.0 * PI * self.tau_c)
        f1 = 3.0 / (4.0 * PI * self.vg * self.vg * self.tau_n)
        s3 = self._src3
        np.multiply(mom.ts.T, f0, out=s3[:, :, 0])
        np.multiply(mom.qxs.T, f1, out=s3[:, :, 1])
        np.multiply(mom.qys.T, f1, out=s3[:, :, 2])
        out = np.ascontiguousarray(np.matmul(self._qmass, s3).transpose(2, 0, 1))
        return out[0], out[1], out[2]

    # -- true transport residual --------------------------------------------------------------
    def true_residual(self, mom, vdf) -> float:
        """``||A_SOL f - A_SRC|| / ||A_SRC||`` in the solid-angle-weighted
        L2 norm, evaluated at the current state with *no* sweep applied.

        This asks one question: do ``vdf`` and the moments in ``mom`` jointly
        satisfy the discrete transport system?  It is zero exactly at the
        fixed point of whichever scheme produced them.

        Read the two schemes differently.

        **CIS.**  The sweep leaves ``A f = b(moments_before)``, and ``mom`` is
        then recomputed from that ``f``, so what this measures is
        ``b(moments_before) - b(moments_after)`` -- the change in the moments,
        which is what ``residual_iterate`` already measures.  The two agree to
        within a normalisation (1.52e-06 vs 1.52e-06 on the truncated
        ``tau_R = 1e-3`` run).  **Neither reveals the error**: see
        ``RunRecord.error_estimate`` for that.
        """
        ndir = self.cxv.size
        num = np.zeros(ndir)
        den = np.zeros(ndir)
        _kernels.transport_residual(
            self.cxv, self.cyv, self.domega, self.cv, self.vg,
            self.tau_r, self.tau_n, self.tau_c, PI,
            self.mass, self.gx, self.gy, self.fcm, self.ttfc,
            self.nx, self.ny, self.tri_faces, self.face_bc, self.neighbour,
            self.periodic_tri, self.bc_type, self.bc_temp, self.flux_wall,
            mom.ts, mom.qxs, mom.qys, vdf, num, den)
        d = float(den.sum())
        if d <= 0.0:
            return float("nan")
        return float(np.sqrt(num.sum() / d))
