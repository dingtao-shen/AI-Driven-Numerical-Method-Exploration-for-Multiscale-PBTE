"""The outer solve, as a linear system in the scattering source.

Source iteration is a stationary Richardson iteration on a linear fixed point,
and that is the whole reason it is slow: the map it iterates,

    y  ->  D T^{-1} (S y + b) ,

has a spectral radius that goes to 1 as the medium becomes optically thick
(``rho ~ 1 - (pi tau_R)^2/3`` in the diffusive limit, ``1 - O(tau_R/tau_N)``
in the hydrodynamic one).  Nothing about the *answer* is hard: the fixed
point is the solution of a small, well-defined linear system

    (I - G) y = g ,       G = D T^{-1} S ,   g = D T^{-1} b ,

in the moments that drive the scattering source -- ``3 * NDOF_TRI * N_TRIS``
unknowns plus one per diffuse-wall face DOF, a few thousand in total, against
the ``NDIR * N_TRIS * NDOF_TRI`` unknowns of the distribution itself.  One
application of ``G`` costs exactly one transport sweep, the same currency
source iteration spends, so any Krylov method on this system is strictly
better value per sweep than the fixed-point iteration.

This module carries

``MomentState``    the packing of ``(T, qx, qy)`` moments and the diffuse-wall
                   emission into one vector, with the scaling that puts every
                   component in the units of the scattering source it feeds;
``MomentOperator`` ``y -> (I - G) y`` and the right-hand side ``g``, each one
                   sweep, plus ``realise`` which turns a converged ``y`` back
                   into the distribution it corresponds to;
``fgmres``         flexible GMRES, so that the preconditioner may be built
                   *during* the solve (see :mod:`pybte.lowres`) without
                   discarding the Krylov space already built.

The fixed point is unchanged by any of this: at convergence ``vdf`` satisfies
the same discrete transport system, to a residual limited by the Krylov
tolerance rather than by the contraction factor.
"""
from __future__ import annotations

import numpy as np

from .constants import BC_NONTHERMALISING, PI

__all__ = ["MomentOperator", "fgmres"]


class MomentOperator:
    """``(I - G) y`` and ``g``, in the scaled moment coordinates.

    The state carries, per element and DOF, the three fields that enter the
    scattering source

        a = Cv T (1/tau_R + 1/tau_N) / 4pi ,
        b = 3 qx / (4pi Vg^2 tau_N) ,
        c = 3 qy / (4pi Vg^2 tau_N) ,

    so that ``A_SRC(m) = sum_l INT_TRI_TRI(l,m,i) (a + cx b + cy c)(l,i)``
    with no further coefficients, followed by the diffuse-wall emission on
    the faces that have one.  Scaling the moments this way (rather than
    carrying ``T``, ``qx``, ``qy`` raw) keeps the three blocks the same size
    when ``tau_N`` is 1e5 times ``tau_R``, which is what a Krylov method
    needs to see a single well-scaled operator instead of three.
    """

    def __init__(self, solver):
        self.s = solver
        c = solver.case
        cv, vg = c.flow.cv, c.flow.vg
        self.cv = cv
        self.alpha = cv * (1.0 / c.flow.tau_r + 1.0 / c.flow.tau_n) / (4.0 * PI)
        self.beta = 3.0 / (4.0 * PI * vg * vg * c.flow.tau_n)
        self.nd = solver.ndof
        self.nt = solver.n_tris
        self.k = self.nd * self.nt

        bd = solver.bcdata
        mesh = solver.mesh
        if bd.has_nonthermalising:
            wall_bc = np.flatnonzero(bd.bc_type == BC_NONTHERMALISING)
            self.fw_faces = np.flatnonzero(np.isin(mesh.face_bc, wall_bc))
        else:
            self.fw_faces = np.zeros(0, dtype=np.int64)
        self.n_fw = int(self.fw_faces.size)
        self.n = 3 * self.k + self.n_fw * self.nd
        self.sweeps = 0
        self.masses: list[float] = []

    # -- packing -----------------------------------------------------------
    def pack(self, out=None) -> np.ndarray:
        """Read the solver's current moments into a state vector."""
        s = self.s
        y = np.empty(self.n) if out is None else out
        k = self.k
        np.multiply(s.mom.ts, self.alpha, out=y[0:k].reshape(self.nd, self.nt))
        np.multiply(s.mom.qxs, self.beta, out=y[k:2 * k].reshape(self.nd, self.nt))
        np.multiply(s.mom.qys, self.beta, out=y[2 * k:3 * k].reshape(self.nd, self.nt))
        if self.n_fw:
            np.multiply(s.bcdata.flux_wall[self.fw_faces], self.alpha,
                        out=y[3 * k:].reshape(self.n_fw, self.nd))
        return y

    def unpack(self, y: np.ndarray) -> None:
        """Write a state vector back into the solver's moment arrays."""
        s = self.s
        k = self.k
        np.multiply(y[0:k].reshape(self.nd, self.nt), 1.0 / self.alpha, out=s.mom.ts)
        np.multiply(y[k:2 * k].reshape(self.nd, self.nt), 1.0 / self.beta, out=s.mom.qxs)
        np.multiply(y[2 * k:3 * k].reshape(self.nd, self.nt), 1.0 / self.beta,
                    out=s.mom.qys)
        if self.n_fw:
            s.bcdata.flux_wall[self.fw_faces] = (y[3 * k:].reshape(self.n_fw, self.nd)
                                                 / self.alpha)

    # -- the map -----------------------------------------------------------
    def _apply(self, y, with_bc: bool, out=None) -> np.ndarray:
        """``D T^{-1} (S y [+ b])`` -- one transport sweep."""
        s = self.s
        self.unpack(y)
        s.ctx.sweep(s.mom, s.vdf, with_bc=with_bc)
        self.sweeps += 1
        s.update_moments()
        self.masses.append(float(np.sum(s.mom.temp)))
        return self.pack(out)

    def rhs(self) -> np.ndarray:
        """``g = D T^{-1} b``: the sweep driven by the wall sources alone."""
        return self._apply(np.zeros(self.n), True)

    def matvec(self, y: np.ndarray) -> np.ndarray:
        out = self._apply(y, False)
        np.subtract(y, out, out=out)
        return out

    def realise(self, y: np.ndarray) -> None:
        """Leave the solver holding the distribution that ``y`` describes.

        One last sweep, with the wall sources in: ``vdf`` then satisfies
        ``A_SOL f = A_SRC(y)`` element by element and direction by direction,
        and the moments are recomputed from that ``f`` so that what the run
        record reports and what ``solver.vdf`` contains are the same state.
        """
        s = self.s
        self.unpack(y)
        s.ctx.sweep(s.mom, s.vdf, with_bc=True)
        self.sweeps += 1
        s.update_moments()
        self.masses.append(float(np.sum(s.mom.temp)))


# ---------------------------------------------------------------------------
def fgmres(matvec, b, tol=1.0e-12, maxiter=200, x0=None, precond=None,
           hook=None, stall_floor=1.0e-9, stall_ratio=0.8):
    """Flexible GMRES with right preconditioning.

    Flexible because the preconditioner is allowed to change from one
    iteration to the next: ``hook(j, res)`` may return a new preconditioner
    (or ``None`` to keep the current one), which lets the driver decide *from
    the observed convergence* whether the synthetic-acceleration operator is
    worth building, without throwing away the Krylov space built so far.

    Returns ``(x, res, iters, history)`` with ``res`` the true relative
    residual ``||b - A x|| / ||b||``.
    """
    n = b.size
    bnorm = float(np.linalg.norm(b))
    if bnorm == 0.0:
        return np.zeros(n), 0.0, 0, [0.0]

    x = np.zeros(n) if x0 is None else np.array(x0, dtype=float)
    r = b - matvec(x) if x0 is not None else b.copy()
    beta = float(np.linalg.norm(r))
    if beta / bnorm <= tol:
        return x, beta / bnorm, 0, [beta / bnorm]

    V = np.empty((maxiter + 1, n))
    Z = np.empty((maxiter, n))
    H = np.zeros((maxiter + 1, maxiter))
    cs = np.zeros(maxiter)
    sn = np.zeros(maxiter)
    g = np.zeros(maxiter + 1)

    V[0] = r / beta
    g[0] = beta
    history = [beta / bnorm]
    res = beta / bnorm
    j = 0
    for j in range(maxiter):
        if hook is not None:
            new = hook(j, res)
            if new is not None:
                precond = new
        Z[j] = V[j] if precond is None else precond(V[j])
        w = matvec(Z[j])

        # classical Gram-Schmidt, twice: BLAS-2 and as stable as modified GS
        Vj = V[:j + 1]
        h = Vj @ w
        w -= h @ Vj
        h2 = Vj @ w
        w -= h2 @ Vj
        h += h2
        H[:j + 1, j] = h
        hnext = float(np.linalg.norm(w))
        H[j + 1, j] = hnext

        for i in range(j):
            t = cs[i] * H[i, j] + sn[i] * H[i + 1, j]
            H[i + 1, j] = -sn[i] * H[i, j] + cs[i] * H[i + 1, j]
            H[i, j] = t
        d = float(np.hypot(H[j, j], hnext))
        if d == 0.0:
            j += 1
            break
        cs[j] = H[j, j] / d
        sn[j] = hnext / d
        H[j, j] = d
        H[j + 1, j] = 0.0
        g[j + 1] = -sn[j] * g[j]
        g[j] = cs[j] * g[j]

        res = abs(g[j + 1]) / bnorm
        history.append(res)
        if res <= tol or hnext == 0.0:
            j += 1
            break
        # a Krylov solve that has stopped making progress well below the
        # accuracy anyone can use is finished, whatever the target says
        if (res < stall_floor and len(history) > 3
                and res > stall_ratio * history[-4]):
            j += 1
            break
        V[j + 1] = w / hnext
    else:
        j = maxiter

    if j > 0:
        yy = np.linalg.solve(np.triu(H[:j, :j]), g[:j])
        x += yy @ Z[:j]
    return x, res, j, history
