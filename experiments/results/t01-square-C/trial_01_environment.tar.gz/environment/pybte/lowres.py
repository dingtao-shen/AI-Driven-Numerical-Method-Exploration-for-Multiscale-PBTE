"""Synthetic acceleration: the same transport problem on a handful of directions.

What makes source iteration slow is not the transport sweep, it is the
scattering: one sweep moves information one mean free path, and in a
diffusive or hydrodynamic medium the answer is many mean free paths away.
The classical cure is to correct the moments with a cheap *low-order* model
of the same physics -- diffusion synthetic acceleration, and its relatives.

Here the low-order model is the discrete transport problem itself -- same
mesh, same DG space, same boundary treatment, same two relaxation channels --
with the angular quadrature collapsed onto ``n`` in-plane directions,

    c_k = Vg sqrt(2/3) (cos t_k, sin t_k),   w_k = 4pi/n,

equally spaced.  For any ``n >= 3`` that set has the exact moments the
scattering operator contracts against (``sum w = 4pi``, ``sum w c = 0``,
``sum w c_i c_j = (4pi Vg^2/3) delta_ij``), so the low-order model inherits
the diffusion limit of the fine one -- it is a P1 closure in disguise -- and,
because the momentum-conserving normal channel is kept in full, the
hydrodynamic limit too.  Nothing has to be derived by hand for either regime:
one assembly serves both.

With so few directions the coupled system

    K g = (T_L - S_L D_L) g = S_L r ,      M^{-1} r = r + D_L g

is small enough to factorise directly, once per run, and ``M^{-1}`` is a good
enough stand-in for ``(I - G)^{-1}`` to take GMRES from several hundred
sweeps to a dozen.

**How many directions.**  Three is the cheapest set that fixes the diffusive
end, and the factorisation is the dominant cost, so three is where to start.
Such a set cannot, however, carry a deviatoric stress -- fewer than five
equally spaced directions have degenerate fourth angular moments -- so the
low-order momentum equation has no viscosity.  That is invisible while
resistive scattering dominates and dominant once normal scattering does
(``tau_N << tau_R``), where the flow is Poiseuille-like and viscous.
:func:`preconditioner_directions` starts one direction richer in that
regime, and :meth:`pybte.driver.Solver.run` escalates further if the rate it
observes says the model is too crude.  Either way this is only a
preconditioner: a poor choice costs iterations, never accuracy.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import BC_NONTHERMALISING, BC_PERIODIC, PI

__all__ = ["LowOrderPreconditioner", "coarse_directions",
           "preconditioner_directions"]


def coarse_directions(vg: float, n: int = 4, offset: float = 0.25):
    """``n`` in-plane directions with the exact zeroth and second moments.

    Equally spaced at ``|c| = Vg sqrt(2/3)`` with weight ``4pi/n``, which for
    every ``n >= 3`` gives ``sum w = 4pi``, ``sum w c = 0`` and
    ``sum w c_i c_j = (4pi Vg^2/3) delta_ij``.  ``offset`` rotates the set by
    that fraction of the spacing, which for ``n = 4`` puts it on the
    diagonals rather than along the axes.
    """
    if n < 3:
        raise ValueError("need at least three coarse directions in 2D")
    ang = (np.arange(n) + offset) * (2.0 * PI / n)
    c = vg * np.sqrt(2.0 / 3.0)
    return c * np.cos(ang), c * np.sin(ang), np.full(n, 4.0 * PI / n)


def preconditioner_directions(case) -> int:
    """How many low-order directions this case needs.

    Four once normal scattering clearly outweighs resistive scattering,
    three otherwise; see the module docstring.  The driver escalates by two
    if the rate it then observes says the model was too crude, so this is a
    starting guess, not a commitment -- and only the iteration count depends
    on it either way.
    """
    return 4 if case.flow.tau_r > 4.0 * case.flow.tau_n else 3


class LowOrderPreconditioner:
    """``r -> r + D_L (T_L - S_L D_L)^{-1} S_L r``."""

    def __init__(self, solver, op, ndir: int | None = None):
        self.op = op
        s = solver
        c = s.case
        nd = self.nd = s.ndof
        nt = self.nt = s.n_tris
        if ndir is None:
            ndir = preconditioner_directions(c)
        cx, cy, wq = coarse_directions(c.flow.vg, ndir)
        self.cx, self.cy, self.wq = cx, cy, wq
        ncd = self.ncd = cx.size
        B = self.B = ncd * nd
        self.cv = c.flow.cv
        self.alpha = op.alpha
        self.beta = op.beta

        I = s.integrals
        mesh = s.mesh
        # INT_NODFUNC_TRI_TRI as (i, m, l) and as (i, l, m): the operator
        # indexes the first, the scattering source the second
        masst = np.ascontiguousarray(np.transpose(I.int_tri_tri, (2, 0, 1)))
        self.mlm = np.ascontiguousarray(np.transpose(masst, (0, 2, 1)))
        fcm = I.int_tri_fc
        ttfc = I.int_tri_tri_fc
        inv_tc = 1.0 / c.tau_c
        bc_type = s.bcdata.bc_type
        tri_faces = mesh.tri_faces

        speed = (cx * mesh.tri_normal[:, :, 0, None]
                 + cy * mesh.tri_normal[:, :, 1, None])        # (i, il, d)
        wp = np.maximum(speed, 0.0)
        wm = np.minimum(speed, 0.0)

        # ---- element-diagonal block: transport + scattering ---------------
        blocks = np.zeros((nt, B, B))
        for d in range(ncd):
            blk = (inv_tc * masst - cx[d] * I.int_tri_tri_x - cy[d] * I.int_tri_tri_y
                   + np.einsum('ij,ijml->iml', wp[:, :, d], fcm))
            blocks[:, d * nd:(d + 1) * nd, d * nd:(d + 1) * nd] += blk
        coup = (self.alpha / self.cv
                + self.beta * (cx[:, None] * cx[None, :] + cy[:, None] * cy[None, :]))
        for d in range(ncd):
            for dp in range(ncd):
                blocks[:, d * nd:(d + 1) * nd, dp * nd:(dp + 1) * nd] -= (
                    self.mlm * (wq[dp] * coup[d, dp]))

        # ---- off-diagonal blocks: upwind inflow from the neighbour --------
        rows = []
        cols = []
        vals = []
        dofs = np.arange(nd)
        dirs = np.arange(ncd)
        wall_slot: list[int] = []
        wall_tri: list[int] = []
        wall_lfc: list[int] = []
        wall_emit: list[np.ndarray] = []
        for il in range(3):
            fc = tri_faces[:, il]
            bcf = mesh.face_bc[fc]
            typ = np.where(bcf >= 0, bc_type[np.maximum(bcf, 0)], -1)
            interior = bcf < 0
            other = np.where(interior, mesh.tri_neighbour[:, il],
                             s.bcdata.periodic_tri[fc])
            sel = np.flatnonzero(interior | (typ == BC_PERIODIC))
            if sel.size:
                blk = wm[sel, il, :, None, None] * ttfc[sel, il][:, None]
                base_r = (sel[:, None, None, None] * B
                          + dirs[None, :, None, None] * nd + dofs[None, None, :, None])
                base_c = (other[sel][:, None, None, None] * B
                          + dirs[None, :, None, None] * nd + dofs[None, None, None, :])
                rows.append(np.broadcast_to(base_r, blk.shape).ravel())
                cols.append(np.broadcast_to(base_c, blk.shape).ravel())
                vals.append(blk.ravel())

            # ---- diffuse walls: what leaves the element comes back in -----
            for i in np.flatnonzero(typ == BC_NONTHERMALISING):
                out = speed[i, il] > 0.0            # leaves through this face
                inn = ~out
                ss2 = float(np.sum(speed[i, il][inn] * wq[inn]))
                if ss2 == 0.0:                      # pragma: no cover
                    continue
                emit = np.zeros(ncd)
                emit[out] = (speed[i, il][out] * wq[out]) / ss2
                wall_slot.append(int(np.searchsorted(op.fw_faces, tri_faces[i, il])))
                wall_tri.append(int(i))
                wall_lfc.append(il)
                wall_emit.append(emit)
                for d in np.flatnonzero(inn):
                    for dp in np.flatnonzero(out):
                        blocks[i, d * nd:(d + 1) * nd, dp * nd:(dp + 1) * nd] -= (
                            (speed[i, il, d] * emit[dp]) * fcm[i, il])

        r0 = (np.arange(nt)[:, None, None] * B + np.arange(B)[None, :, None])
        c0 = (np.arange(nt)[:, None, None] * B + np.arange(B)[None, None, :])
        rows.append(np.broadcast_to(r0, blocks.shape).ravel())
        cols.append(np.broadcast_to(c0, blocks.shape).ravel())
        vals.append(blocks.ravel())

        n = nt * B
        K = sp.csc_matrix((np.concatenate(vals),
                           (np.concatenate(rows), np.concatenate(cols))), shape=(n, n))
        # Static pivoting: the operator is diagonally dominant by construction
        # (the collision term carries 1/tau_C) and this is a preconditioner,
        # so trading a few digits of the factorisation for a third of the fill
        # is free.
        self.lu = spla.splu(K, permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.0)
        self.K = K

        # ---- pre-assembled pieces of the application ----------------------
        lfc = np.array(wall_lfc, dtype=np.int64)
        self.wall_slot = np.array(wall_slot, dtype=np.int64)
        self.wall_tri = np.array(wall_tri, dtype=np.int64)
        self.wall_emit = (np.array(wall_emit).reshape(-1, ncd) if wall_emit
                          else np.zeros((0, ncd)))
        self.wall_wm = (wm[self.wall_tri, lfc] if wall_slot
                        else np.zeros((0, ncd)))
        self.wall_fcm = (fcm[self.wall_tri, lfc] if wall_slot
                         else np.zeros((0, nd, nd)))
        #: (3, ncd) -- the moments the low-order solution feeds back
        self.dmat = np.array([wq * self.alpha / self.cv, wq * cx * self.beta,
                              wq * cy * self.beta])
        #: (3, ncd) -- how the three source fields enter each direction
        self.smat = np.array([np.ones(ncd), cx, cy])

    # -- application -------------------------------------------------------
    def __call__(self, r: np.ndarray) -> np.ndarray:
        op = self.op
        nd, nt, ncd = self.nd, self.nt, self.ncd
        k = op.k
        # S_L r: contract the three source fields with the mass matrix once
        # (one batched gemm), then spread them over the directions
        src = np.ascontiguousarray(
            r[:3 * k].reshape(3, nd, nt).transpose(2, 1, 0))       # (i, l, 3)
        rhs = np.ascontiguousarray(
            ((self.mlm @ src) @ self.smat).transpose(0, 2, 1))     # (i, ncd, m)
        if op.n_fw:
            rfw = r[3 * k:].reshape(op.n_fw, nd)
            np.add.at(rhs, self.wall_tri,
                      self.wall_wm[:, :, None]
                      * (rfw[self.wall_slot] * (1.0 / self.alpha))[:, None, :])

        g = self.lu.solve(rhs.reshape(-1)).reshape(nt, ncd, nd)

        z = np.empty_like(r)
        z[:3 * k] = r[:3 * k] + (self.dmat @ g).transpose(1, 2, 0).reshape(-1)
        if op.n_fw:
            zfw = z[3 * k:].reshape(op.n_fw, nd)
            zfw[:] = r[3 * k:].reshape(op.n_fw, nd)
            t = np.einsum('jd,jdl->jl', self.wall_emit, g[self.wall_tri])
            zfw[self.wall_slot] += self.alpha * (self.wall_fcm @ t[:, :, None])[:, :, 0]
        return z
