"""ctypes binding for the compiled kernels in ``_csrc/bte.c``.

Optional in exactly the sense numba is optional: if the shared library is not
there, or will not load, :data:`HAVE_C` is ``False`` and the solver falls
back to the jitted kernels and then to the pure-numpy ones.  Nothing about
the answer depends on which is used.

Why compile ahead of time at all, when numba is already available: the jitted
kernels are compiled or deserialised on *first call*, which lands inside the
solve.  A warm numba cache costs about 0.2 s to load and a cold one several
seconds -- against a solve that now takes about 0.1 s.  A ``.so`` is mapped
in microseconds and cannot go stale.

Build it with::

    python -m pybte.build_ext
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import sysconfig
from pathlib import Path

import numpy as np

__all__ = ["HAVE_C", "LIB", "build", "library_path", "sweep", "build_inverse",
           "sweep_order", "set_num_threads", "num_threads"]

_HERE = Path(__file__).resolve().parent
_SRC = _HERE / "_csrc" / "bte.c"

_i32 = np.int32
_c_i32p = ctypes.POINTER(ctypes.c_int32)
_c_dp = ctypes.POINTER(ctypes.c_double)


def library_path() -> Path:
    """Where the compiled kernel library lives for this interpreter."""
    suffix = sysconfig.get_config_var("EXT_SUFFIX") or ".so"
    # not an importable extension module, just a shared object; keep the
    # platform tag so two interpreters can share a source tree
    return _HERE / f"_bte{suffix}"


def build(verbose: bool = False) -> Path:
    """Compile ``_csrc/bte.c`` into the library, returning its path."""
    out = library_path()
    cc = os.environ.get("CC") or sysconfig.get_config_var("CC") or "cc"
    cmd = [*cc.split(), "-O3", "-fPIC", "-shared", "-fopenmp",
           "-funroll-loops", "-fno-math-errno", str(_SRC), "-o", str(out), "-lm"]
    if verbose:
        print(" ".join(cmd))
    subprocess.run(cmd, check=True)
    return out


def _load():
    path = library_path()
    if not path.exists():
        return None
    try:
        lib = ctypes.CDLL(str(path))
    except OSError:                                  # pragma: no cover
        return None
    lib.bte_sweep.restype = None
    lib.bte_sweep.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_int, _c_i32p, _c_dp, _c_dp,
        ctypes.c_double, _c_dp, _c_dp, _c_dp, _c_dp, _c_dp, _c_dp,
        _c_i32p, _c_i32p, _c_i32p, _c_i32p, _c_i32p, _c_dp, _c_dp, _c_dp, _c_dp]
    lib.bte_build_inverse.restype = ctypes.c_int
    lib.bte_build_inverse.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_int, _c_dp, _c_dp, ctypes.c_double,
        _c_dp, _c_dp, _c_dp, _c_dp, _c_dp, _c_dp, _c_dp]
    lib.bte_set_threads.restype = None
    lib.bte_set_threads.argtypes = [ctypes.c_int]
    lib.bte_num_threads.restype = ctypes.c_int
    lib.bte_num_threads.argtypes = []
    lib.bte_order.restype = ctypes.c_int
    lib.bte_order.argtypes = [
        ctypes.c_int, ctypes.c_int, _c_i32p, _c_dp, _c_dp, _c_dp, _c_dp,
        _c_i32p, _c_i32p, ctypes.c_int]
    return lib


_DISABLE = os.environ.get("PYBTE_NO_C", "").strip() not in ("", "0", "false", "False")
LIB = None if _DISABLE else _load()
HAVE_C = LIB is not None


# -- argument helpers -------------------------------------------------------
def _d(a):
    return a.ctypes.data_as(_c_dp)


def _i(a):
    return a.ctypes.data_as(_c_i32p)


def set_num_threads(n: int) -> int:
    """Cap the OpenMP team size; ``n = 0`` leaves the default alone."""
    if n > 0:
        LIB.bte_set_threads(int(n))
    return num_threads()


def num_threads() -> int:
    return int(LIB.bte_num_threads())


def sweep(ctx, sa, sb, sc, bc_temp, vdf) -> None:
    """One transport sweep with the compiled kernel."""
    ndir, ntri, nd = vdf.shape
    LIB.bte_sweep(ndir, ntri, nd, _i(ctx.order), _d(ctx.cxv), _d(ctx.cyv),
                  ctypes.c_double(ctx.cv), _d(sa), _d(sb), _d(sc),
                  _d(ctx.ttfc), _d(ctx.nx), _d(ctx.ny), _i(ctx.tri_faces),
                  _i(ctx.face_bc), _i(ctx.neighbour), _i(ctx.periodic_tri),
                  _i(ctx.bc_type), _d(bc_temp), _d(ctx.flux_wall),
                  _d(ctx.inv), _d(vdf))


def build_inverse(cxv, cyv, inv_tau_c, mass, gx, gy, fcm, nx, ny, out) -> int:
    ndir = cxv.size
    nd, _, ntri = mass.shape
    return int(LIB.bte_build_inverse(
        ndir, ntri, nd, _d(cxv), _d(cyv), ctypes.c_double(inv_tau_c),
        _d(mass), _d(gx), _d(gy), _d(fcm), _d(nx), _d(ny), _d(out)))


def sweep_order(neighbour, nx, ny, cxv, cyv, order, cycles, allow_break) -> int:
    ndir = cxv.size
    ntri = neighbour.shape[0]
    return int(LIB.bte_order(ndir, ntri, _i(neighbour), _d(nx), _d(ny),
                             _d(cxv), _d(cyv), _i(order), _i(cycles),
                             int(bool(allow_break))))
