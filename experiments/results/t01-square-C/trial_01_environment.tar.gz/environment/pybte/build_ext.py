"""Compile the optional C kernels: ``python -m pybte.build_ext``.

The solver runs without them (numba, then pure numpy), but they remove the
just-in-time compile/load from the timed part of a run and make the sweep
about twice as fast.  See :mod:`pybte._ckernels`.
"""
from __future__ import annotations

import sys


def main(argv=None) -> int:
    from ._ckernels import build

    path = build(verbose=True)
    print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
