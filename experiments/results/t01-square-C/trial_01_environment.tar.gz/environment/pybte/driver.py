"""The outer solve.

The Fortran's outer loop is a stationary iteration::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

which is Richardson iteration on ``y = G y + g`` in the moments that drive
the scattering source.  Its contraction factor is the physics: it goes to 1
like ``1 - (pi tau_R)^2/3`` as the medium becomes diffusive and like
``1 - O(tau_R/tau_N)`` as it becomes hydrodynamic, so on the stiff end of the
benchmark it needs more iterations than the cap allows -- and, worse, its
stopping test measures the *step* between iterates, which is small long
before the *error* is (``RunRecord.error_estimate`` reports the difference).

:meth:`Solver.run` solves the same system instead of iterating it: GMRES on
``(I - G) y = g``, one transport sweep per matrix-vector product, optionally
right-preconditioned by the four-direction synthetic-acceleration operator of
:mod:`pybte.lowres` when the observed convergence says that operator will pay
for itself.  The fixed point is identical -- same discretisation, same sweep,
same boundary treatment -- but it is reached in tens of sweeps at every
``(tau_R, tau_N)`` in the benchmark rather than tens of thousands, and it is
reached to the residual of the discrete system, not to a stalled step.

:meth:`Solver.step` still performs exactly one Fortran outer iteration, and
:meth:`Solver.run_source_iteration` still drives the loop above, for anyone
who needs the historical iterate sequence.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from .krylov import MomentOperator, fgmres
from .lowres import LowOrderPreconditioner
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        self.vdf = np.ascontiguousarray(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof))
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def update_moments(self) -> None:
        """Moments of the current ``vdf``, and the wall emission it implies.

        The diffuse-wall emission is a moment of the distribution like any
        other -- ``Calculate_FLUX_WALL`` is a boundary-face quadrature over
        the outgoing half-space -- so it is refreshed here rather than at the
        top of the next sweep.  Same value, same iterate sequence; it just
        makes "the state implied by this distribution" one call.
        """
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)

    def step(self) -> None:
        """One Fortran outer iteration: sweep, then moments."""
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer solve ----------------------------------------------------
    #: GMRES target for ``||(I - G) y - g|| / ||g||``.  Four orders of
    #: magnitude tighter than anything the temperature field can resolve,
    #: because it costs one or two extra sweeps to be sure rather than close.
    KRYLOV_TOL = 1.0e-13
    #: below this the answer is converged for every purpose; used to accept a
    #: solve that has stopped improving before reaching ``KRYLOV_TOL``
    KRYLOV_FLOOR = 1.0e-10
    #: first iteration at which the convergence rate is extrapolated to decide
    #: whether the synthetic-acceleration operator is worth building
    PRECOND_PROBE = 6
    #: build it if more than this many further sweeps would be needed without
    PRECOND_BREAKEVEN = 30
    #: rebuild with a richer angular set if, that many sweeps after building
    #: it, the preconditioned rate still implies more than this many to go
    ESCALATE_BREAKEVEN = 60

    def run(self, callback=None, progress_every: int = 0,
            precondition: bool | None = None) -> RunRecord:
        """Solve ``(I - G) y = g`` by GMRES, one sweep per matrix-vector product.

        ``precondition`` forces the four-direction synthetic-acceleration
        preconditioner on or off; the default decides from the observed
        convergence rate, at iteration ``PRECOND_PROBE``, whether building it
        will pay for itself.
        """
        c = self.case
        t0 = time.perf_counter()
        op = MomentOperator(self)
        self._last_operator = op

        y0 = None
        if self.restart_info.get("enabled"):
            self.update_moments()
            y0 = op.pack()

        g = op.rhs()
        maxiter = max(1, min(int(c.iteration.tmax) - 2, 600))

        pc_state = {"pc": None, "built": False, "ndir": 0, "built_at": -1,
                    "res_at_build": 1.0, "escalated": False, "hist": []}

        def build_precond(ndir=None):
            pc_state["built"] = True
            try:
                pc_state["pc"] = LowOrderPreconditioner(self, op, ndir=ndir)
                pc_state["ndir"] = pc_state["pc"].ncd
            except Exception as exc:            # pragma: no cover - defensive
                warnings.warn(f"synthetic acceleration unavailable ({exc}); "
                              "continuing unpreconditioned")
                pc_state["pc"] = None
            return pc_state["pc"]

        if precondition:
            build_precond()

        def remaining(j0, r0, j, res):
            """Sweeps still needed at the rate observed since ``(j0, r0)``."""
            k = j - j0
            if k <= 0 or r0 <= 0.0 or res <= 0.0:
                return np.inf
            rho = (res / r0) ** (1.0 / k)
            if rho >= 1.0:
                return np.inf
            return float(np.log(self.KRYLOV_TOL / res) / np.log(rho))

        def hook(j, res):
            pc_state["hist"].append(res)
            if precondition is False or res <= self.KRYLOV_TOL:
                return None
            if not pc_state["built"]:
                # extrapolate the observed contraction: if the unpreconditioned
                # solve is going to cost more sweeps than the low-order operator
                # costs to build and use, build it
                if j < self.PRECOND_PROBE:
                    return None
                if remaining(0, pc_state["hist"][0], j, res) > self.PRECOND_BREAKEVEN:
                    pc_state["built_at"] = j
                    pc_state["res_at_build"] = res
                    return build_precond()
                return None
            # ... and if the low-order model turns out to be a poor one, pay
            # for a richer angular set rather than iterate on a bad guess
            if (pc_state["pc"] is None or pc_state["escalated"]
                    or j < pc_state["built_at"] + 2 * self.PRECOND_PROBE):
                return None
            if remaining(pc_state["built_at"], pc_state["res_at_build"], j,
                         res) > self.ESCALATE_BREAKEVEN:
                pc_state["escalated"] = True
                return build_precond(ndir=pc_state["ndir"] + 2)
            return None

        y, res, iters, hist = fgmres(
            op.matvec, g, tol=self.KRYLOV_TOL, maxiter=maxiter, x0=y0,
            precond=pc_state["pc"], hook=hook,
            stall_floor=self.KRYLOV_FLOOR)

        # the distribution that goes with the converged moments
        op.realise(y)
        converged = bool(res <= self.KRYLOV_FLOOR)
        wall = time.perf_counter() - t0

        residuals = np.asarray(hist)
        masses = np.asarray(op.masses if op.masses else [float(self.mom.temp.sum())])
        self.t_old[:] = self.mom.temp
        rec = self._record(op.sweeps, converged, residuals, masses, None, wall,
                           scheme="GMRES",
                           extra={"krylov_iterations": int(iters),
                                  "krylov_residual": float(res),
                                  "preconditioner": ("lowres-S4"
                                                     if pc_state["pc"] is not None
                                                     else "none"),
                                  "moment_unknowns": int(op.n)})
        if progress_every:
            print(f"  GMRES {iters} iterations, {op.sweeps} sweeps, "
                  f"relative residual {res:.3e}", flush=True)
        if callback is not None:
            callback(op.sweeps, res, self)
        return rec

    # -- the historical outer loop ------------------------------------------
    def run_source_iteration(self, callback=None,
                             progress_every: int = 0) -> RunRecord:
        """Source iteration: ``Calculate_Residual_T < tol``, as the Fortran."""
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
