/* Compiled kernels: the transport sweep, the element operators, the sweep
 * ordering.
 *
 * These are the same three loops as pybte/_kernels.py, in C, for two reasons
 * that have nothing to do with the arithmetic:
 *
 *   - a jitted kernel is compiled or loaded on first call, inside the solve
 *     it is supposed to be timing.  On this problem size that dominates: a
 *     warm numba cache costs ~0.2 s to load and a cold one several seconds,
 *     against a solve of ~0.1 s.  A shared library is mapped in microseconds.
 *   - the sweep here applies a precomputed *inverse* rather than an LU pair,
 *     and hoists the scattering source contraction out of the direction loop,
 *     which is worth about 2x.
 *
 * Nothing else changes: same discretisation, same upwind flux, same boundary
 * dispatch, same Gauss-Seidel ordering.  pybte falls back to the numba (or
 * pure numpy) kernels when this library is not present, and the two agree to
 * round-off -- see tests/unit/test_ckernels.py.
 *
 * Build:  python -m pybte.build_ext        (or pybte/_ckernels.py::build)
 */
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#ifdef _OPENMP
#include <omp.h>
#endif

#define FOUR_PI 12.566370614359172464

/* Cap the OpenMP team size.  Directions are independent, so any value gives
 * identical results; 0 leaves the runtime's default alone.               */
void bte_set_threads(int n)
{
#ifdef _OPENMP
    if (n > 0)
        omp_set_num_threads(n);
#else
    (void)n;
#endif
}

int bte_num_threads(void)
{
#ifdef _OPENMP
    return omp_get_max_threads();
#else
    return 1;
#endif
}

/* ------------------------------------------------------------------ */
/* in-place inverse of a small dense matrix, Gauss-Jordan with partial
 * pivoting.  Returns 0 on success, the failing column (1-based) if a pivot
 * is exactly zero.                                                     */
static int invert_small(double *a, int n, double *work, int *piv)
{
    int i, j, k, p;
    double big, v, r;

    for (i = 0; i < n * n; ++i)
        work[i] = (i / n == i % n) ? 1.0 : 0.0;

    for (k = 0; k < n; ++k) {
        p = k;
        big = fabs(a[k * n + k]);
        for (i = k + 1; i < n; ++i) {
            v = fabs(a[i * n + k]);
            if (v > big) { big = v; p = i; }
        }
        if (a[p * n + k] == 0.0)
            return k + 1;
        if (p != k) {
            for (j = 0; j < n; ++j) {
                v = a[k * n + j]; a[k * n + j] = a[p * n + j]; a[p * n + j] = v;
                v = work[k * n + j]; work[k * n + j] = work[p * n + j];
                work[p * n + j] = v;
            }
        }
        r = 1.0 / a[k * n + k];
        for (j = 0; j < n; ++j) {
            a[k * n + j] *= r;
            work[k * n + j] *= r;
        }
        for (i = 0; i < n; ++i) {
            if (i == k) continue;
            v = a[i * n + k];
            if (v == 0.0) continue;
            for (j = 0; j < n; ++j) {
                a[i * n + j] -= v * a[k * n + j];
                work[i * n + j] -= v * work[k * n + j];
            }
        }
    }
    memcpy(a, work, (size_t)n * n * sizeof(double));
    (void)piv;
    return 0;
}

/* ------------------------------------------------------------------ */
/* A_SOL(m,l) for one element and one direction -- Solvers.f90's expression.
 * mass is (nd, nd, n_tris), gx/gy are (n_tris, nd, nd), fcm is
 * (n_tris, 3, nd, nd).                                                  */
static void fill_a_sol(double *a, int i, int ntri, int nd, double cxd,
                       double cyd, double inv_tau_c, const double *mass,
                       const double *gx, const double *gy, const double *fcm,
                       const double *nx, const double *ny)
{
    int m, l, il;
    double w[3];
    const double *g0 = gx + (size_t)i * nd * nd;
    const double *g1 = gy + (size_t)i * nd * nd;

    for (il = 0; il < 3; ++il) {
        double s = cxd * nx[i * 3 + il] + cyd * ny[i * 3 + il];
        w[il] = 0.5 * (s + fabs(s));
    }
    for (m = 0; m < nd; ++m) {
        for (l = 0; l < nd; ++l) {
            double v = inv_tau_c * mass[((size_t)m * nd + l) * ntri + i]
                       - cxd * g0[m * nd + l] - cyd * g1[m * nd + l];
            for (il = 0; il < 3; ++il)
                v += w[il] * fcm[(((size_t)i * 3 + il) * nd + m) * nd + l];
            a[m * nd + l] = v;
        }
    }
}

/* Build and invert A_SOL for every (direction, element) pair.
 * mass : (nd, nd, n_tris)   gx, gy : (n_tris, nd, nd)
 * fcm  : (n_tris, 3, nd, nd)  nx, ny : (n_tris, 3)
 * out  : (ndir, n_tris, nd, nd)                                        */
int bte_build_inverse(int ndir, int ntri, int nd,
                      const double *cxv, const double *cyv, double inv_tau_c,
                      const double *mass, const double *gx, const double *gy,
                      const double *fcm, const double *nx, const double *ny,
                      double *out)
{
    int bad = 0;
    int d;
#pragma omp parallel for schedule(static) reduction(+:bad)
    for (d = 0; d < ndir; ++d) {
        double *a = (double *)malloc((size_t)nd * nd * sizeof(double));
        double *work = (double *)malloc((size_t)nd * nd * sizeof(double));
        int i;
        for (i = 0; i < ntri; ++i) {
            double *dst = out + ((size_t)d * ntri + i) * nd * nd;
            fill_a_sol(a, i, ntri, nd, cxv[d], cyv[d], inv_tau_c, mass, gx, gy,
                       fcm, nx, ny);
            if (invert_small(a, nd, work, NULL) != 0)
                bad += 1;
            memcpy(dst, a, (size_t)nd * nd * sizeof(double));
        }
        free(a);
        free(work);
    }
    return bad;
}

/* ------------------------------------------------------------------ */
/* One transport sweep.
 *
 * sa/sb/sc are the three scattering-source fields already contracted with
 * the mass matrix, (n_tris, nd) each; the per-direction source is
 * src[m] = sa[i,m] + cx sb[i,m] + cy sc[i,m].  Hoisting that contraction out
 * of the direction loop is most of the speed-up over the jitted kernel.   */
void bte_sweep(int ndir, int ntri, int nd,
               const int32_t *order, const double *cxv, const double *cyv,
               double cv,
               const double *sa, const double *sb, const double *sc,
               const double *ttfc, const double *nx, const double *ny,
               const int32_t *tri_faces, const int32_t *face_bc,
               const int32_t *neighbour, const int32_t *periodic_tri,
               const int32_t *bc_type, const double *bc_temp,
               const double *flux_wall, const double *inv, double *vdf)
{
    int d;
#pragma omp parallel for schedule(static)
    for (d = 0; d < ndir; ++d) {
        double *src = (double *)malloc((size_t)nd * sizeof(double));
        const double cxd = cxv[d];
        const double cyd = cyv[d];
        const int32_t *ord = order + (size_t)d * ntri;
        double *vd = vdf + (size_t)d * ntri * nd;
        const double *invd = inv + (size_t)d * ntri * nd * nd;
        int k, m, l, il;
        for (k = 0; k < ntri; ++k) {
            const int i = ord[k];
            for (m = 0; m < nd; ++m)
                src[m] = sa[(size_t)i * nd + m] + cxd * sb[(size_t)i * nd + m]
                         + cyd * sc[(size_t)i * nd + m];
            for (il = 0; il < 3; ++il) {
                double s = cxd * nx[i * 3 + il] + cyd * ny[i * 3 + il];
                double w = 0.5 * (s - fabs(s));
                const double *tt;
                int fc, bc, typ, iext;
                if (w == 0.0) continue;
                tt = ttfc + ((size_t)i * 3 + il) * nd * nd;
                fc = tri_faces[i * 3 + il];
                bc = face_bc[fc];
                typ = (bc < 0) ? -1 : bc_type[bc];
                if (bc < 0 || typ == 3) {
                    const double *fl;
                    iext = (bc < 0) ? neighbour[i * 3 + il] : periodic_tri[fc];
                    fl = vd + (size_t)iext * nd;
                    for (m = 0; m < nd; ++m) {
                        double acc = 0.0;
                        for (l = 0; l < nd; ++l)
                            acc += tt[m * nd + l] * fl[l];
                        src[m] -= w * acc;
                    }
                } else if (typ == 2) {
                    const double *fw = flux_wall + (size_t)fc * nd;
                    for (m = 0; m < nd; ++m)
                        src[m] += w * fw[m];
                } else {
                    double tw = cv / 4.0 / M_PI * bc_temp[bc];
                    for (m = 0; m < nd; ++m)
                        src[m] -= w * (tw * tt[m * nd]);
                }
            }
            {
                const double *ai = invd + (size_t)i * nd * nd;
                double *f = vd + (size_t)i * nd;
                for (m = 0; m < nd; ++m) {
                    double acc = 0.0;
                    for (l = 0; l < nd; ++l)
                        acc += ai[m * nd + l] * src[l];
                    f[m] = acc;
                }
            }
        }
        free(src);
    }
}

/* ------------------------------------------------------------------ */
/* Sweep ordering: the pass number of Matrix.f90::Init_Triangle_Order.
 *
 * The Fortran scans elements in ascending index order and emits every one
 * whose inflow faces are all cleared, clearing neighbours' flags as it goes,
 * so an element later in the same scan can go in the same pass.  Element i
 * is therefore emitted in pass
 *
 *     p(i) = max over upwind j of ( p(j) + [j > i] ) ,   1 if it has none,
 *
 * and the order is that pass number, ties broken by ascending index.       */
int bte_order(int ndir, int ntri, const int32_t *neighbour,
              const double *nx, const double *ny,
              const double *cxv, const double *cyv,
              int32_t *order, int32_t *cycles, int allow_break)
{
    int status = 0;
    int d;
#pragma omp parallel for schedule(static) reduction(+:status)
    for (d = 0; d < ndir; ++d) {
        signed char *ioflag = (signed char *)malloc((size_t)ntri * 3);
        unsigned char *inarray = (unsigned char *)malloc((size_t)ntri);
        int32_t *ord = order + (size_t)d * ntri;
        int i, il, k, num = 0, broken = 0;
        for (i = 0; i < ntri; ++i) {
            inarray[i] = 1;
            for (il = 0; il < 3; ++il) {
                signed char f = 0;
                if (neighbour[i * 3 + il] >= 0) {
                    double flux = cxv[d] * nx[i * 3 + il] + cyv[d] * ny[i * 3 + il];
                    f = (flux > 0.0) ? 1 : ((flux < 0.0) ? -1 : 0);
                }
                ioflag[i * 3 + il] = f;
            }
        }
        while (num < ntri) {
            int progressed = 0;
            for (i = 0; i < ntri; ++i) {
                int ready = 1;
                if (!inarray[i]) continue;
                for (il = 0; il < 3; ++il)
                    if (ioflag[i * 3 + il] == -1) { ready = 0; break; }
                if (!ready) continue;
                ord[num++] = i;
                inarray[i] = 0;
                progressed = 1;
                for (il = 0; il < 3; ++il) {
                    int t2 = neighbour[i * 3 + il];
                    if (t2 < 0) continue;
                    for (k = 0; k < 3; ++k)
                        if (neighbour[t2 * 3 + k] == i) {
                            ioflag[t2 * 3 + k] = 0;
                            break;
                        }
                }
            }
            if (!progressed) {
                int best = -1, best_in = 4;
                if (!allow_break) { status += 1; break; }
                for (i = 0; i < ntri; ++i) {
                    int cnt = 0;
                    if (!inarray[i]) continue;
                    for (il = 0; il < 3; ++il)
                        if (ioflag[i * 3 + il] == -1) cnt++;
                    if (cnt < best_in) { best_in = cnt; best = i; }
                }
                if (best < 0) { status += 1; break; }
                ord[num++] = best;
                inarray[best] = 0;
                broken++;
                for (il = 0; il < 3; ++il) {
                    int t2 = neighbour[best * 3 + il];
                    if (t2 < 0) continue;
                    for (k = 0; k < 3; ++k)
                        if (neighbour[t2 * 3 + k] == best) {
                            ioflag[t2 * 3 + k] = 0;
                            break;
                        }
                }
            }
        }
        cycles[d] = broken;
        free(ioflag);
        free(inarray);
    }
    return status ? -1 : 0;
}
