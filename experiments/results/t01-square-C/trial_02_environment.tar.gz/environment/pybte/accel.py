"""Krylov acceleration of the outer iteration.

Source iteration is a fixed-point iteration on the *moments*, and nothing
else: the sweep is an exact transport solve for the source it is handed, so
one outer step is the affine map

    y_{k+1} = G(y_k) = M y_k + c,
    y = (T_dofs, qx_dofs, qy_dofs [, diffuse-wall emission]),

with ``M`` linear in ``y`` and ``c = G(0)`` carrying the wall sources.  The
fixed point is therefore the solution of

    (I - M) y = c,                                            (*)

and source iteration is the Richardson iteration for (*).  Its contraction
factor is the spectral radius of ``M``, which goes to 1 as the medium becomes
optically thick (``1 - rho ~ (tau_C k)^2 / 3``): that is the pseudo-convergence
the shipped driver runs into.

This module solves (*) with GMRES instead.  One matrix-vector product is one
sweep, so the iteration count is directly comparable, and the answer is the
fixed point itself rather than wherever the fixed-point iteration happened to
stall.

Two pieces make it fast:

``MomentSystem``
    packs/unpacks the moment state and evaluates ``G`` with the shipped
    kernels, so the matvec is bit-for-bit the sweep the reference performs.

``LowOrderOperator``
    a synthetic-acceleration preconditioner.  Taking the zeroth and first
    angular moments of the discrete transport equation is *exact*::

        div q'   + Cv T'/tau_C = Cv T /tau_C
        div P'   + q'/tau_C    = q /tau_N

    and closing ``P`` with the Chapman-Enskog result for the Callaway model,
    ``P = (Cv vg^2/3) T I - mu (grad q + grad q^T)`` with
    ``mu = tau_C^2 vg^2 / (5 tau_N)``, turns the correction equation into a
    diffusion problem for the temperature plus a Brinkman problem for the
    heat flux, both posed on the continuous Lagrange subspace of the DG
    space.  The temperature part is classical DSA -- it is what removes the
    diffusive stiffness (``tau_R`` small).  The viscous flux part is what
    removes the *hydrodynamic* stiffness (``tau_N`` small, ``tau_R`` large),
    where momentum, not energy, is the nearly conserved quantity and the
    slow modes are Poiseuille-like flux modes that classical DSA does not
    see.
"""
from __future__ import annotations

import numpy as np

from .constants import BC_NONTHERMALISING, BC_THERMALISING
from .moments import compute_moments

__all__ = ["MomentSystem", "LowOrderOperator", "gmres"]


# ---------------------------------------------------------------------------
# the affine fixed-point map
# ---------------------------------------------------------------------------
class MomentSystem:
    """The source-iteration map ``y -> G(y)`` as a linear operator.

    ``y`` holds the per-DOF moments the sweep reads -- ``T``, ``qx``, ``qy``
    -- and, when a diffusely reflecting wall is present, that wall's emission,
    which the shipped driver also carries from one iteration to the next.
    Nothing else crosses an iteration boundary, so ``G`` is affine in ``y``
    and one evaluation costs exactly one sweep.
    """

    def __init__(self, solver):
        s = self.solver = solver
        self.nd = s.ndof
        self.nt = s.n_tris
        self.k = self.nd * self.nt
        bd = s.bcdata
        if bd.has_nonthermalising:
            fb = s.mesh.face_bc
            typ = np.where(fb >= 0, bd.bc_type[np.maximum(fb, 0)], -1)
            self.wall_faces = np.flatnonzero(typ == BC_NONTHERMALISING)
        else:
            self.wall_faces = np.zeros(0, dtype=np.int64)
        self.nw = self.wall_faces.size * self.nd
        self.n = 3 * self.k + self.nw
        self.sweeps = 0

    # -- state <-> vector --------------------------------------------------
    def scatter(self, y) -> None:
        """Write ``y`` into the solver's moment/wall state."""
        s = self.solver
        k = self.k
        s.mom.ts[:] = y[:k].reshape(self.nd, self.nt)
        s.mom.qxs[:] = y[k:2 * k].reshape(self.nd, self.nt)
        s.mom.qys[:] = y[2 * k:3 * k].reshape(self.nd, self.nt)
        if self.nw:
            s.bcdata.flux_wall[:] = 0.0
            s.bcdata.flux_wall[self.wall_faces] = y[3 * k:].reshape(-1, self.nd)

    def gather(self, out=None) -> np.ndarray:
        s = self.solver
        k = self.k
        out = np.empty(self.n) if out is None else out
        out[:k] = s.mom.ts.ravel()
        out[k:2 * k] = s.mom.qxs.ravel()
        out[2 * k:3 * k] = s.mom.qys.ravel()
        if self.nw:
            out[3 * k:] = s.bcdata.flux_wall[self.wall_faces].ravel()
        return out

    # -- the map -----------------------------------------------------------
    def sweep(self) -> None:
        """One transport sweep from the current moment state, plus the
        moments (and wall emission) of the result."""
        s = self.solver
        s.ctx.sweep(s.mom, s.vdf)
        self.sweeps += 1
        if s.ctx.mode == "onthefly":
            s.factorisation_count += s.ndir * s.n_tris
        compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                        s.integrals.int_tri, s.case.flow.cv, s.mom)
        if self.nw:
            s.bcdata.update_wall_flux(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                                      s.integrals.int_tri_fc, s.mesh)

    def G(self, y, out=None) -> np.ndarray:
        self.scatter(y)
        self.sweep()
        return self.gather(out)

    def residual_map(self, y, const, out=None) -> np.ndarray:
        """``(I - M) y = y - (G(y) - c)``."""
        out = self.G(y, out)
        out *= -1.0
        out += const
        out += y
        return out


# ---------------------------------------------------------------------------
# the low-order (synthetic acceleration) preconditioner
# ---------------------------------------------------------------------------
def _reference_tensors(basis, np_tri):
    """Reference-triangle mass, stiffness and gradient tensors."""
    from .quadrature import tri_quadrature
    from .basis import eval_tri_basis

    nq = max(np_tri, 6)
    qx, qy, qw = tri_quadrature(nq if nq in (3, 4, 6, 7, 12, 16) else 12)
    w = 0.5 * qw                       # int_ref f = 0.5 * sum(qw * f)
    psi = eval_tri_basis(basis.nodfun_tri, basis.mono, qx, qy)
    gx, gy = _ref_grad(basis, qx, qy)
    mass = np.einsum("q,ql,qm->lm", w, psi, psi)
    sxx = np.einsum("q,ql,qm->lm", w, gx, gx)
    sxy = np.einsum("q,ql,qm->lm", w, gx, gy)
    syy = np.einsum("q,ql,qm->lm", w, gy, gy)
    return mass, sxx, sxy, syy


def _ref_grad(basis, xi, eta):
    """``d psi/d xi`` and ``d psi/d eta`` at the given reference points."""
    nodf, mono = basis.nodfun_tri, basis.mono
    xi = np.asarray(xi, dtype=float)
    eta = np.asarray(eta, dtype=float)
    gx = np.zeros((xi.size, nodf.shape[0]))
    gy = np.zeros((xi.size, nodf.shape[0]))
    for k, (a, b) in enumerate(mono):
        if a > 0:
            gx += nodf[:, k] * (a * xi ** (a - 1) * eta ** b)[:, None]
        if b > 0:
            gy += nodf[:, k] * (b * xi ** a * eta ** (b - 1))[:, None]
    return gx, gy


def cg_node_map(mesh, deg: int):
    """Map every DG DOF to a node of the continuous Lagrange space.

    Returns ``(gid, n_cg, face_nodes)`` with ``gid[l, i]`` the global
    continuous-space node of local DOF ``l`` of element ``i`` and
    ``face_nodes[f]`` the ``deg+1`` node ids along face ``f``, ordered from
    its first vertex to its second.  Only ``deg <= 2`` is supported: from
    degree 3 on the edge DOFs need an orientation convention that the nodal
    basis does not carry.
    """
    tn = mesh.tri_nodes
    tf = mesh.tri_faces
    nn = mesh.n_nodes
    if deg == 1:
        gid = np.stack([tn[:, 0], tn[:, 1], tn[:, 2]])
        face_nodes = mesh.face_nodes.T.copy()
        return gid, nn, face_nodes
    if deg == 2:
        gid = np.stack([tn[:, 0], nn + tf[:, 0], tn[:, 1],
                        nn + tf[:, 2], nn + tf[:, 1], tn[:, 2]])
        f = np.arange(mesh.n_faces)
        face_nodes = np.stack([mesh.face_nodes[:, 0], nn + f, mesh.face_nodes[:, 1]])
        return gid, nn + mesh.n_faces, face_nodes
    raise NotImplementedError(f"no continuous node map for deg={deg}")


class LowOrderOperator:
    """Synthetic-acceleration preconditioner for ``I - M``.

    Given the residual ``r`` of (*), it returns an approximation of
    ``(I - M)^-1 r`` by solving the moment (P1 + Chapman-Enskog viscosity)
    closure of the same equations on the continuous Lagrange subspace of the
    DG space::

        -div(kappa grad u_T) = f - mu tau_R lap f - tau_R div g
        (1/tau_R - mu lap) u_q = g - (Cv vg^2/3) grad u_T

    with ``f = Cv r_T/tau_C``, ``g = r_q/tau_N``,
    ``kappa = Cv vg^2 tau_R/3`` and ``mu = tau_C^2 vg^2/(5 tau_N)``;
    the answer is ``r + (u_T, u_q)``.

    Boundary conditions follow the transport problem's:
    an isothermal wall emits a *fixed* distribution, so the correction sees
    a vacuum wall -- Marshak, i.e. ``kappa d_n u_T + Cv vg u_T/2 = 0`` --
    while a diffusely reflecting wall is adiabatic and gives the natural
    condition.  Both wall types randomise the direction of what they
    re-emit, so neither carries tangential momentum: ``u_q = 0`` on the whole
    boundary.
    """

    supported = staticmethod(lambda case, solver:
                             case.dg.deg <= 2 and not solver.bcdata.has_periodic)

    def __init__(self, solver):
        import scipy.sparse as sp
        import scipy.sparse.linalg as spla

        s = solver
        c = s.case
        m = s.mesh
        cv, vg = c.flow.cv, c.flow.vg
        tau_r, tau_n, tau_c = c.flow.tau_r, c.flow.tau_n, c.tau_c

        self.solver = s
        self.nd, self.nt = s.ndof, s.n_tris
        self.kappa = cv * vg * vg * tau_r / 3.0
        self.p_coef = cv * vg * vg / 3.0
        self.cv_over_tau_c = cv / tau_c
        self.inv_tau_n = 1.0 / tau_n
        self.tau_r = tau_r
        self.mu = tau_c * tau_c * vg * vg / (5.0 * tau_n)

        gid, ng, face_nodes = cg_node_map(m, c.dg.deg)
        self.gid = gid
        self.ng = ng

        # -- element geometry: gradients of the reference coordinates -------
        x = m.nodes[m.tri_nodes, 0]
        y = m.nodes[m.tri_nodes, 1]
        area2 = 2.0 * m.tri_area
        gxi = np.stack([y[:, 2] - y[:, 0], x[:, 0] - x[:, 2]], axis=1) / area2[:, None]
        get = np.stack([y[:, 0] - y[:, 1], x[:, 1] - x[:, 0]], axis=1) / area2[:, None]
        self.gxi, self.get = gxi, get
        self.area2 = area2

        mref, sxx, sxy, syy = _reference_tensors(s.basis, c.np_tri)
        self.mref = mref
        gxx = (gxi * gxi).sum(1)
        gxy = (gxi * get).sum(1)
        gyy = (get * get).sum(1)
        loc_k = area2[:, None, None] * (gxx[:, None, None] * sxx
                                        + gxy[:, None, None] * (sxy + sxy.T)
                                        + gyy[:, None, None] * syy)
        loc_m = area2[:, None, None] * mref[None, :, :]

        nd = self.nd
        rows = np.repeat(gid, nd, axis=0).ravel()             # (nd*nd*nt,)
        cols = np.tile(gid, (nd, 1)).ravel()
        shape = (ng, ng)
        stiff = sp.coo_matrix((loc_k.transpose(1, 2, 0).ravel(), (rows, cols)),
                              shape=shape).tocsr()
        mass = sp.coo_matrix((loc_m.transpose(1, 2, 0).ravel(), (rows, cols)),
                             shape=shape).tocsr()

        # -- boundary terms -------------------------------------------------
        robin, dirichlet = self._boundary_terms(s, face_nodes, cv, vg, ng)

        self.lu_temp = spla.splu((self.kappa * stiff + robin).tocsc())
        hmat = (mass / tau_r + self.mu * stiff).tolil()
        if dirichlet.size:
            hmat[dirichlet, :] = 0.0
            hmat[:, dirichlet] = 0.0
            hmat[dirichlet, dirichlet] = 1.0
        self.lu_flux = spla.splu(hmat.tocsc())
        self.dirichlet = dirichlet
        self.lu_mass = spla.splu(mass.tocsc()) if self.mu > 0.0 else None
        self.stiff = stiff

        # scatter matrix: DG DOF (l, i) -> continuous node
        self.scatter = sp.coo_matrix(
            (np.ones(gid.size), (gid.ravel(), np.arange(gid.size))),
            shape=(ng, gid.size)).tocsr()

        # gradients of the DG basis at its own nodes, for grad u_T
        dxi, det = _ref_grad(s.basis, s.basis.node_tri[:, 0], s.basis.node_tri[:, 1])
        self.dxi, self.det = dxi, det
        self.gx = np.ascontiguousarray(s.integrals.int_tri_tri_x)
        self.gy = np.ascontiguousarray(s.integrals.int_tri_tri_y)
        self.tri_mass = np.ascontiguousarray(s.integrals.int_tri_tri)

    def _boundary_terms(self, s, face_nodes, cv, vg, ng):
        """Marshak (Robin) rows for isothermal walls; the Dirichlet node list
        for the flux problem, which is the whole boundary."""
        import scipy.sparse as sp

        m = s.mesh
        deg = s.case.dg.deg
        mfc = _face_mass(s.basis, deg)
        rows, cols, vals = [], [], []
        dirichlet = []
        coef = cv * vg / 2.0
        for f in np.flatnonzero(m.face_bc >= 0):
            bc = int(m.face_bc[f])
            nodes = face_nodes[:, f]
            dirichlet.extend(nodes.tolist())
            if s.bcdata.bc_type[bc] != BC_THERMALISING:
                continue
            blk = coef * float(m.face_len[f]) * mfc
            for a in range(nodes.size):
                for b in range(nodes.size):
                    rows.append(nodes[a])
                    cols.append(nodes[b])
                    vals.append(blk[a, b])
        robin = sp.coo_matrix((vals, (rows, cols)), shape=(ng, ng)).tocsr()
        return robin, np.unique(np.asarray(dirichlet, dtype=np.int64))

    # -- application -------------------------------------------------------
    def apply(self, r, out=None):
        nd, nt = self.nd, self.nt
        k = nd * nt
        rt = r[:k].reshape(nd, nt)
        rqx = r[k:2 * k].reshape(nd, nt)
        rqy = r[2 * k:3 * k].reshape(nd, nt)

        # load of  int f phi  with f = Cv r_T / tau_C
        load_f = self.cv_over_tau_c * np.einsum("lmi,mi->li", self.tri_mass, rt)
        rhs = self.scatter @ load_f.ravel()
        load_temp = rhs

        if self.inv_tau_n > 0.0:
            # tau_R * int g . grad phi,  g = r_q / tau_N
            gterm = (np.einsum("ilm,mi->li", self.gx, rqx)
                     + np.einsum("ilm,mi->li", self.gy, rqy))
            load_temp = load_temp + (self.tau_r * self.inv_tau_n) * (
                self.scatter @ gterm.ravel())
        if self.mu > 0.0:
            # - mu tau_R lap f, weakly, on the continuous projection of f
            load_temp = load_temp + (self.mu * self.tau_r) * (
                self.stiff @ self.lu_mass.solve(rhs))

        u = self.lu_temp.solve(load_temp)
        uel = u[self.gid]

        dxi_u = self.dxi @ uel
        det_u = self.det @ uel
        gux = dxi_u * self.gxi[:, 0] + det_u * self.get[:, 0]
        guy = dxi_u * self.gxi[:, 1] + det_u * self.get[:, 1]

        bx = np.einsum("lmi,mi->li", self.tri_mass,
                       rqx * self.inv_tau_n - self.p_coef * gux)
        by = np.einsum("lmi,mi->li", self.tri_mass,
                       rqy * self.inv_tau_n - self.p_coef * guy)
        bx = self.scatter @ bx.ravel()
        by = self.scatter @ by.ravel()
        if self.dirichlet.size:
            bx[self.dirichlet] = 0.0
            by[self.dirichlet] = 0.0
        uqx = self.lu_flux.solve(bx)[self.gid]
        uqy = self.lu_flux.solve(by)[self.gid]

        out = np.empty_like(r) if out is None else out
        out[:k] = (rt + uel).ravel()
        out[k:2 * k] = (rqx + uqx).ravel()
        out[2 * k:3 * k] = (rqy + uqy).ravel()
        if r.size > 3 * k:
            out[3 * k:] = r[3 * k:]
        return out


def _face_mass(basis, deg):
    """``int_[-1,1] phi_a phi_b dt / 2`` for the 1-D nodal basis."""
    from .quadrature import gauss_legendre

    t, w = gauss_legendre(deg + 2, -1.0, 1.0)
    phi = basis.eval_fc(t)                       # (nq, deg+1)
    return 0.5 * np.einsum("q,qa,qb->ab", w, phi, phi)


# ---------------------------------------------------------------------------
# GMRES
# ---------------------------------------------------------------------------
def gmres(matvec, b, tol, maxiter, precond=None, callback=None):
    """Right-preconditioned GMRES, no restart.

    Returns ``(x, residuals)``; ``residuals`` are relative to ``|b|`` and
    ``x`` solves ``A x = b`` to the last of them.  Orthogonalisation is
    classical Gram-Schmidt applied twice, which is as stable as the modified
    version and runs as one BLAS-2 call per pass instead of ``m`` dots.
    """
    n = b.size
    bnorm = float(np.linalg.norm(b))
    if bnorm == 0.0:
        return np.zeros(n), [0.0]
    maxiter = max(1, int(maxiter))
    q = np.empty((maxiter + 1, n))
    h = np.zeros((maxiter + 1, maxiter))
    cs = np.zeros(maxiter)
    sn = np.zeros(maxiter)
    g = np.zeros(maxiter + 1)
    zs = [] if precond is not None else None

    q[0] = b / bnorm
    g[0] = bnorm
    residuals = []
    m = 0
    for j in range(maxiter):
        if precond is not None:
            z = precond(q[j])
            zs.append(z)
        else:
            z = q[j]
        w = matvec(z)
        # Arnoldi, classical Gram-Schmidt twice
        qj = q[:j + 1]
        c1 = qj @ w
        w -= c1 @ qj
        c2 = qj @ w
        w -= c2 @ qj
        h[:j + 1, j] = c1 + c2
        hj = float(np.linalg.norm(w))
        h[j + 1, j] = hj
        # apply the previous Givens rotations to the new column
        for i in range(j):
            t = cs[i] * h[i, j] + sn[i] * h[i + 1, j]
            h[i + 1, j] = -sn[i] * h[i, j] + cs[i] * h[i + 1, j]
            h[i, j] = t
        denom = np.hypot(h[j, j], hj)
        if denom == 0.0:
            cs[j], sn[j] = 1.0, 0.0
        else:
            cs[j], sn[j] = h[j, j] / denom, hj / denom
        h[j, j] = cs[j] * h[j, j] + sn[j] * hj
        h[j + 1, j] = 0.0
        g[j + 1] = -sn[j] * g[j]
        g[j] = cs[j] * g[j]
        res = abs(g[j + 1]) / bnorm
        residuals.append(res)
        m = j + 1
        if callback is not None:
            callback(res)
        if res < tol:
            break
        if hj <= 1e-300:
            break
        q[j + 1] = w / hj
    yy = _solve_upper(h[:m, :m], g[:m])
    if precond is not None:
        x = np.zeros(n)
        for i in range(m):
            x += yy[i] * zs[i]
    else:
        x = yy @ q[:m]
    return x, residuals


def _solve_upper(r, g):
    m = g.size
    y = np.zeros(m)
    for i in range(m - 1, -1, -1):
        s = g[i] - r[i, i + 1:m] @ y[i + 1:m]
        y[i] = s / r[i, i] if r[i, i] != 0.0 else 0.0
    return y
