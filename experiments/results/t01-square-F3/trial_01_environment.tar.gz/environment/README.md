# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, transport sweeps driven by a
synthetically accelerated Krylov solve.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/kn_1e-3.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte cases/kn_1e-3.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## What one sweep does

    sweep()                 # exact transport solve, one direction at a time,
                            # in a topological order of the element graph
    compute_moments()       # T, qx, qy from the distribution

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

## How the outer loop works

Repeating that pair until successive temperatures stop moving -- source
iteration, `Solver.run_source_iteration` -- is a Richardson iteration on the
discrete transport system.  Its contraction factor is `1 - O((mfp/L)^2)` in
the diffusive limit and `1 - O(tau_C/tau_R)` in the hydrodynamic one, so it
needs tens of thousands of sweeps at `tau_R = 1e-3` and its *step* stops being
informative about its *error* long before that (see
`RunRecord.error_estimate`).

`Solver.run` solves the same system by a different route, in `pybte/accel.py`.
The sweep, the discretisation and the boundary treatment are untouched -- only
the loop around them changes -- so the fixed point, and therefore the answer,
is the same one source iteration converges to.  It is reached in 12-55 sweeps
across the shipped cases instead of 10^3-10^6.

    u = (T, qx, qy dofs; the distribution behind a periodic face;
         the diffuse wall emission)          # everything a sweep reads
    u' = P u + c                             # one sweep: an affine map
    solve (I - P) u = c                      # GMRES, matvec = one sweep

preconditioned with the diffusion limit of that same discrete system: an
interior-penalty **DG** discretisation of `-div(kappa grad dT)` with
`kappa = cv vg^2 tau_R / 3` and a Marshak wall condition, plus a vector
Helmholtz solve for the momentum correction with the Guyer-Krumhansl viscosity
`nu = tau_C vg^2 / 5`, plus a P1 reconstruction of the correction on the
periodic-trace and wall-emission components.  The low-order operators are
1200 x 1200 sparse and are factorised once, in numpy/scipy; the module adds no
jitted kernel.

`record.iterations` counts transport sweeps either way.

## Cases

Three boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)
    F3_*   east and west walls periodic (the mesh's two side boundaries are
           paired; `bc.py` matches their faces)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the reduced state, the low-order operators, GMRES
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `NAZIM` is silently forced even.
* The integral tensors are assembled with numpy's `power` rather than a
  Python-level `math.pow` loop; that is one ulp on ~5% of entries and moves
  the converged temperature by 8e-12 relative.  Set
  `pybte.integration.EXACT_POW = True` to recover bit-identity with the
  Fortran at the cost of ~70 ms of setup.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
