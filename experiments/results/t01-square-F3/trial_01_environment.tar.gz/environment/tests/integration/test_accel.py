"""The accelerated outer loop must land on the source iteration's fixed point.

Gate: same sweep, same discretisation, same answer -- only fewer sweeps.

The three checks below are the ones that would catch an "acceleration" that
silently solves a different problem: the reduced map must *be* the shipped
iteration, the converged state must satisfy the discrete transport system,
and the temperature must agree with what source iteration converges to.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte.accel import ReducedState
from pybte.moments import Moments, compute_moments

from ..conftest import CASES

FAMILIES = ["F1_1e-1", "F2_1e-1", "F3_1e-1"]


def _case(name, **kw):
    c = Case.from_yaml(CASES / f"{name}.yaml")
    c.output.field = c.output.run_record = c.output.runtime_log = False
    for k, v in kw.items():
        setattr(c.iteration, k, v)
    return c


@pytest.mark.parametrize("name", FAMILIES)
def test_reduced_map_is_the_shipped_step(name):
    """``ReducedState.apply`` must reproduce ``Solver.step`` bit for bit.

    That equality is the whole argument that the accelerated solve has the
    same fixed point: it is not a similar iteration, it is the same one,
    written as an affine map on the state a sweep actually reads.
    """
    shipped = Solver(_case(name))
    reduced_solver = Solver(_case(name))
    red = ReducedState(reduced_solver)

    u = np.zeros(red.n)
    for k in range(6):
        shipped.step()
        u = red.apply(u)
        assert np.array_equal(shipped.vdf, reduced_solver.vdf), f"step {k + 1}"
        assert np.array_equal(shipped.mom.temp, reduced_solver.mom.temp)


@pytest.mark.parametrize("name", FAMILIES)
def test_converged_state_solves_the_discrete_system(name):
    """``||A f - b|| / ||b||`` from the converged distribution alone."""
    s = Solver(_case(name))
    rec = s.run()
    assert rec.converged

    mom = Moments.zeros(s.ndof, s.n_tris)
    compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                    s.integrals.int_tri, s.case.flow.cv, mom)
    s.bcdata.update_wall_flux(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                              s.integrals.int_tri_fc, s.mesh)
    assert s.ctx.true_residual(mom, s.vdf) < 1e-9
    # what the record reports is what the distribution says
    assert np.allclose(mom.temp, rec.temp, rtol=1e-14, atol=0.0)


@pytest.mark.parametrize("name", FAMILIES)
def test_agrees_with_source_iteration(name):
    """The two loops converge to the same temperature field."""
    fast = Solver(_case(name)).run()
    slow = Solver(_case(name, tol=1e-13, tmax=50_000)).run_source_iteration()
    assert slow.converged and fast.converged
    assert fast.iterations < slow.iterations / 10
    rel = np.abs(fast.temp - slow.temp) / np.abs(slow.temp)
    assert rel.max() < 1e-7, f"worst element {rel.max():.3e}"


def test_sweep_is_still_the_interface():
    """``solver.ctx.sweep(solver.mom, solver.vdf)`` stays a full sweep."""
    s = Solver(_case("F1_1e-1"))
    s.run()
    before = s.vdf.copy()
    n = s.ctx.sweep_count
    s.ctx.sweep(s.mom, s.vdf)
    assert s.ctx.sweep_count == n + 1
    # at the fixed point one more sweep changes essentially nothing
    assert np.abs(s.vdf - before).max() <= 1e-9 * np.abs(before).max()


def test_respects_tmax():
    s = Solver(_case("F1_1e-3", tmax=7))
    rec = s.run()
    assert rec.iterations <= 7
    assert rec.sweep_count <= 7
