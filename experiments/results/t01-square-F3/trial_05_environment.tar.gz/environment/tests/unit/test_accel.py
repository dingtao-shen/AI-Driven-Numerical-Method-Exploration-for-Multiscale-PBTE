"""The Krylov outer solver and its coarse-angle synthetic preconditioner.

Gate: the accelerated solver must land on the *same* discrete fixed point
the plain source iteration converges to, and its reported residual must be
the transport residual a verifier would compute from the distribution.
"""
from __future__ import annotations

import numpy as np
import pytest

from pybte import Case, Solver
from pybte._kernels import transport_residual
from pybte.accel import (CoarsePreconditioner, CoarseSystem, MomentOperator,
                         coarse_quadrature, gmres, nested_dissection)
from pybte.constants import PI

from ..conftest import CASES

FAMILIES = {"F1": "F1_1e-3.yaml", "F2": "F2_1e-3.yaml", "F3": "F3_1e-3.yaml"}


def _case(name, **flow):
    c = Case.from_yaml(CASES / name)
    c.output.field = c.output.run_record = c.output.runtime_log = False
    for k, v in flow.items():
        setattr(c.flow, k, v)
    return c


def _strict_residual(solver):
    """``||A f - b|| / ||b_wall||`` from the shipped residual kernel."""
    ctx, mom, vdf = solver.ctx, solver.mom, solver.vdf
    ndir = ctx.cxv.size
    num = np.zeros(ndir)
    den = np.zeros(ndir)
    transport_residual(ctx.cxv, ctx.cyv, ctx.domega, ctx.cv, ctx.vg,
                       ctx.tau_r, ctx.tau_n, ctx.tau_c, PI,
                       ctx.mass, ctx.gx, ctx.gy, ctx.fcm, ctx.ttfc, ctx.nx, ctx.ny,
                       ctx.tri_faces, ctx.face_bc, ctx.neighbour, ctx.periodic_tri,
                       ctx.bc_type, ctx.bc_temp, ctx.flux_wall,
                       mom.ts, mom.qxs, mom.qys, vdf, num, den)
    op = MomentOperator(solver)
    op._setup_residual()
    return np.sqrt(num.sum()) / op.boundary_norm, np.sqrt(num.sum() / den.sum())


def test_gmres_solves_a_small_system():
    rng = np.random.default_rng(3)
    n = 40
    A = np.eye(n) + 0.3 * rng.normal(size=(n, n))
    b = rng.normal(size=n)
    x, hist, y = gmres(lambda v: A @ v, b, tol=1e-12, relative_to="rhs")
    assert np.linalg.norm(A @ x - b) / np.linalg.norm(b) < 1e-11
    # with a preconditioner it converges in one step
    Ainv = np.linalg.inv(A)
    x, hist, y = gmres(lambda v: A @ v, b, precond=lambda v: Ainv @ v, tol=1e-12,
                       relative_to="rhs")
    assert len(hist) == 1 and np.allclose(x, Ainv @ b)


def test_coarse_quadrature_moments():
    for n in (4, 5, 6, 8):
        cx, cy, w = coarse_quadrature(n)
        assert w.sum() == pytest.approx(4 * PI)
        assert abs((w * cx).sum()) < 1e-14 and abs((w * cy).sum()) < 1e-14
        assert (w * cx * cx).sum() == pytest.approx(4 * PI / 3)
        assert (w * cy * cy).sum() == pytest.approx(4 * PI / 3)
        assert abs((w * cx * cy).sum()) < 1e-14


def test_nested_dissection_is_a_permutation(shipped_mesh):
    cent = shipped_mesh.nodes[shipped_mesh.tri_nodes].mean(axis=1)
    adj = [[int(t) for t in shipped_mesh.tri_neighbour[i] if t >= 0]
           for i in range(shipped_mesh.n_tris)]
    perm = nested_dissection(cent, adj)
    assert np.array_equal(np.sort(perm), np.arange(shipped_mesh.n_tris))


@pytest.mark.parametrize("name", ["F1_1e-1.yaml", "F2_1e-1.yaml"])
def test_coarse_assembly_reproduces_the_sweep(name):
    """Assembled with the *fine* quadrature, the coupled system's direct
    solution is a fixed point of the shipped sweep: the assembly encodes
    exactly the operator the kernels apply, walls included."""
    c = _case(name)
    c.velmesh.npole, c.velmesh.nazim = 4, 8
    s = Solver(c)
    op = MomentOperator(s)
    cs = CoarseSystem.build(s.ctx, op, s.ctx.cxv, s.ctx.cyv, s.ctx.domega)
    pre = CoarsePreconditioner(op, cs)
    cvec = op.constant()
    x = pre(cvec)                       # (I - L)^{-1} c, exactly
    Lx = op.apply_L(x)
    assert np.linalg.norm(Lx + cvec - x) / np.linalg.norm(x) < 1e-12


@pytest.mark.parametrize("fam", sorted(FAMILIES))
def test_krylov_reaches_the_source_iteration_fixed_point(fam):
    """Where CIS converges, both schemes give the same answer."""
    c = _case(FAMILIES[fam], tau_r=1.0, tau_n=1.0)
    c.velmesh.npole, c.velmesh.nazim = 4, 8
    c.scheme.accel = "cis"
    c.iteration.tol = 1e-13
    c.iteration.tmax = 5000
    a = Solver(c)
    ra = a.run()
    assert ra.converged

    c = _case(FAMILIES[fam], tau_r=1.0, tau_n=1.0)
    c.velmesh.npole, c.velmesh.nazim = 4, 8
    b = Solver(c)
    rb = b.run()
    assert rb.converged and rb.iterations < ra.iterations
    assert np.abs(rb.temp - ra.temp).max() <= 1e-7 * np.abs(ra.temp).max()
    assert np.abs(b.vdf - a.vdf).max() <= 1e-7 * np.abs(a.vdf).max()


@pytest.mark.parametrize("fam", sorted(FAMILIES))
def test_stiff_cases_converge_to_the_discrete_system(fam):
    """The shipped cases at tau_R = 1e-3, where source iteration needs tens
    of thousands of sweeps: a few sweeps, a transport residual far below
    1e-7 in the strictest normalisation, and moments consistent with the
    distribution."""
    c = _case(FAMILIES[fam])
    s = Solver(c)
    rec = s.run()
    assert rec.converged
    assert rec.iterations == rec.sweep_count <= 20
    strict, shipped = _strict_residual(s)
    assert strict < 1e-8 and shipped < 1e-8
    assert rec.final_residual == pytest.approx(strict, rel=1e-6)
    # the reported temperature is the one recomputed from the distribution
    from pybte.moments import Moments, compute_moments
    m = Moments.zeros(s.ndof, s.n_tris)
    compute_moments(s.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                    s.integrals.int_tri, c.flow.cv, m)
    assert np.array_equal(m.temp, rec.temp)


def test_hydrodynamic_regime_uses_six_directions():
    c = _case("F2_10_1e-2.yaml")
    s = Solver(c)
    rec = s.run()
    assert rec.converged and rec.diagnostics["coarse_dirs"] == 6
    assert rec.iterations <= 20


def test_sweep_still_callable_after_run():
    """Gate 4: ``solver.ctx.sweep(solver.mom, solver.vdf)`` performs one full
    sweep from the current moments -- and at the fixed point it is idle."""
    c = _case("F1_1e-2.yaml")
    s = Solver(c)
    s.run()
    before = s.vdf.copy()
    n = s.ctx.sweep_count
    s.ctx.sweep(s.mom, s.vdf)
    assert s.ctx.sweep_count == n + 1
    assert np.abs(s.vdf - before).max() <= 1e-7 * np.abs(before).max()


def test_cis_scheme_still_available():
    c = _case("F1_1e-1.yaml")
    c.scheme.accel = "cis"
    c.iteration.tmax = 20
    rec = Solver(c).run()
    assert rec.scheme == "CIS" and rec.iterations == 20 and not rec.converged
