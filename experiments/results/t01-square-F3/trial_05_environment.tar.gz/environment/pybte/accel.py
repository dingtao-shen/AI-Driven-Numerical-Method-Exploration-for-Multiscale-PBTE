"""Krylov acceleration of the source iteration with a coarse-angle synthetic
preconditioner.

The outer iteration of ``driver.py`` is a fixed-point map,

    x  ->  G(x) = L x + c,        x = (T_s, qx_s, qy_s, f_wall, f_lag)

where one evaluation of ``G`` is one transport sweep followed by the moment
update.  The state ``x`` is everything the sweep reads besides the wall
temperatures:

* the three moment fields the scattering source is built from;
* the diffuse-wall emission ``flux_wall`` of non-thermalising faces;
* for periodic faces, the distribution on the element behind the partner
  face, in the directions that flow in through the face.  The sweep cannot
  order elements across a periodic pair (the dependency is cyclic) and so
  reads the partner's ``vdf`` as it stands -- last pass, or this pass if the
  partner was already visited.  Carrying those values in the state makes one
  sweep a well-defined affine map whose fixed point is the exact discrete
  solution, periodic coupling included.

The map is affine because the sweep is linear in its scattering source, in
the wall emission and in the inflow, and ``c`` is what the sweep returns
with all of those zero.  The converged distribution is the fixed point
``x = G(x)``, i.e. the solution of ``(I - L) x = c``.  Source iteration is
Richardson's method on this system, and its contraction ``rho -> 1`` as the
medium becomes optically thick or normal scattering dominates.

Here the system is solved with right-preconditioned GMRES.  Each Krylov
vector costs exactly one sweep (``L v`` is the sweep with the wall
temperatures zeroed), and the preconditioner is a *coarse-angle synthetic*
solve: the same nodal-DG discretisation, the same integral tensors and the
same three boundary treatments, but with a handful of discrete directions
instead of ``NPOLE * NAZIM``.  That small transport system -- with its
scattering, wall-emission and periodic coupling folded in -- is assembled as
one sparse matrix and LU-factorised once by SuperLU; applying the
preconditioner is a sparse triangular solve.  Because the spatial
discretisation is identical, the preconditioner captures the slowly
converging diffusive and hydrodynamic modes exactly in space and only
approximately in angle, which is all a Krylov method needs.

Nothing here changes the discrete system whose fixed point is sought: the
sweep kernel and the moment kernel are those of ``_kernels.py``, and the
final state is produced by one plain sweep from the converged moments.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import BC_NONTHERMALISING, BC_PERIODIC, PI
from .moments import compute_moments

__all__ = ["coarse_quadrature", "MomentOperator", "CoarseSystem",
           "CoarsePreconditioner", "gmres"]


# ---------------------------------------------------------------------------
# coarse angular quadrature
# ---------------------------------------------------------------------------
def coarse_quadrature(n_dir: int = 6, offset: float = 0.3):
    """``n_dir`` in-plane directions on one ring, equal weights.

    The ring radius is chosen so that the zeroth, first and second angular
    moments of the true (sphere-projected) quadrature are reproduced
    exactly: ``sum w = 4 pi``, ``sum w c = 0``, ``sum w c c^T = (4 pi / 3) I``.
    That fixes the diffusion coefficient of the coarse model and makes the
    normal-scattering term conserve momentum in it, which is what the
    preconditioner has to get right.  With five or more directions the
    fourth moments are isotropic as well, which the hydrodynamic regime
    needs.  ``offset`` rotates the ring away from the mesh directions so
    that no coarse direction is tangent to a face.
    """
    if n_dir < 3:
        raise ValueError("need at least three coarse directions")
    ang = offset + 2.0 * PI * np.arange(n_dir) / n_dir
    rad = np.sqrt(2.0 / 3.0)
    return rad * np.cos(ang), rad * np.sin(ang), np.full(n_dir, 4.0 * PI / n_dir)


# ---------------------------------------------------------------------------
# element ordering for the sparse factorisation
# ---------------------------------------------------------------------------
def nested_dissection(centroids, adjacency, leaf: int = 8) -> np.ndarray:
    """Geometric nested dissection of the element graph.

    Recursive coordinate bisection; the separator at each level is the set
    of elements on the lower side that touch the upper side, numbered last.
    On these meshes the resulting natural-order LU has 10-45% less fill than
    SuperLU's minimum-degree orderings, and the factorisation is faster in
    proportion.  Returns ``order[p]`` = element at position ``p``.
    """
    order: list = []

    def rec(ids):
        if ids.size <= leaf:
            order.extend(ids.tolist())
            return
        pts = centroids[ids]
        ax = int(np.argmax(pts.max(axis=0) - pts.min(axis=0)))
        med = np.median(pts[:, ax])
        lower = ids[pts[:, ax] <= med]
        upper = ids[pts[:, ax] > med]
        if lower.size == 0 or upper.size == 0:
            order.extend(ids.tolist())
            return
        up = set(upper.tolist())
        sep = np.array([any(nb in up for nb in adjacency[i]) for i in lower])
        rec(lower[~sep])
        rec(upper)
        order.extend(lower[sep].tolist())

    rec(np.arange(centroids.shape[0]))
    return np.asarray(order, dtype=np.int64)


# ---------------------------------------------------------------------------
# the fixed-point map as an affine operator
# ---------------------------------------------------------------------------
class MomentOperator:
    """``x -> L x`` and ``c`` for the fixed-point map of the outer iteration.

    ``apply_L(x)`` is the homogeneous part (wall temperatures zeroed) and
    ``constant()`` is ``G(0)``; both cost exactly one sweep.  ``finish``
    leaves the distribution of a converged state in ``solver.vdf``.
    """

    def __init__(self, solver, keep: int = 64):
        self.s = solver
        ctx = solver.ctx
        self.nd, self.n_tris, self.ndir = solver.ndof, solver.n_tris, solver.ndir
        self.k = self.nd * self.n_tris

        bc = ctx.face_bc
        typ = np.where(bc >= 0, ctx.bc_type[np.maximum(bc, 0)], -1)
        self.wall_faces = np.flatnonzero(typ == BC_NONTHERMALISING)
        self.n_wall = self.wall_faces.size * self.nd

        # periodic lag: (direction, partner element) pairs the sweep reads
        el, il, part = [], [], []
        for i in range(self.n_tris):
            for j in range(3):
                f = int(ctx.tri_faces[i, j])
                if typ[f] == BC_PERIODIC:
                    el.append(i)
                    il.append(j)
                    part.append(int(ctx.periodic_tri[f]))
        self.per_el = np.asarray(el, dtype=np.int64)
        self.per_il = np.asarray(il, dtype=np.int64)
        self.per_tri = np.asarray(part, dtype=np.int64)
        if self.per_el.size:
            speed = (ctx.cxv[:, None] * ctx.nx[self.per_el, self.per_il][None]
                     + ctx.cyv[:, None] * ctx.ny[self.per_el, self.per_il][None])
            # only pairs the sweep reads *before* visiting the partner are
            # state; when the partner comes first in the sweep order the
            # inflow is this pass's fresh value (Gauss-Seidel) and carries no
            # lag at all
            pos = np.empty_like(ctx.order)
            np.put_along_axis(pos, ctx.order, np.arange(self.n_tris, dtype=pos.dtype)[None, :], axis=1)
            stale = pos[:, self.per_tri] > pos[:, self.per_el]         # (ndir, n_pf)
            self.lag_d, self.lag_f = np.nonzero((speed < 0.0) & stale)  # (n_lag,)
        else:
            self.lag_d = self.lag_f = np.zeros(0, dtype=np.int64)
        self.lag_tri = self.per_tri[self.lag_f]
        self.n_lag = self.lag_d.size * self.nd
        self.n = 3 * self.k + self.n_wall + self.n_lag

        self.zero_temp = np.zeros_like(ctx.bc_temp)
        self.work = np.zeros_like(solver.vdf)
        self.sweeps = 0
        # the distributions behind c and each L z_j, kept so that the
        # converged distribution can be assembled by linearity instead of
        # by one more sweep (see ``finish``)
        self.keep = keep
        self.vdf_c = None
        self.vdf_hist: list = []

    # -- packing -----------------------------------------------------------
    def unpack(self, x, vdf):
        m = self.s.mom
        k = self.k
        m.ts[:] = x[:k].reshape(self.nd, self.n_tris)
        m.qxs[:] = x[k:2 * k].reshape(self.nd, self.n_tris)
        m.qys[:] = x[2 * k:3 * k].reshape(self.nd, self.n_tris)
        if self.n_wall:
            self.s.bcdata.flux_wall[self.wall_faces] = \
                x[3 * k:3 * k + self.n_wall].reshape(-1, self.nd)
        if self.n_lag:
            vdf[self.lag_d, self.lag_tri, :] = \
                x[3 * k + self.n_wall:].reshape(-1, self.nd)

    def pack(self, vdf):
        m = self.s.mom
        parts = [m.ts.ravel(), m.qxs.ravel(), m.qys.ravel()]
        if self.n_wall:
            parts.append(self.s.bcdata.flux_wall[self.wall_faces].ravel())
        if self.n_lag:
            parts.append(vdf[self.lag_d, self.lag_tri, :].ravel())
        return np.concatenate(parts)

    def split(self, x):
        """``(ts, qxs, qys, fw, lag)`` views of a state vector."""
        k = self.k
        return (x[:k].reshape(self.nd, self.n_tris),
                x[k:2 * k].reshape(self.nd, self.n_tris),
                x[2 * k:3 * k].reshape(self.nd, self.n_tris),
                x[3 * k:3 * k + self.n_wall].reshape(-1, self.nd),
                x[3 * k + self.n_wall:].reshape(-1, self.nd))

    @staticmethod
    def join(ts, qxs, qys, fw, lag):
        return np.concatenate([ts.ravel(), qxs.ravel(), qys.ravel(),
                               fw.ravel(), lag.ravel()])

    # -- the sweep ---------------------------------------------------------
    def _sweep(self, vdf, bc_temp):
        self.s.ctx.sweep(self.s.mom, vdf, bc_temp=bc_temp)
        self.sweeps += 1
        self._moments_of(vdf)

    def apply_L(self, x):
        # sweep straight into a fresh history slot: the sweep never reads
        # the array's prior contents except the periodic-lag entries, which
        # ``unpack`` sets
        if len(self.vdf_hist) < self.keep:
            vdf = np.empty_like(self.work)
            self.vdf_hist.append(vdf)
        else:
            vdf = self.work
        self.unpack(x, vdf)
        self._sweep(vdf, self.zero_temp)
        return self.pack(vdf)

    def constant(self, x0=None):
        """``G(x0)`` -- the full map, wall temperatures included -- from the
        state ``x0`` (zero by default), keeping its distribution as the
        affine offset ``finish`` builds on.  ``G(0)`` is ``c``."""
        self.unpack(np.zeros(self.n) if x0 is None else x0, self.work)
        self._sweep(self.work, self.s.ctx.bc_temp)
        self.vdf_c = self.work.copy()
        return self.pack(self.work)

    def state_of(self, vdf):
        """The state ``(moments, wall emission, lag)`` a distribution defines."""
        self._moments_of(vdf)
        return self.pack(vdf)

    def residual_matvec(self, v):
        """``(I - L) v``."""
        return v - self.apply_L(v)

    def state_weights(self):
        """Per-component weights making the Euclidean norm of a state
        residual track the transport residual it generates.

        The temperature moments enter the source with ``alpha``, the heat
        flux with ``beta`` -- a ratio of ``3 tau_R / tau_N`` when normal
        scattering is weak, so an unweighted norm would have GMRES chase a
        flux mismatch that is invisible to the discrete system.  Wall
        emission and periodic inflow enter through the face tensors with
        the upwind speed, and are given that typical size.
        """
        ctx = self.s.ctx
        alpha = ctx.cv / (4.0 * PI) * (1.0 / ctx.tau_r + 1.0 / ctx.tau_n)
        beta = 3.0 / (4.0 * PI) / ctx.tau_n / (ctx.vg * ctx.vg)
        mbar = float(np.mean(np.abs(ctx.mass)))
        fbar = float(np.mean(np.abs(ctx.ttfc)))
        w = np.empty(self.n)
        k = self.k
        w[:k] = alpha * mbar
        w[k:3 * k] = beta * mbar * np.sqrt(2.0 / 3.0)
        w[3 * k:] = 0.5 * fbar
        return w / (alpha * mbar)

    # -- the transport residual of a state, without a sweep -------------
    def _setup_residual(self):
        ctx = self.s.ctx
        nx, ny = ctx.nx, ctx.ny
        w, cx, cy = ctx.domega, ctx.cxv, ctx.cyv
        self._massT = np.ascontiguousarray(np.transpose(ctx.mass, (2, 1, 0)))
        self._alpha = ctx.cv / (4.0 * PI) * (1.0 / ctx.tau_r + 1.0 / ctx.tau_n)
        self._beta = 3.0 / (4.0 * PI) / ctx.tau_n / (ctx.vg * ctx.vg)
        # angular moments of the quadrature: sum_d w (a + b cx + c cy)^2 is
        # a fixed quadratic form in (a, b, c)
        self._q = np.array([w.sum(), (w * cx * cx).sum(), (w * cy * cy).sum(),
                            (w * cx).sum(), (w * cy).sum(), (w * cx * cy).sum()])
        # elements whose source has a direction-resolved part (walls, lag)
        aff = []
        if self.n_wall:
            adj = [self.s.mesh.adjacent(int(f)) for f in self.wall_faces]
            self._wtri = np.asarray([t for t, _ in adj])
            wl = np.asarray([l for _, l in adj])
            sp = cx[:, None] * nx[self._wtri, wl][None] + cy[:, None] * ny[self._wtri, wl][None]
            self._wm_wall = 0.5 * (sp - np.abs(sp))                     # (ndir, n_w)
            aff.append(self._wtri)
        if self.n_lag:
            sp = (cx[self.lag_d] * nx[self.per_el, self.per_il][self.lag_f]
                  + cy[self.lag_d] * ny[self.per_el, self.per_il][self.lag_f])
            self._wm_lag = 0.5 * (sp - np.abs(sp))                      # (n_lag,)
            self._ttfc_lag = ctx.ttfc[self.per_el[self.lag_f], self.per_il[self.lag_f]]
            self._lag_el = self.per_el[self.lag_f]
            aff.append(self._lag_el)
        self._aff = np.unique(np.concatenate(aff)) if aff else np.zeros(0, dtype=np.int64)
        aff_pos = np.full(self.n_tris, -1, dtype=np.int64)
        aff_pos[self._aff] = np.arange(self._aff.size)
        if self.n_wall:
            self._wpos = aff_pos[self._wtri]
        if self.n_lag:
            self._lpos = aff_pos[self._lag_el]
        # the boundary data: thermalising-wall inflow, in the weighted norm
        bw2 = 0.0
        for il in range(3):
            fc = ctx.tri_faces[:, il]
            bc = ctx.face_bc[fc]
            therm = bc >= 0
            therm[therm] = ctx.bc_type[bc[therm]] == 1
            if not np.any(therm):
                continue
            el = np.flatnonzero(therm)
            sp = cx[:, None] * nx[el, il][None] + cy[:, None] * ny[el, il][None]
            wm = 0.5 * (sp - np.abs(sp))                                 # (ndir, n_el)
            tw = ctx.cv / (4.0 * PI) * ctx.bc_temp[bc[el]]              # (n_el,)
            contrib = (wm * tw[None, :])[:, :, None] * ctx.ttfc[el, il, :, 0][None]
            bw2 += float(np.sum(w[:, None, None] * contrib ** 2))
        self.boundary_norm = np.sqrt(bw2)
        self._residual_ready = True

    def transport_residual(self, r):
        """``||A f - b|| / ||b||`` of the distribution ``f = sweep(x)`` whose
        state residual is ``r = x - G(x)``, in the solid-angle-weighted norm,
        with ``b`` the thermalising-wall inflow alone (everything else --
        scattering, wall emission, periodic coupling -- counted in ``A``).

        ``A f`` differs from the sources the sweep was fed only through the
        mismatch between the state and what the distribution generated, so
        the residual is the source operator applied to ``r``; no sweep is
        needed.  This is the strictest of the usual normalisations.
        """
        if not getattr(self, "_residual_ready", False):
            self._setup_residual()
        ctx = self.s.ctx
        ts, qxs, qys, fw, lag = self.split(r)
        # scattering source of the moment mismatch: a + b cx + c cy per (i, m)
        a = np.einsum("iml,li->im", self._massT, ts) * self._alpha       # (i, m)
        if self._beta != 0.0:
            b = np.einsum("iml,li->im", self._massT, qxs) * self._beta
            c = np.einsum("iml,li->im", self._massT, qys) * self._beta
        else:
            b = c = np.zeros_like(a)
        q = self._q
        per_el = (q[0] * (a * a) + q[1] * (b * b) + q[2] * (c * c)
                  + 2.0 * (q[3] * a * b + q[4] * a * c + q[5] * b * c)).sum(axis=1)
        num2 = float(per_el.sum())
        if self._aff.size:
            # elements with wall emission or periodic inflow: resolve in angle
            k = self._aff
            src = (a[k][None] + ctx.cxv[:, None, None] * b[k][None]
                   + ctx.cyv[:, None, None] * c[k][None])                # (d, k, m)
            if self.n_wall:
                np.add.at(src, (slice(None), self._wpos), self._wm_wall[:, :, None] * fw[None])
            if self.n_lag:
                inflow = np.einsum("kml,kl->km", self._ttfc_lag, lag)
                np.add.at(src, (self.lag_d, self._lpos), -self._wm_lag[:, None] * inflow)
            num2 += float(np.einsum("d,dkm,dkm->", ctx.domega, src, src)) - float(per_el[k].sum())
        return np.sqrt(max(num2, 0.0)) / self.boundary_norm

    def _moments_of(self, vdf):
        """Moments and wall emission of ``vdf`` into the solver's state."""
        s = self.s
        compute_moments(vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                        s.integrals.int_tri, s.case.flow.cv, s.mom)
        s.bcdata.update_wall_flux(vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                                  s.integrals.int_tri_fc, s.mesh)

    def finish(self, x, coeffs=None):
        """Leave the converged distribution in ``solver.vdf`` with moments
        and wall emission consistent with it.

        The sweep is affine, so the distribution belonging to
        ``x = x0 + sum_j coeffs[j] z_j`` is ``vdf_c + sum_j coeffs[j] vdf_j``
        with ``vdf_c`` the distribution ``constant(x0)`` produced and
        ``vdf_j`` the one of the ``j``-th ``apply_L``.  When those are all
        on hand this costs an axpy per Krylov vector instead of a sweep;
        otherwise one plain sweep from ``x`` is performed.
        """
        vdf = self.s.vdf
        if (coeffs is not None and self.vdf_c is not None
                and len(self.vdf_hist) >= len(coeffs)):
            vdf[:] = self.vdf_c
            for cj, vj in zip(coeffs, self.vdf_hist):
                vdf += cj * vj
            self._moments_of(vdf)
        else:
            self.unpack(x, vdf)
            self._sweep(vdf, self.s.ctx.bc_temp)
        self.vdf_hist.clear()
        self.vdf_c = None


# ---------------------------------------------------------------------------
# the coarse coupled system
# ---------------------------------------------------------------------------
@dataclass
class CoarseSystem:
    """``K g = s`` for the coarse-angle transport problem, with the scattering
    source, the diffuse-wall emission and the periodic coupling folded into
    ``K``.  Unknowns are ordered ``(element, direction, dof)``, element-major,
    so the dense in-element scattering block is contiguous.
    """
    cx: np.ndarray
    cy: np.ndarray
    w: np.ndarray
    lu: spla.SuperLU
    nnz: int
    nd: int
    n_tris: int
    alpha: float
    beta: float
    cv: float
    massT: np.ndarray                   # (i, m, l) = mass[l, m, i]
    wminus: np.ndarray                  # (n_c, n_tris, 3)  0.5 * (s - |s|)
    # diffusely reflecting walls
    wall_tri: np.ndarray                # (n_w,) element behind each wall face
    wall_lfc: np.ndarray                # (n_w,) its local edge
    wall_emit: np.ndarray               # (n_w, n_c) weight of g[d, tri] in flux_wall
    wall_fcm: np.ndarray                # (n_w, m, l)
    # periodic lag (see MomentOperator)
    per_el: np.ndarray                  # (n_pf,) element owning each periodic face
    per_il: np.ndarray                  # (n_pf,)
    per_tri: np.ndarray                 # (n_pf,) partner element
    lag_d: np.ndarray                   # (n_lag,) fine direction of each lag entry
    lag_f: np.ndarray                   # (n_lag,) periodic face of each lag entry
    half_inv: np.ndarray                # (n_pf, 3, 3) half-range P1 fit per face
    fcx: np.ndarray
    fcy: np.ndarray
    fw: np.ndarray
    perm: np.ndarray                    # (n_tris,) element at each position
    pos: np.ndarray                     # (n_tris,) position of each element
    K: sp.csc_matrix | None = field(default=None, repr=False)

    @classmethod
    def build(cls, ctx, op: MomentOperator, cx, cy, w, keep_matrix=False,
              ordering="nd", diag_pivot_thresh=0.1, dtype=np.float64):
        cx = np.asarray(cx, dtype=float)
        cy = np.asarray(cy, dtype=float)
        w = np.asarray(w, dtype=float)
        n_c = cx.size
        nd, n_tris = op.nd, op.n_tris
        cv, vg = ctx.cv, ctx.vg
        tau_r, tau_n, tau_c = ctx.tau_r, ctx.tau_n, ctx.tau_c

        mass = np.ascontiguousarray(np.transpose(ctx.mass, (2, 0, 1)))   # (i, m, l)
        massT = np.ascontiguousarray(np.transpose(ctx.mass, (2, 1, 0)))  # (i, m, l) = mass[l, m, i]
        gx, gy, fcm, ttfc = ctx.gx, ctx.gy, ctx.fcm, ctx.ttfc
        nx, ny = ctx.nx, ctx.ny

        # speed through each local edge, per coarse direction
        s = cx[:, None, None] * nx[None] + cy[:, None, None] * ny[None]    # (c, i, il)
        wplus = 0.5 * (s + np.abs(s))
        wminus = 0.5 * (s - np.abs(s))

        # element numbering for the factorisation
        if ordering == "nd":
            mesh = op.s.mesh
            cent = mesh.nodes[mesh.tri_nodes].mean(axis=1)
            adjacency = [[int(t) for t in mesh.tri_neighbour[i] if t >= 0]
                         for i in range(n_tris)]
            for e, t in zip(op.per_el, op.per_tri):
                adjacency[int(e)].append(int(t))
            perm = nested_dissection(cent, adjacency)
            permc_spec = "NATURAL"
        else:
            perm = np.arange(n_tris)
            permc_spec = "MMD_AT_PLUS_A"
        pos = np.empty(n_tris, dtype=np.int64)
        pos[perm] = np.arange(n_tris)

        def idx(d, i):
            return (pos[np.asarray(i)] * n_c + d) * nd

        rows, cols, vals = [], [], []
        m_ = np.arange(nd)

        def add_block(r0, c0, blk):
            """``blk[..., m, l]`` at row bases ``r0`` / column bases ``c0``."""
            rows.append(np.broadcast_to(np.asarray(r0)[..., None, None]
                                        + m_[None, :, None], blk.shape).ravel())
            cols.append(np.broadcast_to(np.asarray(c0)[..., None, None]
                                        + m_[None, None, :], blk.shape).ravel())
            vals.append(np.ascontiguousarray(blk).ravel())

        d_all = np.arange(n_c)
        i_all = np.arange(n_tris)

        # -- transport: the element operator A_SOL(d, i) -------------------
        a = ((1.0 / tau_c) * mass[None]
             - cx[:, None, None, None] * gx[None]
             - cy[:, None, None, None] * gy[None]
             + np.einsum("dik,iklm->dilm", wplus, fcm))               # (c, i, m, l)
        base = idx(d_all[:, None], i_all[None, :])
        add_block(base, base, a)

        # -- transport: upwind inflow from the neighbour or periodic partner --
        for il in range(3):
            fc = ctx.tri_faces[:, il]
            bc = ctx.face_bc[fc]
            interior = bc < 0
            periodic = np.zeros(n_tris, dtype=bool)
            periodic[~interior] = ctx.bc_type[bc[~interior]] == BC_PERIODIC
            iext = np.where(interior, ctx.neighbour[:, il], ctx.periodic_tri[fc])
            sel = np.flatnonzero(interior | periodic)
            for d in range(n_c):
                act = sel[wminus[d, sel, il] < 0.0]
                if act.size:
                    blk = wminus[d, act, il][:, None, None] * ttfc[act, il]
                    add_block(idx(d, act), idx(d, iext[act]), blk)

        # -- scattering: dense within each element --------------------------
        alpha = cv / (4.0 * PI) * (1.0 / tau_r + 1.0 / tau_n)
        beta = 3.0 / (4.0 * PI) / tau_n / (vg * vg)
        cdd = w[None, :] * (alpha / cv + beta * (cx[:, None] * cx[None, :]
                                                  + cy[:, None] * cy[None, :]))
        for d in range(n_c):
            for dp in range(n_c):
                add_block(idx(d, i_all), idx(dp, i_all), -cdd[d, dp] * massT)

        # -- diffuse walls: the emission is linear in g ----------------------
        wall_tri = np.zeros(0, dtype=np.int64)
        wall_lfc = np.zeros(0, dtype=np.int64)
        wall_emit = np.zeros((0, n_c))
        wall_fcm = np.zeros((0, nd, nd))
        if op.wall_faces.size:
            mesh = op.s.mesh
            adj = [mesh.adjacent(int(f)) for f in op.wall_faces]
            wall_tri = np.asarray([t for t, _ in adj], dtype=np.int64)
            wall_lfc = np.asarray([l for _, l in adj], dtype=np.int64)
            # u = c . n_in; u < 0 hits the wall, u >= 0 is emitted into
            u = -(cx[None, :] * nx[wall_tri, wall_lfc][:, None]
                  + cy[None, :] * ny[wall_tri, wall_lfc][:, None])     # (n_w, c)
            out = u < 0.0
            ss2 = -np.sum(np.where(~out, u * w[None, :], 0.0), axis=1)
            wall_emit = np.where(out, u * w[None, :], 0.0) * (-1.0 / ss2)[:, None]
            wall_fcm = fcm[wall_tri, wall_lfc]
            wm_wall = wminus[:, wall_tri, wall_lfc]                    # (c, n_w)
            for d in range(n_c):
                for dp in range(n_c):
                    k = np.flatnonzero((wm_wall[d] < 0.0) & out[:, dp])
                    if k.size:
                        # src[d, t, m] += wm * flux_wall[f, m]  ->  LHS: -=
                        coef = -(wm_wall[d, k] * wall_emit[k, dp])
                        add_block(idx(d, wall_tri[k]), idx(dp, wall_tri[k]),
                                  coef[:, None, None] * wall_fcm[k])

        # -- periodic lag: half-range P1 fit of the fine inflow ---------------
        n_pf = op.per_el.size
        half_inv = np.zeros((n_pf, 3, 3))
        if n_pf:
            fnx = nx[op.per_el, op.per_il]
            fny = ny[op.per_el, op.per_il]
            # moments of a + b.c over the inflow hemisphere, discrete
            speed = (ctx.cxv[:, None] * fnx[None] + ctx.cyv[:, None] * fny[None])
            wi = np.where(speed < 0.0, ctx.domega[:, None], 0.0)      # (ndir, n_pf)
            H = np.empty((n_pf, 3, 3))
            H[:, 0, 0] = wi.sum(axis=0)
            H[:, 0, 1] = H[:, 1, 0] = (wi * ctx.cxv[:, None]).sum(axis=0)
            H[:, 0, 2] = H[:, 2, 0] = (wi * ctx.cyv[:, None]).sum(axis=0)
            H[:, 1, 1] = (wi * ctx.cxv[:, None] ** 2).sum(axis=0)
            H[:, 2, 2] = (wi * ctx.cyv[:, None] ** 2).sum(axis=0)
            H[:, 1, 2] = H[:, 2, 1] = (wi * ctx.cxv[:, None] * ctx.cyv[:, None]).sum(axis=0)
            half_inv = np.linalg.inv(H)

        n = n_c * n_tris * nd
        K = sp.csc_matrix((np.concatenate(vals),
                           (np.concatenate(rows), np.concatenate(cols))),
                          shape=(n, n))
        K.sum_duplicates()
        # Threshold pivoting: full partial pivoting wrecks the fill-reducing
        # ordering on the optically thin systems (10x the factorisation
        # cost); the matrix is far from needing it.
        lu = spla.splu(K.astype(dtype, copy=False), permc_spec=permc_spec,
                       diag_pivot_thresh=diag_pivot_thresh)
        return cls(cx=cx, cy=cy, w=w, lu=lu, nnz=K.nnz, nd=nd, n_tris=n_tris,
                   alpha=alpha, beta=beta, cv=cv, massT=massT, wminus=wminus,
                   wall_tri=wall_tri, wall_lfc=wall_lfc, wall_emit=wall_emit,
                   wall_fcm=wall_fcm,
                   per_el=op.per_el, per_il=op.per_il, per_tri=op.per_tri,
                   lag_d=op.lag_d, lag_f=op.lag_f, half_inv=half_inv,
                   fcx=ctx.cxv, fcy=ctx.cyv, fw=ctx.domega,
                   perm=perm, pos=pos,
                   K=K if keep_matrix else None)

    @property
    def n(self) -> int:
        return self.cx.size * self.n_tris * self.nd

    # -- state -> coarse source ---------------------------------------------
    def source(self, ts, qxs, qys, fw, lag, ttfc):
        """The coarse transport source for a state ``(ts, qxs, qys, fw, lag)``.

        The fine-direction periodic lag is projected onto the coarse inflow
        directions through its half-range P1 fit, which is exact when the
        inflow is linear in angle -- the diffusive and hydrodynamic case.
        """
        n_c = self.cx.size
        massT = self.massT
        src = np.empty((n_c, self.n_tris, self.nd))
        src[:] = np.einsum("iml,li->im", massT, self.alpha * ts)[None]
        if self.beta != 0.0:
            src += self.beta * (self.cx[:, None, None]
                                * np.einsum("iml,li->im", massT, qxs)[None]
                                + self.cy[:, None, None]
                                * np.einsum("iml,li->im", massT, qys)[None])
        if self.wall_tri.size:
            wm = self.wminus[:, self.wall_tri, self.wall_lfc]           # (c, n_w)
            np.add.at(src, (slice(None), self.wall_tri), wm[:, :, None] * fw[None])
        if self.per_el.size:
            n_pf = self.per_el.size
            mom = np.zeros((n_pf, 3, self.nd))
            wd = self.fw[self.lag_d]
            np.add.at(mom[:, 0], self.lag_f, wd[:, None] * lag)
            np.add.at(mom[:, 1], self.lag_f, (wd * self.fcx[self.lag_d])[:, None] * lag)
            np.add.at(mom[:, 2], self.lag_f, (wd * self.fcy[self.lag_d])[:, None] * lag)
            ab = np.einsum("fij,fjl->fil", self.half_inv, mom)          # (n_pf, 3, l)
            proj = (ab[None, :, 0] + self.cx[:, None, None] * ab[None, :, 1]
                    + self.cy[:, None, None] * ab[None, :, 2])           # (c, n_pf, l)
            wm = self.wminus[:, self.per_el, self.per_il]                # (c, n_pf)
            inflow = np.einsum("fml,cfl->cfm", ttfc[self.per_el, self.per_il], proj)
            np.add.at(src, (slice(None), self.per_el), -wm[:, :, None] * inflow)
        return np.ascontiguousarray(np.transpose(src, (1, 0, 2))[self.perm]).ravel()

    # -- coarse distribution -> state ----------------------------------------
    def moments(self, g):
        """``(ts, qxs, qys, fw, lag)`` of the coarse distribution ``g``; the
        fine-direction lag is the P1 reconstruction from the coarse moments
        on the partner element."""
        n_c = self.cx.size
        g = g.reshape(self.n_tris, n_c, self.nd)[self.pos]              # (i, d, l)
        ts = np.einsum("d,idl->li", self.w, g) / self.cv
        qxs = np.einsum("d,idl->li", self.w * self.cx, g)
        qys = np.einsum("d,idl->li", self.w * self.cy, g)
        if self.wall_tri.size:
            fw = np.einsum("kd,kml,kdl->km", self.wall_emit, self.wall_fcm,
                           g[self.wall_tri])
        else:
            fw = np.zeros((0, self.nd))
        if self.lag_d.size:
            t = self.per_tri[self.lag_f]
            lag = ((self.cv / (4.0 * PI)) * ts[:, t].T
                   + (3.0 / (4.0 * PI)) * (self.fcx[self.lag_d][:, None] * qxs[:, t].T
                                           + self.fcy[self.lag_d][:, None] * qys[:, t].T))
        else:
            lag = np.zeros((0, self.nd))
        return ts, qxs, qys, fw, lag


class CoarsePreconditioner:
    """``r -> (I - L_c)^{-1} r`` through the coarse coupled system.

    With ``g`` the coarse distribution driven by the residual,
    ``K g = M r``, the error estimate is ``e = P g + r``.
    """

    def __init__(self, op: MomentOperator, coarse: CoarseSystem):
        self.op = op
        self.cs = coarse
        self.ttfc = op.s.ctx.ttfc
        self.solves = 0

    def __call__(self, r):
        ts, qxs, qys, fw, lag = self.op.split(r)
        src = self.cs.source(ts, qxs, qys, fw, lag, self.ttfc)
        g = self.cs.lu.solve(src.astype(self.cs.lu.L.dtype, copy=False))
        self.solves += 1
        ets, eqxs, eqys, efw, elag = self.cs.moments(g)
        return self.op.join(ets + ts, eqxs + qxs, eqys + qys, efw + fw, elag + lag)


# ---------------------------------------------------------------------------
# GMRES
# ---------------------------------------------------------------------------
def gmres(matvec, b, precond=None, tol=1e-8, maxit=300, callback=None,
          relative_to="solution", measure=None, measure_window=100.0):
    """Flexible GMRES (right preconditioning, modified Gram-Schmidt, no
    restart) for ``A x = b`` from ``x = 0``.

    The preconditioned directions ``z_j = M^{-1} v_j`` are kept, so the
    iterate is ``x_k = Z_k y_k``; that makes the preconditioner free to be
    inexact (a single-precision factorisation, say) and gives ``||x_k||`` at
    every step for the stopping test.  Returns ``(x, history, y)`` with
    ``history[j]`` the residual norm after ``j + 1`` matvecs, relative to
    ``||x_j||`` (``relative_to="solution"``) or to ``||b||``; ``y`` are the
    coefficients of ``x`` in the ``z_j`` basis.

    ``measure(rvec, xnorm)``, if given, replaces that cheap estimate by a
    measure of the actual residual vector (recovered from the Arnoldi
    relation, no matvec) once the estimate is within ``measure_window`` of
    ``tol``; ``history`` then holds whichever was used.

    For the fixed-point system ``(I - L) x = c`` the residual is
    ``G(x) - x``, the mismatch between the moments the sweep was fed and the
    ones it produced.  Relative to ``||x||`` that is, up to the source
    weighting, the transport residual ``||A f - b(f)|| / ||b(f)||`` of the
    distribution the converged state generates -- the quantity a verifier
    checks -- whereas relative to ``||c||`` it is inflated by ``||x|| / ||c||``,
    which is large when the medium is thick and the first sweep from zero
    moments captures only the boundary layer.
    """
    n = b.size
    bnorm = float(np.linalg.norm(b))
    if bnorm == 0.0:
        return np.zeros(n), [0.0], np.zeros(0)

    V = np.empty((maxit + 1, n))
    Z = np.empty((maxit, n))
    H = np.zeros((maxit + 1, maxit))
    Hbar = np.zeros((maxit + 1, maxit))      # before the Givens rotations
    g = np.zeros(maxit + 1)
    cs = np.zeros(maxit)
    sn = np.zeros(maxit)
    V[0] = b / bnorm
    g[0] = bnorm
    hist = []
    k = 0
    y = np.zeros(0)
    for j in range(maxit):
        Z[j] = precond(V[j]) if precond is not None else V[j]
        wv = matvec(Z[j])
        for i in range(j + 1):
            H[i, j] = V[i] @ wv
            wv -= H[i, j] * V[i]
        hnew = float(np.linalg.norm(wv))
        H[j + 1, j] = hnew
        Hbar[:j + 2, j] = H[:j + 2, j]
        if hnew > 0.0:
            V[j + 1] = wv / hnew
        for i in range(j):
            t = cs[i] * H[i, j] + sn[i] * H[i + 1, j]
            H[i + 1, j] = -sn[i] * H[i, j] + cs[i] * H[i + 1, j]
            H[i, j] = t
        rr = float(np.hypot(H[j, j], hnew))
        cs[j] = H[j, j] / rr
        sn[j] = hnew / rr
        H[j, j] = rr
        H[j + 1, j] = 0.0
        g[j + 1] = -sn[j] * g[j]
        g[j] = cs[j] * g[j]
        k = j + 1
        rnorm = abs(g[k])
        y = np.linalg.solve(H[:k, :k], g[:k])
        if relative_to == "solution":
            xnorm = float(np.linalg.norm(Z[:k].T @ y))
            res = rnorm / xnorm if xnorm > 0.0 else rnorm / bnorm
        else:
            xnorm = float("nan")
            res = rnorm / bnorm
        if measure is not None and res < measure_window * tol:
            e = -(Hbar[:k + 1, :k] @ y)
            e[0] += bnorm
            res = measure(V[:k + 1].T @ e, xnorm)
        hist.append(res)
        if callback is not None:
            callback(k, res)
        if res < tol or hnew == 0.0:
            break
    return Z[:k].T @ y, hist, y
