# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, source iteration in time.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/kn_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte cases/kn_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

    while True:
        sweep()                 # exact transport solve, one direction at a time,
                                # in a topological order of the element graph
        compute_moments()       # T, qx, qy from the distribution
        correct()               # synthetic acceleration (accel.py)
        if correction < accel_tol: break

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

## Why the correction is there

Both collision channels conserve energy, so the scattering ratio of this
operator is exactly one and nothing damps the source iteration except leakage
through the walls.  A phonon needs `O((L/tau_C)^2)` sweeps to random-walk to a
wall, and the N channel adds a second slow family -- it conserves momentum
too, so the drift part of the source regenerates itself with amplification
`tau_C/tau_N`, which is `0.999` at `(tau_R, tau_N) = (10, 0.01)`.  Unaccelerated,
`F1_1e-2` needs 16 830 sweeps and `F1_1e-3` does not converge inside `tmax`
at all.

`accel.py` solves a synthetic low-order model between one sweep and the next:
the *same* DG discretisation on the *same* mesh with the *same* boundary
treatment, but nine ordinates instead of two hundred, small enough to
factorise once with a sparse direct solve and reuse.  Its quadrature is
chosen to reproduce every angular moment the collision operator uses up to
fourth order, so it inherits both the Fourier limit and the viscous
(Guyer-Krumhansl) response.  Contraction rates on the shipped cases are 0.08
to 0.53, and every one of the fifteen converges in eight to twenty-seven
sweeps.

Because it is a *correction*, driven by a residual that goes to zero, none of
its approximations can move the answer -- only how fast it arrives.  Turn it
off with `scheme.accelerate: false` to recover the shipped iteration exactly.

## Knowing when to stop

`Calculate_Residual_T` compares two successive iterates.  That is a step, not
an error: for a linearly converging sequence the error left is the sum of all
future steps, `r rho/(1 - rho)`, and `rho -> 1` is precisely what makes these
cases hard.  On the shipped mesh at `tau_R = 1e-2` the unaccelerated solver
reports `1e-8` after 16 830 sweeps with a temperature field still wrong in the
fifth digit.  The accelerated solver instead stops on the size of the
correction it is about to apply, measured as a relative change *per element*
of the temperature -- the quantity the answer is judged on, measured where a
cold corner is held to the same standard as the hot wall.  Since the iteration
contracts by 0.53 or better, what is left after a correction of size `s` is no
worse than about `s`; `scheme.accel_tol` defaults to `1e-10`.

## Cases

Three boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)
    F3_*   east and west walls periodic (the mesh's two side boundaries are
           paired; `bc.py` matches their faces)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration
      accel.py      the synthetic acceleration of that iteration
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `NAZIM` is silently forced even.
* The synthetic model is factorised once, costs no sweeps, and scales like
  `O((NDIR_LO * NDOF * N_TRIS)^1.5)`: 0.1 s for the shipped 200-element mesh,
  a couple of seconds by `Nx41`.  On a mesh where that stops paying for
  itself, `scheme.accelerate: false` is the escape hatch.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
