"""The outer iteration -- the port of ``Callaway_2D_2V_DG.f90``.

::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

The sweep and the moment update are untouched -- :meth:`Solver.step` is that
loop body, kernel for kernel.  What is added around them:

* the synthetic correction of :mod:`pybte.accel`, applied to the moments (and
  to the two places a sweep reads the distribution back) between one pass and
  the next.  Without it the iteration converges at the rate energy leaks out
  of an optically thick slab -- 16 830 sweeps at ``tau_R = 1e-2``, more than
  ``tmax`` at ``1e-3`` -- and with it every shipped case is done in eight to
  twenty-seven;
* a stopping rule that measures the *error* rather than the step between two
  iterates.  ``Calculate_Residual_T`` is a step, and a step is only an error
  if the iteration contracts fast; the shipped cases are exactly the ones
  where it does not, which is why ``1e-8`` there can sit next to a 90% wrong
  answer;
* an explicit restart contract, an optional true residual, and a
  :class:`~pybte.io_output.RunRecord` complete enough that a verifier never
  has to parse stdout.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self._accel = None
        self._accel_ok = True
        self._accel_failed = None
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        self.vdf = np.ascontiguousarray(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof))
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- acceleration -------------------------------------------------------
    def accelerator(self):
        """The synthetic accelerator, built on first use, or ``None``.

        Building it costs one sparse factorisation of a nine-ordinate copy of
        the same discretisation -- no sweeps at all -- and it is what turns
        the ``O((L/tau_C)^2)`` source iteration into a contraction of 0.53 or
        better.  If it cannot be built the solver says so and falls back to
        the unaccelerated iteration rather than failing the run.
        """
        if self._accel is not None or not (self.case.scheme.accelerate
                                           and self._accel_ok):
            return self._accel
        from .accel import Accelerator

        try:
            self._accel = Accelerator(self)
        except Exception as exc:  # pragma: no cover - defensive
            warnings.warn(f"synthetic acceleration unavailable ({exc}); "
                          "falling back to the unaccelerated iteration")
            self._accel_failed = str(exc)
        return self._accel

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Iterate to the fixed point of the discrete transport system.

        Each pass is one transport sweep and one moment update -- the Fortran's
        loop -- followed by the synthetic correction of :mod:`pybte.accel`,
        which is what makes the stiff cases converge in tens of sweeps instead
        of hundreds of thousands.  The stopping rule is the size of that
        correction, an estimate of the *error*; the Fortran's
        ``Calculate_Residual_T`` step is still computed, recorded, and has to
        agree before the run is called converged -- unless the correction has
        reached the problem's round-off floor, where neither test can be
        driven any lower.
        """
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))
        accel = self.accelerator()
        atol = c.scheme.accel_tol

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []
        errors: list[float] = []

        t0 = time.perf_counter()
        if accel is not None and not self.restart_info["enabled"]:
            accel.start(self.mom, self.vdf)
        step = 0
        converged = False
        grew = 0
        while True:
            step += 1
            if accel is not None:
                ts0 = self.mom.ts.copy()
                qx0 = self.mom.qxs.copy()
                qy0 = self.mom.qys.copy()
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)

            if accel is None:
                if res < tol:
                    converged = True
                    break
            else:
                corr, size = accel.correction(self.mom, self.mom.ts - ts0,
                                              self.mom.qxs - qx0,
                                              self.mom.qys - qy0)
                # Round-off floor.  Three iterations without halving the
                # correction is not slow convergence -- the accelerated
                # iteration contracts by 0.53 or better -- it is the floor
                # set by the sweep's own round-off, which the synthetic
                # correction amplifies by the same ``(L/tau_C)^2`` that makes
                # the unaccelerated iteration slow.  On the shipped cases
                # that floor is near 1e-11; push ``tau_R`` to 1e-5 and it is
                # 1e-6, and no amount of iterating in double precision will
                # improve on it.  Below 1e-8 accept it at once; above, insist
                # on a long enough history that a genuine contraction would
                # have shown itself.
                flat = (len(errors) >= 6
                        and min(errors[-2:] + [size]) > 0.5 * min(errors[:-2]))
                stalled = flat and (size < 1e-8 or len(errors) >= 20)
                errors.append(size)
                if size < atol or stalled:
                    # ``res < tol`` is the Fortran's own test, kept as a
                    # second opinion; at a round-off floor coarser than
                    # ``tol`` there is nothing left to iterate towards, so it
                    # does not get a veto.
                    converged = bool(res < tol or stalled)
                    break
                if not np.isfinite(size):
                    accel = self._abandon_acceleration()
                    continue
                grew = grew + 1 if len(errors) > 1 and size > errors[-2] else 0
                if grew >= 10:
                    accel = self._abandon_acceleration()
                    continue
                accel.apply(self.mom, self.vdf, corr)
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        if converged and errors and errors[-1] > 1e-8:
            warnings.warn(
                f"stopped at a synthetic correction of {errors[-1]:.2e}, the "
                "round-off floor of this problem, rather than the requested "
                f"{atol:.0e}: the answer is good to about that much")
        rec = self._record(step, converged, residuals, masses,
                           true_res if want_true else None, wall,
                           scheme="CIS+SA" if accel is not None else "CIS")
        rec.diagnostics["error_history"] = errors
        return rec

    def _abandon_acceleration(self):
        """Give up on the synthetic model mid-run and restart cleanly."""
        warnings.warn("the synthetic correction diverged; restarting the "
                      "unaccelerated iteration")
        self._accel = None
        self._accel_ok = False
        self.vdf[:] = 0.0
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old[:] = 0.0
        return None

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
