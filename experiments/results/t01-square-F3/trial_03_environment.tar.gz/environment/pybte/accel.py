"""Synthetic acceleration of the source iteration.

Source iteration converges at a rate set by the scattering ratio, which for
this collision operator is exactly one: both channels conserve energy, so the
only thing that damps the iteration is leakage through the walls.  In an
optically thick medium a particle takes ``O((L/tau)^2)`` sweeps to random-walk
to a wall, and that -- not the transport solve -- is what the shipped driver
spends its iterations on.  The N channel adds a second slow family: it
conserves momentum too, so the drift part of the source regenerates itself
with amplification ``tau_C/tau_N``, which is ``0.999`` at ``tau_N = 0.01,
tau_R = 10``.

The cure is classical.  Write one outer iteration as

    m_{k+1/2} = G m_k + g          (a sweep, then the moments)

with ``m = (T_s, qx_s, qy_s)``, the only thing the sweep reads back.  The
error obeys ``(I - G) e = G (m_{k+1/2} - m_k)``, so if some cheap ``G_LO``
approximates ``G`` well, then

    m_{k+1} = m_k + (I - G_LO)^{-1} (m_{k+1/2} - m_k)

kills whatever ``G_LO`` captures.  Diffusion synthetic acceleration takes
``G_LO`` from a diffusion discretisation.  Here ``G_LO`` is instead *the same
transport problem on the same DG mesh with nine directions* -- a discrete
ordinates model small enough to factorise once and solve directly:

* it inherits the spatial discretisation, so it stays consistent in the thick
  cells (``h/tau_C ~ 100``) where an independently discretised diffusion
  operator is the classic way to make DSA diverge;
* it inherits the boundary treatment -- isothermal, diffusely reflecting and
  periodic walls need no separate derivation;
* its quadrature is chosen to reproduce every angular moment the collision
  operator uses, up to fourth order, so it reproduces both the Fourier limit
  (``kappa = Cv Vg^2 tau_R / 3``) and the viscous (Guyer-Krumhansl) response
  that makes the hydrodynamic cases stiff.

Measured contraction rates on the shipped cases: 0.08 to 0.53, against
``1 - 1e-6`` for the unaccelerated iteration.

Applying the correction to the *moments* is not quite enough.  A sweep also
reads the distribution itself, in two places: the emission of a diffusely
reflecting wall, and the inflow across a periodic face (the sweep ordering
cannot make a periodic pair upwind of itself, so that inflow is one iterate
old).  Those two lag the corrected moments unless the correction is also
written into ``vdf``, and with them lagging the iteration diverges outright on
the F2 and F3 families.  :meth:`Accelerator.correct` therefore also injects
the correction into the distribution in the equilibrium (P1) form

    df = Cv dT_s / (4 pi) + 3 (dqx_s cx + dqy_s cy) / (4 pi Vg^2),

whose moments are exactly ``(dT_s, dqx_s, dqy_s)`` -- so the injection is
consistent with the moment update rather than an approximation of it -- and
only in the elements a sweep can read stale.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import PI

__all__ = ["LowOrderModel", "Accelerator", "lo_directions"]


def lo_directions(vg: float):
    """Ordinates whose weights reproduce the angular moments that matter.

    The transport operator sees only the in-plane components ``(mu, nu) =
    (cx, cy) / Vg``; the sphere projects onto the unit disc.  A quadrature on
    that disc drives the low-order model's asymptotics through

        sum w = 4 pi,  sum w mu^2 = 4 pi / 3,      (Fourier limit)
        sum w mu^4 = 4 pi / 5,  sum w mu^2 nu^2 = 4 pi / 15,   (viscosity)

    plus vanishing odd moments.  Four axis points, four diagonal points and
    one stagnant point -- the phonons travelling out of plane, which carry
    energy nowhere -- satisfy all of them exactly:

        (+-1, 0), (0, +-1)          w = 4 pi / 15
        (+-1, +-1)/sqrt(3)          w = 3 pi / 5
        (0, 0)                      w = 8 pi / 15

    Every eight-point set that matches the same four moments puts one of its
    families outside the light cone, and the sets that stay inside it get the
    fourth moment wrong: drop the diagonal points for the S2-like
    five-direction set and the accelerated iteration diverges on every family
    but F1; drop the stagnant point and it diverges on the hydrodynamic
    cases.  So all nine are needed -- but the stagnant one does not have to
    be *solved for*, see :meth:`LowOrderModel._assemble`.

    Returns the eight transporting ordinates and, separately, the weight of
    the stagnant one.
    """
    b = 1.0 / np.sqrt(3.0)
    w1 = 4.0 * PI / 15.0
    w2 = 3.0 * PI / 5.0
    w0 = 8.0 * PI / 15.0
    cx = np.array([1.0, -1.0, 0.0, 0.0, b, b, -b, -b]) * vg
    cy = np.array([0.0, 0.0, 1.0, -1.0, b, -b, b, -b]) * vg
    om = np.array([w1, w1, w1, w1, w2, w2, w2, w2])
    return cx, cy, om, w0


class LowOrderModel:
    """``(I - G_LO)^{-1}`` in moment space, as a sparse direct solve.

    The low-order discrete-ordinate system is assembled once,

        K f = T_LO f - B_LO W f - (wall emission) f = B_LO r,

    and factorised.  ``A_LO^{-1} r`` is then ``W f + r``: exactly the fixed
    point of the low-order iteration driven by the residual ``r``, since
    ``m = W f + r`` and ``T_LO f = B_LO m`` together are ``m - G_LO m = r``.
    """

    def __init__(self, solver, dirs=None):
        c = solver.case
        self.s = solver
        cx, cy, om, om_s = dirs if dirs is not None else lo_directions(c.flow.vg)
        self.cx, self.cy, self.om = cx, cy, om
        # The stagnant ordinate has no gradient and no face terms, so its row
        # is the purely local ``f_0 = tau_C * (isotropic source)``.  Solving
        # it by hand instead of carrying it costs nothing and takes the
        # element block from 9*NDOF to 8*NDOF, which is a third off the
        # factorisation.  Substituting it back multiplies every isotropic
        # term -- the scattering kernel, the source, the moment it returns --
        # by the same 4 pi / (4 pi - w_0).
        self.om_s = om_s
        self.iso = 4.0 * PI / (4.0 * PI - om_s)
        self.nlo = cx.size
        self.nt = solver.n_tris
        self.nd = solver.ndof
        self.cv, self.vg = c.flow.cv, c.flow.vg
        self.tau_r, self.tau_n, self.tau_c = c.flow.tau_r, c.flow.tau_n, c.tau_c
        self.n = self.nlo * self.nt * self.nd
        self._assemble()

    # -- assembly ----------------------------------------------------------
    def _assemble(self) -> None:
        ctx = self.s.ctx
        nd, nt, nlo = self.nd, self.nt, self.nlo
        cx, cy, om = self.cx, self.cy, self.om
        rr = np.repeat(np.arange(nd), nd)
        cc = np.tile(np.arange(nd), nd)
        rows, cols, vals = [], [], []

        def push(r0, c0, blocks):
            rows.append((r0[:, None] + rr[None, :]).ravel())
            cols.append((c0[:, None] + cc[None, :]).ravel())
            vals.append(np.asarray(blocks).reshape(len(r0), -1).ravel())

        speed = cx[:, None, None] * ctx.nx[None] + cy[:, None, None] * ctx.ny[None]
        wout = 0.5 * (speed + np.abs(speed))
        win = 0.5 * (speed - np.abs(speed))
        base = np.arange(nt) * nd
        dofs = nt * nd

        # A_SOL, direction by direction (the same expression the sweep builds)
        a_sol = (np.transpose(ctx.mass, (2, 0, 1))[None] / self.tau_c
                 - cx[:, None, None, None] * ctx.gx[None]
                 - cy[:, None, None, None] * ctx.gy[None]
                 + np.einsum('dik,ikml->diml', wout, ctx.fcm, optimize=True))
        for d in range(nlo):
            push(base + d * dofs, base + d * dofs, a_sol[d])

        # the collision source, moved to the left-hand side
        kap = om[None, :] * (self.iso / (4.0 * PI * self.tau_c)
                             + 3.0 * (cx[:, None] * cx[None, :]
                                      + cy[:, None] * cy[None, :])
                             / (4.0 * PI * self.vg ** 2 * self.tau_n))
        mass_lm = np.transpose(ctx.mass, (2, 1, 0))             # [i][m,l] = M(l,m,i)
        for d in range(nlo):
            for dp in range(nlo):
                push(base + d * dofs, base + dp * dofs, -kap[d, dp] * mass_lm)

        # upwind inflow across interior and periodic faces
        ext = np.where(ctx.neighbour >= 0, ctx.neighbour,
                       ctx.periodic_tri[ctx.tri_faces])
        for d in range(nlo):
            for il in range(3):
                sel = np.flatnonzero((win[d, :, il] != 0.0) & (ext[:, il] >= 0))
                if sel.size:
                    push(sel * nd + d * dofs, ext[sel, il] * nd + d * dofs,
                         win[d, sel, il][:, None, None] * ctx.ttfc[sel, il])

        # diffusely reflecting walls: the emission is a functional of the
        # incoming half-space, so it couples the directions at that element
        for i, il in self._wall_faces():
            u = -(cx * ctx.nx[i, il] + cy * ctx.ny[i, il])      # c . n_inward
            ss2 = -np.sum(u[u >= 0.0] * om[u >= 0.0])
            for dp in np.flatnonzero(u < 0.0):
                coef = win[:, i, il] * u[dp] * om[dp] / ss2
                for d in np.flatnonzero(coef != 0.0):
                    push(np.array([i * nd + d * dofs]),
                         np.array([i * nd + dp * dofs]),
                         (coef[d] * ctx.fcm[i, il])[None])

        k = sp.coo_matrix((np.concatenate(vals),
                           (np.concatenate(rows), np.concatenate(cols))),
                          shape=(self.n, self.n)).tocsc()
        self.matrix = k
        # A_TRANS + A ordering with pivoting all but disabled: the operator is
        # diagonally dominant when the mesh is optically thick and only mildly
        # indefinite when it is not, and letting SuperLU pivot freely walks
        # away from the fill-reducing ordering -- 23 M nonzeros and 3.9 s
        # instead of 2.5 M and 0.08 s at ``tau_R = tau_N = 1``.  Nothing here
        # can move the answer: this matrix is a preconditioner, and the
        # correction it returns is driven by a residual that goes to zero.
        self.lu = spla.splu(k, permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.1)

    def _wall_faces(self):
        ctx = self.s.ctx
        out = []
        for i in range(self.nt):
            for il in range(3):
                bc = ctx.face_bc[ctx.tri_faces[i, il]]
                if bc >= 0 and ctx.bc_type[bc] == 2:
                    out.append((i, il))
        return out

    # -- the wall-driven solution ------------------------------------------
    def wall_solution(self):
        """The low-order model's own answer, driven by the wall temperatures.

        The factorisation is already paid for, so this costs one triangular
        solve and gives the outer iteration a starting point that is already
        the right shape -- within 1e-5 of the answer in the diffusive limit,
        within a few per cent in the transition regime -- instead of starting
        from a cold, empty domain.  Worth two to four sweeps.
        """
        ctx = self.s.ctx
        nd, nt, nlo = self.nd, self.nt, self.nlo
        rhs = np.zeros((nlo, nt, nd))
        speed = (self.cx[:, None, None] * ctx.nx[None]
                 + self.cy[:, None, None] * ctx.ny[None])
        win = 0.5 * (speed - np.abs(speed))
        bc = np.where(ctx.face_bc[ctx.tri_faces] >= 0,
                      ctx.face_bc[ctx.tri_faces], 0)
        hot = (ctx.face_bc[ctx.tri_faces] >= 0) & (ctx.bc_type[bc] == 1)
        tw = np.where(hot, self.cv / (4.0 * PI) * ctx.bc_temp[bc], 0.0)
        for il in range(3):
            k = np.flatnonzero(tw[:, il] != 0.0)
            if k.size:
                rhs[:, k, :] -= (win[:, k, il, None] * tw[k, il, None]
                                 * ctx.ttfc[k, il, :, 0][None])
        f = self.lu.solve(rhs.reshape(-1)).reshape(nlo, nt, nd)
        return self._moments(f)

    def _moments(self, f):
        ts = self.iso * np.einsum('d,dim->mi', self.om, f, optimize=True) / self.cv
        qx = np.einsum('d,dim->mi', self.om * self.cx, f, optimize=True)
        qy = np.einsum('d,dim->mi', self.om * self.cy, f, optimize=True)
        return ts, qx, qy

    # -- the correction ----------------------------------------------------
    def solve(self, r_ts, r_qx, r_qy):
        """``A_LO^{-1} r`` for a moment-space residual ``r``."""
        ctx = self.s.ctx
        a = self.iso * self.cv * (1.0 / self.tau_r + 1.0 / self.tau_n) / (4.0 * PI)
        b = 3.0 / (4.0 * PI * self.vg ** 2 * self.tau_n)
        g = (a * r_ts[None, :, :]
             + b * (self.cx[:, None, None] * r_qx[None, :, :]
                    + self.cy[:, None, None] * r_qy[None, :, :]))    # (d, l, i)
        rhs = np.einsum('lmi,dli->dim', ctx.mass, g, optimize=True)
        f = self.lu.solve(rhs.reshape(-1)).reshape(self.nlo, self.nt, self.nd)
        ts, qx, qy = self._moments(f)
        # ``iso * (W f + r)``: the stagnant ordinate contributes to the
        # temperature both through the distribution it was eliminated from
        # and through its own share of the residual's isotropic source
        return ts + self.iso * r_ts, qx + r_qx, qy + r_qy


class Accelerator:
    """The low-order model plus the bookkeeping of one accelerated step."""

    def __init__(self, solver):
        self.s = solver
        self.model = LowOrderModel(solver)
        self.stale = self._stale_elements()
        c = solver.case
        self.cv, self.vg = c.flow.cv, c.flow.vg
        self.int_tri = solver.integrals.int_tri

    def _stale_elements(self) -> np.ndarray:
        """Elements whose distribution a sweep can read before rewriting it.

        A sweep visits elements in a topological order, so interior inflow is
        always fresh; what is not are the periodic partners (the pairing is
        not part of the ordering), the elements a diffusely reflecting wall
        integrates its emission from, and -- if the ordering had to break a
        cycle -- everything.
        """
        s = self.s
        if s.order.cycles_broken.any():
            return np.arange(s.n_tris)
        idx = []
        bd = s.bcdata
        if bd.has_periodic:
            idx.append(bd.periodic_tri[bd.periodic_tri >= 0])
        if bd.has_nonthermalising:
            faces = np.flatnonzero(
                (s.mesh.face_bc >= 0)
                & (bd.bc_type[np.clip(s.mesh.face_bc, 0, None)] == 2))
            idx.append(np.array([s.mesh.adjacent(int(f))[0] for f in faces]))
        if not idx:
            return np.zeros(0, dtype=np.int64)
        return np.unique(np.concatenate(idx)).astype(np.int64)

    def correction(self, mom, d_ts, d_qx, d_qy):
        """The correction the low-order model wants, and its relative size.

        ``d_*`` is the change the sweep just made to the moments.  What comes
        back is what has to be added *on top of* that change, i.e.
        ``(I - G_LO)^{-1} d - d``.

        The size reported with it is the largest *element-wise relative*
        change this correction would make to the temperature -- the quantity
        the answer is judged on, measured where it is judged, so an element
        whose temperature is 1e-6 of the peak is held to the same relative
        standard as the hot wall.  Because the accelerated iteration
        contracts by 0.53 or better, what is left after a correction of size
        ``s`` is no worse than about ``s``.
        """
        ts, qx, qy = self.model.solve(d_ts, d_qx, d_qy)
        e = (ts - d_ts, qx - d_qx, qy - d_qy)
        size = _rel_norm(e[0], e[1], e[2], mom)
        if size < 1.0e-4:
            # close enough for the element-wise measure to mean something:
            # early on the cold elements are still exactly zero and every
            # relative change there is infinite
            dtemp = np.einsum('li,li->i', e[0], self.int_tri)
            temp = np.abs(mom.temp)
            floor = 1e-13 * temp.max()
            size = max(size, float(np.max(np.abs(dtemp)
                                          / np.maximum(temp, floor))))
        return e, size

    def start(self, mom, vdf) -> None:
        """Seed the iteration with the low-order model's own solution."""
        ts, qx, qy = self.model.wall_solution()
        self.apply(mom, vdf, (ts - mom.ts, qx - mom.qxs, qy - mom.qys))

    def apply(self, mom, vdf, e) -> None:
        """Add the correction to the moments and to the distribution."""
        e_ts, e_qx, e_qy = e
        mom.ts += e_ts
        mom.qxs += e_qx
        mom.qys += e_qy
        if self.stale.size:
            ctx = self.s.ctx
            k = self.stale
            f = (self.cv / (4.0 * PI)) * e_ts[:, k].T[None, :, :]
            f = f + (3.0 / (4.0 * PI * self.vg ** 2)) * (
                np.multiply.outer(ctx.cxv, e_qx[:, k].T)
                + np.multiply.outer(ctx.cyv, e_qy[:, k].T))
            vdf[:, k, :] += f


def _rel_norm(d_ts, d_qx, d_qy, mom) -> float:
    num = float(np.vdot(d_ts, d_ts) + np.vdot(d_qx, d_qx) + np.vdot(d_qy, d_qy))
    den = float(np.vdot(mom.ts, mom.ts) + np.vdot(mom.qxs, mom.qxs)
                + np.vdot(mom.qys, mom.qys))
    if den <= 0.0:
        return float("inf")
    return float(np.sqrt(num / den))
