"""The outer iteration.

The Fortran's loop is::

    STEP = 1
    DO
        DG_Solver_VDF                       ! transport sweep
        Calculate_Macro_Properties
        Calculate_Residual_T
        EXIT when RESIDUAL < TOL or STEP >= TMAX
    END DO

which is Richardson iteration on the discrete system, and it slows to a crawl
exactly where the physics is stiff: its contraction factor tends to 1 as the
medium becomes optically thick.  :meth:`Solver.run_source_iteration` is that
loop, kept verbatim.

:meth:`Solver.run` solves the same discrete system, to the same fixed point,
by FGMRES on the reduced fixed-point system of :mod:`pybte.accel`, optionally
preconditioned by the low-order operator of :mod:`pybte.loworder`.  One
Krylov iteration costs exactly one transport sweep, and the sweep itself is
untouched.  See :mod:`pybte.accel` for why the two have the same solution.

Around both: an explicit restart contract, an optional true residual, and a
:class:`~pybte.io_output.RunRecord` complete enough that a verifier never has
to parse stdout.
"""
from __future__ import annotations

import hashlib
import time
import warnings
from pathlib import Path

import numpy as np

from .accel import ReducedSystem, fgmres
from .basis import build_basis
from .bc import build_boundary_data
from .config import Case
from .integration import build_integrals
from .loworder import LowOrderOperator
from .io_output import (RunRecord, append_runtime_log, locate_points,
                        sample_fields, sampling_grid, write_tecplot)
from .mesh import build_mesh
from .moments import Moments, compute_moments, residual_iterate
from .ordering import build_sweep_order, validate_sweep_order
from .sweep import SweepContext
from .velocity import build_velocity_mesh

__all__ = ["Solver"]


class Solver:
    """Set up a case and run it to convergence.

    >>> case = Case.from_yaml("cases/cavity_tauR1e-3_cis.yaml")
    >>> record = Solver(case).run()
    >>> record.iterations, record.converged
    """

    def __init__(self, case: Case, validate_order: bool = False,
                 on_cycle: str | None = None):
        t0 = time.perf_counter()
        self.case = case
        c = case
        on_cycle = on_cycle or c.scheme.on_cycle

        if not c.boundaries:
            raise ValueError("the case declares no boundaries")

        self.mesh = build_mesh(c.mesh_path(),
                               [b.phyid for b in c.boundaries],
                               c.bc_codes(),
                               [b.name for b in c.boundaries],
                               [b.xoff for b in c.boundaries],
                               [b.yoff for b in c.boundaries])
        self.basis = build_basis(c.dg.deg)
        self.vel = build_velocity_mesh(c.velmesh.npole, c.velmesh.nazim, c.flow.vg)
        self.integrals = build_integrals(self.mesh, self.basis, c.np_tri, c.np_fc,
                                         bc_codes=c.bc_codes(),
                                         bc_xoff=[b.xoff for b in c.boundaries],
                                         bc_yoff=[b.yoff for b in c.boundaries])
        self.order = build_sweep_order(self.mesh, self.vel, on_cycle=on_cycle)
        if validate_order:
            validate_sweep_order(self.mesh, self.vel, self.order)
        self.bcdata = build_boundary_data(self.mesh, c.boundaries, c.ndof_tri)

        self.ndir = self.vel.ndir
        self.n_tris = self.mesh.n_tris
        self.ndof = c.ndof_tri

        self.ctx = SweepContext.build(c, self.mesh, self.integrals, self.vel,
                                      self.order, self.bcdata)
        self.factorisation_count = (self.ndir * self.n_tris
                                    if self.ctx.mode == "precomputed" else 0)

        self.vdf = np.zeros((self.ndir, self.n_tris, self.ndof))
        self.mom = Moments.zeros(self.ndof, self.n_tris)
        self.t_old = np.zeros(self.n_tris)
        self.restart_info = self._apply_restart()

        self.setup_seconds = time.perf_counter() - t0

    # -- restart ----------------------------------------------------
    def _restart_stem(self) -> str:
        c = self.case
        return (f"VDFP{c.dg.deg}T{self.n_tris:3d}"
                f"NP{c.velmesh.npole:2d}NA{c.velmesh.nazim:2d}").replace(" ", "")

    def _apply_restart(self) -> dict:
        r = self.case.restart
        default = Path(self.case.basedir) / f"{self._restart_stem()}.out"
        if not r.enabled:
            if r.error_on_stale and default.exists():
                raise FileExistsError(
                    f"a restart file {default} is present but restart is disabled. "
                    "The Fortran would have read it silently and changed the "
                    "iteration count with no warning. Delete it, or set "
                    "restart.enabled or restart.error_on_stale explicitly.")
            return {"enabled": False, "path": None, "sha256": None}

        path = Path(r.path) if r.path else default
        if not path.is_absolute():
            path = Path(self.case.basedir) / path
        if not path.exists():
            raise FileNotFoundError(f"restart enabled but {path} does not exist")
        raw = path.read_bytes()
        want = self.ndof * self.n_tris * self.ndir * 8
        if len(raw) != want:
            raise ValueError(f"{path}: {len(raw)} bytes, expected {want} "
                             "(wrong DEG / mesh / angular resolution?)")
        arr = np.frombuffer(raw, dtype="<f8").reshape(
            (self.ndof, self.n_tris, self.case.velmesh.npole,
             self.case.velmesh.nazim), order="F")
        self.vdf = np.ascontiguousarray(
            np.transpose(arr, (3, 2, 1, 0)).reshape(self.ndir, self.n_tris, self.ndof))
        return {"enabled": True, "path": str(path),
                "sha256": hashlib.sha256(raw).hexdigest()}

    def save_restart(self, path=None) -> Path:
        path = Path(path) if path else Path(self.case.basedir) / f"{self._restart_stem()}.out"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.vdf_fortran().ravel(order="F").tobytes())
        return path

    # -- views -------------------------------------------------------------
    def vdf_fortran(self) -> np.ndarray:
        """``VDF(NDOF_TRI, N_TRIS, NPOLE, NAZIM)``, for stage comparison."""
        npole, nazim = self.case.velmesh.npole, self.case.velmesh.nazim
        return np.transpose(
            self.vdf.reshape(nazim, npole, self.n_tris, self.ndof), (3, 2, 1, 0))

    # -- one outer iteration ------------------------------------------------
    def step(self) -> None:
        if self.bcdata.has_nonthermalising:
            self.bcdata.update_wall_flux(self.vdf, self.ctx.cxv, self.ctx.cyv,
                                         self.ctx.domega,
                                         self.integrals.int_tri_fc, self.mesh)
        self.ctx.sweep(self.mom, self.vdf)
        if self.ctx.mode == "onthefly":
            self.factorisation_count += self.ndir * self.n_tris
        compute_moments(self.vdf, self.ctx.cxv, self.ctx.cyv, self.ctx.domega,
                        self.integrals.int_tri, self.case.flow.cv, self.mom)

    # -- the outer loop -----------------------------------------------------
    def run(self, callback=None, progress_every: int = 0) -> RunRecord:
        """Solve to the discrete fixed point.

        Uses the accelerated solver unless ``iteration.accelerate`` is off,
        in which case the Fortran's source iteration runs instead.  Both
        converge to the same state; only the cost of getting there differs.
        """
        if self.case.iteration.accelerate:
            return self.run_accelerated(callback=callback,
                                        progress_every=progress_every)
        return self.run_source_iteration(callback=callback,
                                         progress_every=progress_every)

    def run_source_iteration(self, callback=None,
                             progress_every: int = 0) -> RunRecord:
        """Source iteration: ``Calculate_Residual_T < tol``, as the Fortran."""
        c = self.case
        tol, tmax = c.iteration.tol, c.iteration.tmax
        want_true = c.iteration.true_residual
        every = max(1, int(c.iteration.true_residual_every))

        residuals: list[float] = []
        masses: list[float] = []
        true_res: list[float] = []

        t0 = time.perf_counter()
        step = 0
        converged = False
        while True:
            step += 1
            self.step()
            res = residual_iterate(self.mom.temp, self.t_old)
            self.t_old[:] = self.mom.temp
            residuals.append(res)
            masses.append(self.mom.mass)
            if want_true:
                true_res.append(self.ctx.true_residual(self.mom, self.vdf)
                                if (step % every == 0) else np.nan)
            if progress_every and step % progress_every == 0:
                print(f"  step {step:8d}  residual {res:.6e}  mass {self.mom.mass:.10f}",
                      flush=True)
            if callback is not None:
                callback(step, res, self)
            if res < tol:
                converged = True
                break
            if step >= tmax:
                break
        wall = time.perf_counter() - t0
        return self._record(step, converged, residuals, masses,
                            true_res if want_true else None, wall,
                            scheme="CIS")

    # -- the accelerated outer loop -----------------------------------------
    #: unpreconditioned Krylov iterations taken before judging whether a
    #: low-order operator is worth building
    PROBE = 6
    #: iterations the fitted rate is estimated over
    RATE_WINDOW = 4
    #: build the low-order operator once the projected remaining iteration
    #: count exceeds this; roughly what building and factorising one costs,
    #: measured in sweeps
    BUILD_IF_REMAINING = 25
    #: give up on P1 and go to P2 once the projected count exceeds this
    UPGRADE_IF_REMAINING = 60

    @staticmethod
    def _projected(residuals: list, target: float, window: int) -> float:
        """Iterations still needed at the recently observed rate."""
        if len(residuals) <= window:
            return float("inf")
        last, prev = residuals[-1], residuals[-1 - window]
        if last <= target:
            return 0.0
        if not (0.0 < last < prev):
            return float("inf")
        rate = (last / prev) ** (1.0 / window)
        if rate >= 1.0:
            return float("inf")
        return float(np.log(target / last) / np.log(rate))

    def run_accelerated(self, callback=None, progress_every: int = 0) -> RunRecord:
        """FGMRES on the reduced fixed-point system; see :mod:`pybte.accel`.

        The preconditioner is not built unconditionally: a low-order solve
        costs tens of sweeps to assemble and factorise, which is more than the
        whole iteration needs in the optically thin regime.  The first
        :data:`PROBE` iterations run unpreconditioned and the observed
        convergence rate decides.  ``tau_N < tau_R`` -- normal scattering
        dominant, so the slow mode is momentum diffusion, which a P1 closure
        cannot represent -- starts at P2 rather than P1.
        """
        c = self.case
        cv = c.flow.cv
        tol = max(min(c.iteration.tol * 1.0e-2, 1.0e-10), 1.0e-13)
        red = ReducedSystem(self)
        tmax = int(c.iteration.tmax)
        restart = max(4, int(c.iteration.krylov_restart))

        residuals: list[float] = []
        masses: list[float] = []
        info = {"build": 0.0, "kdeg": 0, "stage": 0, "since": 0, "lo": None,
                "krylov": 0, "restarts": 0, "scale": 1.0}

        t0 = time.perf_counter()
        b = red.step(np.zeros(red.n))
        residuals.append(1.0)
        masses.append(self.mom.mass)
        bnorm = float(np.linalg.norm(b))

        def op(v):
            return v + b - red.step(v)

        def identity(v, j):
            return v

        def make_precon(lo):
            def precon(v, j):
                rm, rw, rp = red.views(v)
                dm, dw, dp = lo.apply(rm, rw, rp, cv)
                out = np.empty(red.n)
                om, ow, op_ = red.views(out)
                om[:] = dm
                if ow is not None:
                    ow[:] = dw
                if op_ is not None:
                    op_[:] = dp
                return out
            return precon

        def build(kdeg, j):
            t = time.perf_counter()
            try:
                lo = LowOrderOperator(self, kdeg=kdeg,
                                      pivot_thresh=c.iteration.lo_pivot_thresh)
            except Exception as exc:                 # never fatal: it is only
                warnings.warn(f"low-order preconditioner (P{kdeg}) could not "
                              f"be built ({exc}); continuing unpreconditioned")
                info["build"] += time.perf_counter() - t
                info["stage"] = 3
                return identity
            info["build"] += time.perf_counter() - t
            info["lo"] = lo
            info["kdeg"] = kdeg
            info["since"] = j
            return make_precon(lo)

        kdeg0 = 2 if c.flow.tau_n < c.flow.tau_r else 1
        precon = identity

        def on_iterate(j, rel):
            j += info["krylov"]
            rel *= info["scale"]          # FGMRES reports against the cycle's
            residuals.append(rel)         # own r0; the history is against b
            masses.append(self.mom.mass)
            if progress_every and j % progress_every == 0:
                print(f"  krylov {j:5d}  residual {rel:.6e}"
                      f"  preconditioner P{info['kdeg']}", flush=True)
            if callback is not None:
                callback(j, rel, self)
            if not c.iteration.precondition or rel <= tol:
                return None
            if info["stage"] == 0 and j >= self.PROBE:
                if self._projected(residuals, tol, self.RATE_WINDOW) \
                        > self.BUILD_IF_REMAINING:
                    info["stage"] = 2 if kdeg0 == 2 else 1
                    return build(kdeg0, j)
            elif info["stage"] == 1 and j - info["since"] >= self.PROBE:
                if self._projected(residuals, tol, self.RATE_WINDOW) \
                        > self.UPGRADE_IF_REMAINING:
                    info["stage"] = 2
                    return build(2, j)
            return None

        # Restarted outside, so that the Krylov basis never grows past
        # ``krylov_restart`` vectors however large ``tmax`` is.  Each cycle
        # ends with one sweep that both rebuilds the residual and leaves the
        # distribution and its moments in the solver state.
        y = np.zeros(red.n)
        r = b
        rnorm = bnorm
        final = 1.0 if bnorm > 0 else 0.0
        while True:
            budget = tmax - red.sweeps - 1
            if budget < 1 or final <= tol:
                break
            dy, _, nit, _ = fgmres(op, r, precon, tol * bnorm / rnorm,
                                   min(restart, budget), red.n,
                                   on_iterate=on_iterate)
            info["krylov"] += nit
            precon = make_precon(info["lo"]) if info["lo"] is not None else identity
            y = y + dy
            ylast = red.step(y)
            r = ylast - y
            rnorm = float(np.linalg.norm(r))
            final = rnorm / bnorm if bnorm > 0 else 0.0
            info["scale"] = final
            residuals.append(final)
            masses.append(self.mom.mass)
            info["restarts"] += 1
        wall = time.perf_counter() - t0

        return self._record(
            red.sweeps, bool(final <= tol), residuals, masses, None, wall,
            scheme="FGMRES",
            extra={"krylov_iterations": info["krylov"],
                   "krylov_restarts": info["restarts"] - 1,
                   "preconditioner": f"P{info['kdeg']}" if info["kdeg"] else "none",
                   "preconditioner_seconds": info["build"],
                   "reduced_dim": red.n,
                   "target_residual": tol})

    def _record(self, iterations, converged, residuals, masses, true_res, wall,
                scheme, extra=None) -> RunRecord:
        """Assemble the run record from the solver's current state."""
        c = self.case
        rec = RunRecord(
            iterations=iterations, converged=converged,
            residual_history=np.asarray(residuals),
            residual_true=np.asarray(true_res) if true_res is not None else None,
            mass_history=np.asarray(masses),
            temp=self.mom.temp.copy(), qx=self.mom.qx.copy(), qy=self.mom.qy.copy(),
            temp_dofs=self.mom.ts.copy(), qx_dofs=self.mom.qxs.copy(),
            qy_dofs=self.mom.qys.copy(),
            sweep_count=self.ctx.sweep_count,
            factorisation_count=self.factorisation_count,
            wall_clock=wall, setup_wall_clock=self.setup_seconds,
            config_hash=c.config_hash,
            scheme=scheme,
            tol=c.iteration.tol, tmax=c.iteration.tmax,
            tau_r=c.flow.tau_r, tau_n=c.flow.tau_n,
            tau_c=c.tau_c, deg=c.dg.deg, npole=c.velmesh.npole,
            nazim=c.velmesh.nazim, n_tris=self.n_tris, n_faces=self.mesh.n_faces,
            mesh_file=str(c.mesh_path()),
            restart=self.restart_info,
            environment=RunRecord.environment_fingerprint(),
            diagnostics={
                "sweep_mode": self.ctx.mode,
                "cycles_broken": int(self.order.cycles_broken.sum()),
                "hmin": float(self.mesh.hmin),
                "n_faces_b": int(self.mesh.n_faces_b),
                "boundary_types": [b.type for b in c.boundaries],
            },
        )
        if extra:
            rec.diagnostics.update(extra)
        return rec

    # -- output -------------------------------------------------------------
    def write_outputs(self, rec: RunRecord) -> dict:
        c = self.case
        out = c.output_path()
        out.mkdir(parents=True, exist_ok=True)
        written = {}

        if c.output.run_record:
            written["run_record"] = str(rec.to_json(out / "run_record.json"))
        if c.output.runtime_log:
            written["runtime_log"] = str(append_runtime_log(
                out / "RunTime.txt", rec.scheme, c.flow.tau_r, c.flow.tau_n,
                self.n_tris, c.velmesh.npole, c.velmesh.nazim,
                rec.iterations, rec.wall_clock))
        if c.output.field:
            px, py = sampling_grid(c.output.field_nx, c.output.field_ny)
            triid = locate_points(self.mesh, px, py)
            missing = int(np.count_nonzero(triid < 0))
            if missing:
                warnings.warn(f"{missing} sampling points fell outside the mesh")
            pT, pqx, pqy, pxx, pxy, pyy = sample_fields(
                self.mesh, self.basis, self.vdf, self.ctx.cxv, self.ctx.cyv,
                self.ctx.domega, c.flow.cv, px, py, triid,
                ndof_tri=self.ndof)
            if c.output.npz:
                np.savez_compressed(out / "field.npz", px=px, py=py, triid=triid,
                                    T=pT, qx=pqx, qy=pqy,
                                    Nxx=pxx, Nxy=pxy, Nyy=pyy)
                written["field_npz"] = str(out / "field.npz")
            if c.output.tecplot:
                written["field_dat"] = str(write_tecplot(
                    out / "field.dat", px, py, [pT, pqx, pqy, pxx, pxy, pyy],
                    ["T", "qx", "qy", "Nxx", "Nxy", "Nyy"]))
        return written
