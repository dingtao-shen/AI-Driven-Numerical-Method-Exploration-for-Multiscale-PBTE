"""The accelerated outer iteration.

Source iteration is a fixed-point iteration on a small amount of data.  The
sweep reads exactly three things from the previous iterate:

* the moments ``(T_s, qx_s, qy_s)`` that build the scattering source,
* the diffuse-wall emission ``FLUX_WALL`` (non-thermalising walls only),
* the distribution in the elements behind a periodic pair -- the sweep
  ordering treats a periodic face as a boundary, so that inflow is lagged.

Call that data ``y``.  One sweep plus the moment update is an *affine* map
``y -> A y + b``, so the converged state is the solution of ::

    (I - A) y = b

on a few thousand unknowns rather than the ``ndir * n_tris * ndof``
distribution.  Source iteration is the Richardson iteration for that system,
which is why it inherits its spectral radius.  Solving it with FGMRES
instead costs exactly one sweep per iteration and converges in a number of
iterations set by the *clustering* of the spectrum rather than by its
radius; preconditioning with :mod:`pybte.loworder` clusters it.

The fixed point is untouched by any of this.  ``y`` solves the same equation
source iteration was converging to, and the distribution reported is
``vdf = sweep(y)``, so it satisfies the discrete transport system to the
tolerance the Krylov residual is driven to -- not to the tolerance a
successive-difference test happens to report.
"""
from __future__ import annotations

import numpy as np

from .moments import compute_moments

__all__ = ["ReducedSystem", "fgmres"]


class ReducedSystem:
    """Packs the sweep's lagged data into one vector and applies the map."""

    def __init__(self, solver):
        self.s = solver
        bd = solver.bcdata
        self.ndof, self.ntri, self.ndir = solver.ndof, solver.n_tris, solver.ndir
        self.has_wall = bool(bd.has_nonthermalising)
        ptri = bd.periodic_tri
        self.per_elems = (np.unique(ptri[ptri >= 0]) if bd.has_periodic
                          else np.zeros(0, dtype=np.int64))
        self.nm = 3 * self.ndof * self.ntri
        self.nw = bd.flux_wall.size if self.has_wall else 0
        self.np_ = self.per_elems.size * self.ndir * self.ndof
        self.n = self.nm + self.nw + self.np_
        self.wall_shape = bd.flux_wall.shape
        self.per_shape = (self.ndir, self.per_elems.size, self.ndof)
        self.vdf = solver.vdf
        self.sweeps = 0

    # -- layout -------------------------------------------------------------
    def views(self, y):
        """(moments, wall, periodic) views into a packed vector."""
        nd, nt = self.ndof, self.ntri
        rm = y[:self.nm].reshape(3, nd, nt)
        off = self.nm
        rw = y[off:off + self.nw].reshape(self.wall_shape) if self.nw else None
        off += self.nw
        rp = y[off:off + self.np_].reshape(self.per_shape) if self.np_ else None
        return rm, rw, rp

    def gather(self, out=None):
        """Pack the solver's current lagged data."""
        s = self.s
        y = np.empty(self.n) if out is None else out
        rm, rw, rp = self.views(y)
        rm[0] = s.mom.ts
        rm[1] = s.mom.qxs
        rm[2] = s.mom.qys
        if rw is not None:
            rw[:] = s.bcdata.flux_wall
        if rp is not None:
            rp[:] = self.vdf[:, self.per_elems, :]
        return y

    def scatter(self, y):
        """Load a packed vector into the solver's state."""
        s = self.s
        rm, rw, rp = self.views(y)
        s.mom.ts[:] = rm[0]
        s.mom.qxs[:] = rm[1]
        s.mom.qys[:] = rm[2]
        if rw is not None:
            s.bcdata.flux_wall[:] = rw
        if rp is not None:
            self.vdf[:, self.per_elems, :] = rp

    # -- the affine map -----------------------------------------------------
    def step(self, y, vdf=None):
        """One sweep from the lagged data ``y``; returns the new lagged data."""
        s = self.s
        self.vdf = s.vdf if vdf is None else vdf
        self.scatter(y)
        s.ctx.sweep(s.mom, self.vdf)
        self.sweeps += 1
        if s.ctx.mode == "onthefly":
            s.factorisation_count += s.ndir * s.n_tris
        compute_moments(self.vdf, s.ctx.cxv, s.ctx.cyv, s.ctx.domega,
                        s.integrals.int_tri, s.case.flow.cv, s.mom)
        if self.has_wall:
            s.bcdata.update_wall_flux(self.vdf, s.ctx.cxv, s.ctx.cyv,
                                      s.ctx.domega, s.integrals.int_tri_fc,
                                      s.mesh)
        return self.gather()


def fgmres(apply_op, b, precon, tol, maxit, n, on_iterate=None):
    """Flexible GMRES.

    Flexible, so that the preconditioner may be built (or upgraded) partway
    through without discarding the Krylov space: the preconditioned basis
    ``Z`` is stored anyway, which is all FGMRES needs.

    ``precon`` is called as ``precon(v, j)`` and may return ``v`` itself.
    ``on_iterate(j, relative_residual)`` is called after each iteration and
    may return a new ``precon`` to install from the next iteration onwards.
    """
    beta = float(np.linalg.norm(b))
    if beta == 0.0:
        return np.zeros(n), 0.0, 0, True
    v = np.empty((maxit + 1, n))
    z = np.empty((maxit, n))
    h = np.zeros((maxit + 1, maxit))
    cs = np.zeros(maxit)
    sn = np.zeros(maxit)
    g = np.zeros(maxit + 1)
    g[0] = beta
    v[0] = b / beta
    j = 0
    rel = 1.0
    converged = False
    while j < maxit:
        z[j] = precon(v[j], j)
        w = apply_op(z[j])
        for i in range(j + 1):                       # modified Gram-Schmidt
            h[i, j] = np.dot(v[i], w)
            w -= h[i, j] * v[i]
        hnext = float(np.linalg.norm(w))             # kept: the rotation below
        h[j + 1, j] = hnext                          # overwrites h[j+1, j]
        for i in range(j):                           # previous rotations
            t = cs[i] * h[i, j] + sn[i] * h[i + 1, j]
            h[i + 1, j] = -sn[i] * h[i, j] + cs[i] * h[i + 1, j]
            h[i, j] = t
        d = np.hypot(h[j, j], h[j + 1, j])
        if d == 0.0:
            cs[j], sn[j] = 1.0, 0.0
        else:
            cs[j], sn[j] = h[j, j] / d, h[j + 1, j] / d
        h[j, j] = cs[j] * h[j, j] + sn[j] * h[j + 1, j]
        h[j + 1, j] = 0.0
        g[j + 1] = -sn[j] * g[j]
        g[j] = cs[j] * g[j]
        rel = abs(g[j + 1]) / beta
        j += 1
        if rel <= tol:
            converged = True
        if on_iterate is not None:
            new = on_iterate(j, rel)
            if new is not None:
                precon = new
        if converged:
            break
        if hnext == 0.0:                             # exact breakdown
            converged = True
            break
        v[j] = w / hnext
    y = np.linalg.solve(np.triu(h[:j, :j]), g[:j])
    return z[:j].T @ y, rel, j, converged
