"""The angular-P_K projection of the discrete transport operator.

Source iteration converges at a rate that degrades to 1 as the medium becomes
optically thick, because the slow error modes are the ones the collision
operator does not damp: the isotropic (diffusive) mode when ``tau_R`` is
small, and the drift mode when ``tau_N`` is small.  Killing them needs an
operator that couples the whole domain in a single solve -- the classical
synthetic-acceleration idea.

What is assembled here is the Galerkin projection of the *same* discrete
transport operator the sweep inverts, onto a low-order angular subspace::

    f_d(x) ~ sum_k U_k(x) psi_k(c_d)

with ``psi_k`` polynomials in ``(c_x, c_y)`` orthonormalised against the
solver's own solid-angle quadrature.  ``kdeg = 1`` (``psi = 1, c_x, c_y``)
is P1, i.e. diffusion synthetic acceleration: it reproduces Fourier's law in
the diffusive limit.  ``kdeg = 2`` adds the second moments, which is what the
``tau_N << tau_R`` (hydrodynamic) regime needs -- there the slow mode is
momentum diffusion, and a P1 closure has no viscosity at all to represent it.

Nothing is hand-discretised.  Every coefficient is an angular quadrature sum,
over the solver's own ordinates, of the terms the sweep kernel itself uses
(``int_tri_tri``, ``int_tri_tri_x/y``, ``int_tri_fc``, ``int_tri_tri_fc``),
so the low-order operator inherits the transport discretisation's upwinding,
its boundary treatment and its periodic pairing exactly.  Being only a
preconditioner it never enters the answer: it changes how fast the Krylov
iteration reaches the fixed point, not where that fixed point is.
"""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import BC_NONTHERMALISING, BC_PERIODIC, PI

__all__ = ["LowOrderOperator", "angular_basis"]


def angular_basis(cx, cy, domega, kdeg: int) -> np.ndarray:
    """The closure basis, orthonormalised so that
    ``sum_d domega_d psi_a psi_b = delta_ab``.

    ``kdeg = 1``   ``1, c_x, c_y``            -- P1: density and heat flux.
    ``kdeg = 2``   ``+ c_x c_y, c_x^2 - c_y^2`` -- the *deviatoric* in-plane
                   second moments, i.e. the viscous stress.

    The isotropic second moment is deliberately absent: its trace is
    ``vg^2`` times the density, so it adds a column that the closure already
    carries, and leaving it out shrinks the factorisation by a fifth for no
    change at all in the iteration count.  Odd powers of ``c_z`` are absent
    for a different reason: the geometry is 2-D, so the distribution is even
    in ``c_z`` and those moments vanish identically.
    """
    one = np.ones_like(cx)
    p = [one, cx, cy]
    if kdeg >= 2:
        p += [cx * cy, cx * cx - cy * cy]
    p = np.stack(p)
    gram = (p * domega) @ p.T
    return np.linalg.solve(np.linalg.cholesky(gram), p)


class LowOrderOperator:
    """Assembled and factorised P_K operator, and the correction it defines.

    :meth:`apply` maps a residual of the reduced fixed-point system to an
    approximate correction, in the synthetic-acceleration form ``delta = r +
    (moments of the low-order transport solve driven by r)``.
    """

    def __init__(self, solver, kdeg: int = 1, pivot_thresh: float = 0.01):
        ctx = solver.ctx
        mesh = solver.mesh
        ig = solver.integrals
        nd = solver.ndof
        nt = solver.n_tris
        self.nd, self.nt, self.kdeg = nd, nt, kdeg

        cx, cy, w = ctx.cxv, ctx.cyv, ctx.domega
        vg, tau_n, tau_c = ctx.vg, ctx.tau_n, ctx.tau_c
        psi = angular_basis(cx, cy, w, kdeg)
        k = psi.shape[0]
        self.psi = psi
        self.k = k
        # rho = p0.U, qx = p1.U, qy = p2.U for the ansatz f_d = sum_k U_k psi_k
        self.p0 = (psi * w).sum(axis=1)
        self.p1 = (psi * w * cx).sum(axis=1)
        self.p2 = (psi * w * cy).sum(axis=1)
        self.alpha = 1.0 / (4.0 * PI * tau_c)
        self.beta = 3.0 / (4.0 * PI * tau_n * vg * vg)

        # -- angular sums ---------------------------------------------------
        u = (ctx.nx.ravel()[:, None] * cx[None, :]
             + ctx.ny.ravel()[:, None] * cy[None, :])            # (nt*3, ndir)
        wp = np.where(u > 0.0, w * u, 0.0)
        wm = np.where(u < 0.0, w * u, 0.0)
        self.wm = wm
        pp = (psi[:, None, :] * psi[None, :, :]).reshape(k * k, -1)
        fp = (wp @ pp.T).reshape(nt, 3, k, k)
        fm = (wm @ pp.T).reshape(nt, 3, k, k)
        mx = ((w * cx) * psi) @ psi.T
        my = ((w * cy) * psi) @ psi.T
        ssrc = (self.alpha * np.outer(self.p0, self.p0)
                + self.beta * (np.outer(self.p1, self.p1)
                               + np.outer(self.p2, self.p2)))
        dvol = np.eye(k) / tau_c - ssrc

        self.mass = np.ascontiguousarray(np.transpose(ig.int_tri_tri, (2, 0, 1)))
        self.fcm = ig.int_tri_fc
        self.ttfc = ig.int_tri_tri_fc

        own = (np.einsum('iml,ek->iekml', self.mass, dvol, optimize=True)
               - np.einsum('iml,ek->iekml', ig.int_tri_tri_x, mx, optimize=True)
               - np.einsum('iml,ek->iekml', ig.int_tri_tri_y, my, optimize=True)
               + np.einsum('iaml,iaek->iekml', self.fcm, fp, optimize=True))

        # -- connectivity: who supplies the inflow across each face ---------
        fcs = np.asarray(mesh.tri_faces)
        bcs = np.asarray(mesh.face_bc)[fcs]
        typ = np.where(bcs >= 0, solver.bcdata.bc_type[bcs], 0)
        jarr = np.array(ctx.neighbour, dtype=np.int64)
        per = typ == BC_PERIODIC
        if per.any():
            jarr[per] = solver.bcdata.periodic_tri[fcs[per]]
        # a thermalising wall's inflow is data, not an unknown: no coupling
        self.wall_faces = []
        for i, a in zip(*np.nonzero(typ == BC_NONTHERMALISING)):
            uu = u[i * 3 + a]
            denom = -np.sum(np.where(uu < 0.0, w * uu, 0.0))
            g = (np.where(uu > 0.0, w * uu, 0.0) * psi).sum(axis=1) / denom
            h = (np.where(uu < 0.0, w * uu, 0.0) * psi).sum(axis=1)
            own[i] += np.einsum('ml,e,k->ekml', self.fcm[i, a], h, g)
            self.wall_faces.append((int(fcs[i, a]), int(i), int(a), g, h))
        self.per_faces = [(int(i), int(a), int(jarr[i, a]))
                          for i, a in zip(*np.nonzero(per))]
        ptri = solver.bcdata.periodic_tri
        self.per_elems = np.unique(ptri[ptri >= 0]) if per.any() else None
        if self.per_elems is not None:
            self.per_index = np.full(nt, -1, dtype=np.int64)
            self.per_index[self.per_elems] = np.arange(self.per_elems.size)

        # -- sparse assembly, one dense (k*ndof)^2 block per element pair ---
        bs = k * nd
        ia, aa = np.nonzero(jarr >= 0)
        blk_nbr = np.einsum('fml,fek->femkl', self.ttfc[ia, aa], fm[ia, aa],
                            optimize=True).reshape(-1, bs, bs)
        data = np.concatenate(
            [np.transpose(own, (0, 1, 3, 2, 4)).reshape(nt, bs, bs), blk_nbr])
        rowb = np.concatenate([np.arange(nt), ia])
        colb = np.concatenate([np.arange(nt), jarr[ia, aa]])
        order = np.lexsort((colb, rowb))
        indptr = np.zeros(nt + 1, dtype=np.int64)
        np.add.at(indptr, rowb + 1, 1)
        np.cumsum(indptr, out=indptr)
        self.matrix = sp.bsr_matrix((data[order], colb[order], indptr),
                                    shape=(nt * bs, nt * bs)).tocsc()
        # Partial pivoting with the default threshold buys nothing here (the
        # blocks are well scaled) and costs an order of magnitude in fill;
        # a small threshold keeps the factorisation honest and cheap.
        self.lu = spla.splu(self.matrix, permc_spec="MMD_AT_PLUS_A",
                            diag_pivot_thresh=pivot_thresh)
        self.nnz_factor = self.lu.nnz

    # -- the correction -----------------------------------------------------
    def apply(self, rm, rw, rp, cv):
        """``delta`` for a reduced-system residual ``r = (rm, rw, rp)``.

        ``rm`` is ``(3, ndof, n_tris)`` in the solver's ``(T, qx, qy)``
        scaling, ``rw`` the diffuse-wall emission residual (or None), ``rp``
        the lagged periodic traces ``(ndir, n_per, ndof)`` (or None).
        """
        nt, nd, k = self.nt, self.nd, self.k
        coeff = (self.alpha * self.p0[:, None, None] * (cv * rm[0])[None]
                 + self.beta * (self.p1[:, None, None] * rm[1][None]
                                + self.p2[:, None, None] * rm[2][None]))
        rhs = np.einsum('iml,eli->iem', self.mass, coeff, optimize=True)
        if rw is not None:
            for fc, i, a, g, h in self.wall_faces:
                rhs[i] += np.outer(h, rw[fc])
        if rp is not None:
            for i, a, iext in self.per_faces:
                hp = (self.wm[i * 3 + a] * self.psi) @ rp[:, self.per_index[iext], :]
                rhs[i] -= hp @ self.ttfc[i, a].T
        u = self.lu.solve(rhs.reshape(-1)).reshape(nt, k, nd)

        dm = np.empty_like(rm)
        dm[0] = rm[0] + np.einsum('e,iem->mi', self.p0, u, optimize=True) / cv
        dm[1] = rm[1] + np.einsum('e,iem->mi', self.p1, u, optimize=True)
        dm[2] = rm[2] + np.einsum('e,iem->mi', self.p2, u, optimize=True)
        dw = None
        if rw is not None:
            dw = rw.copy()
            for fc, i, a, g, h in self.wall_faces:
                dw[fc] -= self.fcm[i, a] @ (g @ u[i])
        dp = None
        if rp is not None:
            dp = rp + np.einsum('dk,ekm->dem', self.psi.T, u[self.per_elems],
                                optimize=True)
        return dm, dw, dp
