# Phonon Boltzmann transport solver

Steady 2D2V gray linear Callaway phonon BTE.  Nodal discontinuous Galerkin in
space, discrete ordinates in angle, source iteration in time.

    from pybte import Case, Solver
    record = Solver(Case.from_yaml("cases/F1_1e-2.yaml")).run()
    record.iterations, record.converged, record.temp

or from the command line::

    python -m pybte run cases/F1_1e-2.yaml

## The model

Phonons relax by two channels with relaxation times `tau_R` (resistive,
momentum-destroying) and `tau_N` (normal, momentum-conserving), combined as
`1/tau_C = 1/tau_R + 1/tau_N`.  With `Vg = L = 1` the Knudsen number is
`tau_R`: large means ballistic, small means diffusive, and in the diffusive
limit the temperature obeys Fourier's law with `kappa = Cv Vg^2 tau_R / 3`.
`pybte.analytic` carries that limit for the shipped cavity as a 200-term
series.

## How one iteration works

    while True:
        sweep()                 # exact transport solve, one direction at a time,
                                # in a topological order of the element graph
        compute_moments()       # T, qx, qy from the distribution
        if residual < tol: break

The sweep is Gauss-Seidel: within a direction each element reads inflow from
neighbours already updated in the same pass, which is what makes it an exact
solve for that direction.

That loop is the *source iteration*; it is kept as
`Solver.run_source_iteration()` (or `scheme.accelerate: false`).  Its
contraction factor tends to 1 in the optically thick limit (energy-conserving
temperature modes) and when normal scattering dominates (momentum-conserving
heat-flux modes), so on the stiff cases it needs thousands of sweeps or never
gets there.

## How the accelerated solve works

`Solver.run()` finds the *same* fixed point -- same sweep, same
discretisation, same answer -- as the solution of a linear system.  The
sweep is affine in the moments it reads, `m -> K m + c`, so the fixed point
solves `(I - K) m = c`.  `pybte.accel` solves that with

* **GMRES**, each iteration costing exactly one `ctx.sweep`, on the state the
  sweep actually reads: the per-DOF moments `(T_s, qx_s, qy_s)`, the emission
  of diffusely reflecting walls, and, for periodic pairs, the distribution at
  the elements the periodic inflow is taken from (the sweep reads those before
  it overwrites them, so they lag by one sweep and belong to the state);
* a **synthetic-acceleration preconditioner**: the Galerkin projection of the
  same DG transport operator onto angular polynomials of degree 1 in
  `(cx, cy)` -- degree 2 when `tau_N << tau_R`, because the damping of the
  momentum modes is set by the fourth angular moments -- assembled as a
  sparse matrix and LU-factorised once.  With the spatial discretisation
  unchanged the coarse operator has the fine scheme's thick-cell diffusion
  limit, which is what makes the correction effective at `tau_C << h`.

The iteration stops when the relative norm of the preconditioned residual --
an estimate of the relative error of the moments, not of the step -- falls
below `scheme.accel_tol` (default `1e-8`).  The converged distribution is
assembled from the stored sweep outputs by linearity, so `record.iterations`
(the number of sweeps) is `1 + number of GMRES steps`.  All fifteen shipped
cases converge in 7 to 20 sweeps; the transport residual of the result,
`||A f - b|| / ||b||` with the moments recomputed from `f`, is below `1e-8`
on every one.

`scheme` options: `accelerate` (default true), `coarse_order` (0 = choose
from the relaxation times, else 1 or 2), `accel_tol`, and
`periodic_prolongation` (`auto`/`on`/`off`: whether the coarse correction is
also prolongated onto the lagged periodic traces, which pays when the
receiving elements are optically thick and hurts when they are not).

## Cases

Three boundary-condition families on the same square and the same
discretisation (200 elements, `DEG = 2`, a `10 x 20` angular mesh,
`tol = 1e-8`), each at five `(tau_R, tau_N)` pairs spanning the diffusive,
transition, ballistic and hydrodynamic regimes:

    F1_*   all four walls isothermal, T = 1 on the north wall
    F2_*   east and west walls diffusely reflecting (adiabatic)
    F3_*   east and west walls periodic (the mesh's two side boundaries are
           paired; `bc.py` matches their faces)

A diffusely reflecting wall re-emits, isotropically, the energy that hits
it, so its emission depends on the solution: `bc.py` recomputes it from the
distribution at the start of every iteration.

## Layout

    pybte/          the solver
      driver.py     the outer iteration (accelerated, and the plain loop)
      accel.py      GMRES + angular-P_N synthetic acceleration
      sweep.py      the transport sweep
      moments.py    moments and the residual
      basis.py      nodal DG bases
      quadrature.py Gauss-Legendre and triangle rules
      bc.py         boundary conditions
      mesh/         gmsh reader, topology, geometry
      analytic.py   the diffusion-limit series
    cases/          case files
    meshes/         gmsh meshes
    tests/          pytest suite

## Notes

* `Temp`, `Qx`, `Qy` on the run record are element *integrals*, not averages:
  `record.temp.sum()` is the domain integral of `T`.  Divide by
  `mesh.tri_area` for cell averages.
* `NAZIM` is silently forced even.
* The angular quadrature is accurate to about `1e-13`, not to machine
  precision; do not design a test that needs better.
