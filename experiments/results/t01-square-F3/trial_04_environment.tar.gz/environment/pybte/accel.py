"""Krylov acceleration of the source iteration with an angular P_N coarse solve.

The outer iteration of ``driver.py`` is a fixed-point map on the moments,

    m  ->  Phi(m) = R sweep(m) = K m + c,

which is affine in ``m`` (the sweep is an exact per-direction transport solve
with the scattering source frozen).  Source iteration is the Richardson
iteration for ``(I - K) m = c``; its spectral radius is the largest
eigenvalue of ``K``, and that tends to 1 as the medium becomes optically
thick (energy-conserving T modes) or as normal scattering starts to dominate
(momentum-conserving q modes).  Nothing about ``K`` itself changes here:
one application of ``K`` is still exactly one call of ``ctx.sweep``.

What changes is how the fixed point is found:

* **GMRES** on ``(I - K) m = c`` instead of Richardson, and
* a **synthetic-acceleration preconditioner**: a Galerkin projection of the
  *same* DG transport discretisation onto a low-order angular polynomial
  space (P1 or P2 in the in-plane velocity components), assembled as a
  sparse matrix and LU-factorised once.  Because the spatial part of the
  coarse operator is identical to the fine one, the coarse operator has the
  same thick-cell diffusion limit as the fine DG scheme, which is what makes
  the correction effective when ``tau_C << h``.

The state vector the Krylov method works on is the smallest set of numbers
the sweep needs besides the wall temperatures: the per-DOF moments
``(T_s, qx_s, qy_s)``, plus, when present, the diffusely reflecting walls'
emission (``flux_wall``) and, for periodic pairs, the distribution at the
elements the periodic inflow is read from (the sweep reads those *before*
overwriting them, so they are lagged by one sweep in the shipped solver and
must be part of the state for the map to be a fixed linear operator).  The
fixed point of the augmented map is exactly the fixed point of the shipped
source iteration.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from .constants import BC_NONTHERMALISING, BC_PERIODIC, PI

__all__ = ["AngularCoarseOperator", "StateLayout", "angular_basis",
           "AccelerationSetupError"]


class AccelerationSetupError(RuntimeError):
    """The coarse operator could not be built or factorised."""


# ---------------------------------------------------------------------------
# angular polynomial basis
# ---------------------------------------------------------------------------
def angular_basis(cxv, cyv, domega, order: int) -> np.ndarray:
    """Orthonormal (w.r.t. the discrete-ordinate weights) polynomial basis in
    the in-plane velocity components, up to total degree ``order``.

    Returns ``Psi`` of shape ``(ndir, npsi)`` with ``Psi.T @ diag(domega) @ Psi
    = I``; ``Psi[:, 0]`` spans the isotropic mode.
    """
    if order < 1 or order > 3:
        raise ValueError("angular order must be 1, 2 or 3")
    cols = [np.ones_like(cxv), cxv, cyv]
    if order >= 2:
        cols += [cxv * cxv, cxv * cyv, cyv * cyv]
    if order >= 3:
        cols += [cxv ** 3, cxv * cxv * cyv, cxv * cyv * cyv, cyv ** 3]
    psi = np.stack(cols, axis=1)
    sw = np.sqrt(domega)
    q, _ = np.linalg.qr(psi * sw[:, None])
    return q / sw[:, None]


# ---------------------------------------------------------------------------
# the state vector
# ---------------------------------------------------------------------------
@dataclass
class StateLayout:
    """Where each part of the fixed-point state lives in one flat vector.

    ``[ts | qxs | qys | flux_wall(wall faces) | vdf(periodic source elements)]``
    """
    nd: int
    n_tris: int
    ndir: int
    wall_faces: np.ndarray             # (nw,) face ids of diffuse walls
    per_faces: np.ndarray              # (nper,) face ids of periodic receivers
    per_src: np.ndarray                # (nper,) element read through each
    per_recv: np.ndarray               # (nper,) element owning each face
    per_recv_lfc: np.ndarray           # (nper,) local face id in per_recv
    per_mask: np.ndarray               # (ndir, nper) bool, inflow through face
    n_m: int = 0
    n_w: int = 0
    n_p: int = 0
    n: int = 0
    _tr: np.ndarray = field(default=None, repr=False)

    def __post_init__(self):
        k = self.nd * self.n_tris
        self.n_m = 3 * k
        self.n_w = self.wall_faces.size * self.nd
        self.n_p = int(self.per_mask.sum()) * self.nd if self.per_faces.size else 0
        self.n = self.n_m + self.n_w + self.n_p
        self._tr = np.zeros((self.ndir, self.per_faces.size, self.nd))

    @property
    def has_wall(self) -> bool:
        return self.n_w > 0

    @property
    def has_periodic(self) -> bool:
        return self.n_p > 0

    def pack(self, mom, flux_wall, vdf, out=None) -> np.ndarray:
        v = np.empty(self.n) if out is None else out
        k = self.nd * self.n_tris
        v[:k] = mom.ts.ravel()
        v[k:2 * k] = mom.qxs.ravel()
        v[2 * k:3 * k] = mom.qys.ravel()
        o = 3 * k
        if self.n_w:
            v[o:o + self.n_w] = flux_wall[self.wall_faces].ravel()
            o += self.n_w
        if self.n_p:
            tr = vdf[:, self.per_src, :]
            v[o:o + self.n_p] = tr[self.per_mask].ravel()
        return v

    def unpack(self, v, mom, flux_wall, vdf) -> None:
        k = self.nd * self.n_tris
        mom.ts[:] = v[:k].reshape(self.nd, self.n_tris)
        mom.qxs[:] = v[k:2 * k].reshape(self.nd, self.n_tris)
        mom.qys[:] = v[2 * k:3 * k].reshape(self.nd, self.n_tris)
        o = 3 * k
        if self.n_w:
            flux_wall[:] = 0.0
            flux_wall[self.wall_faces] = v[o:o + self.n_w].reshape(-1, self.nd)
            o += self.n_w
        if self.n_p:
            tr = self._tr
            tr[:] = 0.0
            tr[self.per_mask] = v[o:o + self.n_p].reshape(-1, self.nd)
            # a source element may serve several receiving faces; the mask
            # entries of one (direction, element) pair carry identical values
            vdf[:, self.per_src, :] = tr

    def periodic_full(self, v) -> np.ndarray:
        """``(ndir, nper, nd)`` view of the periodic part, zeros where masked out."""
        o = self.n_m + self.n_w
        tr = np.zeros((self.ndir, self.per_faces.size, self.nd))
        tr[self.per_mask] = v[o:o + self.n_p].reshape(-1, self.nd)
        return tr


def build_state_layout(ctx, mesh, bcdata) -> StateLayout:
    face_bc = ctx.face_bc
    bct = np.where(face_bc >= 0, ctx.bc_type[np.maximum(face_bc, 0)], 0)
    wall_faces = np.flatnonzero(bct == BC_NONTHERMALISING).astype(np.int64)
    per_faces = np.flatnonzero(bct == BC_PERIODIC).astype(np.int64)
    if per_faces.size:
        adj = np.array([mesh.adjacent(int(f)) for f in per_faces], dtype=np.int64)
        recv, lfc = adj[:, 0], adj[:, 1]
        src = ctx.periodic_tri[per_faces].astype(np.int64)
        speed = ctx.cxv[:, None] * ctx.nx[recv, lfc][None, :] \
            + ctx.cyv[:, None] * ctx.ny[recv, lfc][None, :]
        mask = speed < 0.0
    else:
        recv = lfc = src = np.zeros(0, dtype=np.int64)
        mask = np.zeros((ctx.cxv.size, 0), dtype=bool)
    return StateLayout(nd=ctx.mass.shape[0], n_tris=ctx.mass.shape[2],
                       ndir=ctx.cxv.size, wall_faces=wall_faces,
                       per_faces=per_faces, per_src=src, per_recv=recv,
                       per_recv_lfc=lfc, per_mask=mask)


# ---------------------------------------------------------------------------
# the coarse operator
# ---------------------------------------------------------------------------
def _bsr_from_blocks(brow, bcol, data, nblk):
    """Block-sparse matrix from ``data[k]`` at block ``(brow[k], bcol[k])``;
    coincident blocks are summed."""
    order = np.lexsort((bcol, brow))
    brow, bcol, data = brow[order], bcol[order], data[order]
    if brow.size > 1:
        new = np.ones(brow.size, dtype=bool)
        new[1:] = (brow[1:] != brow[:-1]) | (bcol[1:] != bcol[:-1])
        if not new.all():
            starts = np.flatnonzero(new)
            data = np.add.reduceat(data, starts, axis=0)
            brow, bcol = brow[starts], bcol[starts]
    indptr = np.zeros(nblk + 1, dtype=np.int64)
    np.cumsum(np.bincount(brow, minlength=nblk), out=indptr[1:])
    b = data.shape[1]
    return sp.bsr_matrix((data, bcol.astype(np.int32), indptr), shape=(nblk * b, nblk * b),
                         blocksize=(b, b))


class AngularCoarseOperator:
    """Galerkin projection of the fine DG-S_N operator onto angular P_N.

    Given a residual ``r`` of the augmented fixed-point map, :meth:`apply`
    returns ``r + R_c (W^T (L - B R) W)^{-1} W^T (B r_m + J r_p + ...)``,
    i.e. the two-level correction ``(I - K_c)^{-1} r`` where ``K_c`` is the
    coarse-angle version of the source-iteration operator.
    """

    def __init__(self, ctx, mesh, layout: StateLayout, order: int = 1,
                 periodic_prolongation: bool = True, condense: bool = False):
        self.order = order
        self.layout = layout
        self.condensed = bool(condense and order >= 2)
        nd, n_tris, ndir = layout.nd, layout.n_tris, layout.ndir
        cxv, cyv, dom = ctx.cxv, ctx.cyv, ctx.domega
        psi = angular_basis(cxv, cyv, dom, order)              # (ndir, np)
        npsi = psi.shape[1]
        self.psi, self.npsi = psi, npsi
        pw = psi * dom[:, None]
        cv, vg = ctx.cv, ctx.vg
        kappa0 = (1.0 / ctx.tau_r + 1.0 / ctx.tau_n) / (4.0 * PI)
        kappa1 = 3.0 / (4.0 * PI * ctx.tau_n * vg * vg)

        # moments of the reconstruction:  m_a = Lam[a, k] U_k,  chi = (1/cv, cx, cy)
        chi = np.stack([np.full(ndir, 1.0 / cv), cxv, cyv], axis=1)
        lam = chi.T @ pw                                       # (3, np)
        # projected scattering source:  W^T B m = Gam[j, a] m_a (times mass)
        beta = np.stack([np.full(ndir, kappa0 * cv), kappa1 * cxv, kappa1 * cyv], axis=1)
        gam = pw.T @ beta                                      # (np, 3)
        th0 = pw.T @ psi
        thx = pw.T @ (psi * cxv[:, None])
        thy = pw.T @ (psi * cyv[:, None])

        mass = ctx.mass                                        # [m, l, i]
        mass_ml = np.ascontiguousarray(np.transpose(mass, (2, 0, 1)))   # [i, m, l]
        mass_lm = np.ascontiguousarray(np.transpose(mass, (2, 1, 0)))   # [i, l, m]
        gx, gy, fcm, ttfc = ctx.gx, ctx.gy, ctx.fcm, ctx.ttfc
        nx, ny = ctx.nx, ctx.ny

        # face speeds for every direction: s[d, i, il]
        speed = cxv[:, None, None] * nx[None] + cyv[:, None, None] * ny[None]
        wp = 0.5 * (speed + np.abs(speed))
        wm = 0.5 * (speed - np.abs(speed))
        # Phi±[i, il, j, k] = sum_d dom psi_j psi_k w±
        php = np.einsum('dj,dk,dab->abjk', pw, psi, wp, optimize=True)
        phm = np.einsum('dj,dk,dab->abjk', pw, psi, wm, optimize=True)

        n = n_tris * npsi * nd
        self.n = n
        nb_ = npsi * nd                     # unknowns per element, (mode, dof) order

        def element_blocks(blk):
            """``blk[i, j, k, m, l]`` -> ``(n_i, B, B)`` with rows ``(j, m)``, cols ``(k, l)``."""
            return np.ascontiguousarray(np.transpose(blk, (0, 1, 3, 2, 4))).reshape(-1, nb_, nb_)

        # -- element blocks: streaming + collision + outflow + scattering ------
        blk = (np.einsum('jk,iml->ijkml', th0 * (1.0 / ctx.tau_c), mass_ml)
               - np.einsum('jk,iml->ijkml', thx, gx)
               - np.einsum('jk,iml->ijkml', thy, gy)
               - np.einsum('jk,iml->ijkml', gam @ lam, mass_lm))
        for il in range(3):
            blk += np.einsum('ijk,iml->ijkml', php[:, il], fcm[:, il])
        diag = element_blocks(blk)
        brow = [np.arange(n_tris)]
        bcol = [np.arange(n_tris)]
        bdat = [diag]

        # -- inflow coupling to the upwind neighbour / periodic partner --------
        face_bc = ctx.face_bc
        bct = np.where(face_bc >= 0, ctx.bc_type[np.maximum(face_bc, 0)], 0)
        for il in range(3):
            fc = ctx.tri_faces[:, il]
            t = bct[fc]
            nb = ctx.neighbour[:, il].astype(np.int64)
            per = t == BC_PERIODIC
            nb[per] = ctx.periodic_tri[fc[per]]
            sel = np.flatnonzero((nb >= 0) & ((t == 0) | per))
            if sel.size == 0:
                continue
            b2 = np.einsum('ijk,iml->ijkml', phm[sel, il], ttfc[sel, il])
            brow.append(sel)
            bcol.append(nb[sel])
            bdat.append(element_blocks(b2))

        # -- diffusely reflecting walls: emission is a linear function of F ---
        wf = layout.wall_faces
        if wf.size:
            adj = np.array([mesh.adjacent(int(f)) for f in wf], dtype=np.int64)
            wtri, wlfc = adj[:, 0], adj[:, 1]
            sw = speed[:, wtri, wlfc]                          # (ndir, nw)
            inc = np.where(sw < 0.0, -sw, 0.0)
            out = np.where(sw > 0.0, sw, 0.0)
            dwall = dom @ inc                                  # (nw,)
            zeta = np.einsum('dj,dw->wj', pw, inc)             # sum_in dom psi |s|
            eta = np.einsum('dk,dw->wk', pw, out)              # sum_out dom psi s
            coef = -np.einsum('wj,wk->wjk', zeta, eta) / dwall[:, None, None]
            b3 = np.einsum('wjk,wml->wjkml', coef, fcm[wtri, wlfc])
            np.add.at(diag, wtri, element_blocks(b3))
            self.wtri, self.wlfc, self.dwall, self.zeta, self.eta = wtri, wlfc, dwall, zeta, eta

        cond_in = cond_out = None
        if self.condensed:
            # Static condensation of the modes above P1, element by element:
            # the higher modes' equations carry no scattering source and are
            # solved locally for the element's own P1 modes and the P1 inflow
            # from its neighbours, dropping the neighbours' higher modes.
            # Leaves a P1-sized system that still carries the P2 closure of
            # the momentum modes.
            n1 = 3 * nd
            d11 = diag[:, :n1, :n1]
            d12 = diag[:, :n1, n1:]
            d21 = diag[:, n1:, :n1]
            d22 = diag[:, n1:, n1:]
            s12 = np.linalg.solve(np.transpose(d22, (0, 2, 1)),
                                  np.transpose(d12, (0, 2, 1)))          # (D12 D22^-1)^T
            s12 = np.ascontiguousarray(np.transpose(s12, (0, 2, 1)))     # (N, n1, n2)
            e21 = -np.linalg.solve(d22, d21)                              # U2 = e21 U1 (local)
            bdat[0] = d11 - s12 @ d21
            for k in range(1, len(bdat)):
                nb_blk = bdat[k]
                e_nb = e21[bcol[k]]
                bdat[k] = (nb_blk[:, :n1, :n1] + nb_blk[:, :n1, n1:] @ e_nb
                           - s12[brow[k]] @ (nb_blk[:, n1:, :n1] + nb_blk[:, n1:, n1:] @ e_nb))
            nb_ = n1
            n = n_tris * n1
            self.n = n
            # coarse-side maps between the P2 and the condensed P1 indexing
            i_p2 = (np.arange(n_tris)[:, None] * (npsi * nd) + np.arange(npsi * nd)[None, :])
            i_p1 = (np.arange(n_tris)[:, None] * n1 + np.arange(n1)[None, :])
            # rhs:  b1 - S12 b2
            rows = np.concatenate([i_p1.ravel(),
                                   np.broadcast_to(i_p1[:, :, None], s12.shape).ravel()])
            cols = np.concatenate([i_p2[:, :n1].ravel(),
                                   np.broadcast_to(i_p2[:, None, n1:], s12.shape).ravel()])
            vals = np.concatenate([np.ones(n_tris * n1), (-s12).ravel()])
            cond_in = sp.csr_matrix((vals, (rows, cols)), shape=(n, n_tris * npsi * nd))
            # solution:  U = [U1; E21 U1]
            rows = np.concatenate([i_p2[:, :n1].ravel(),
                                   np.broadcast_to(i_p2[:, n1:, None], e21.shape).ravel()])
            cols = np.concatenate([i_p1.ravel(),
                                   np.broadcast_to(i_p1[:, None, :], e21.shape).ravel()])
            vals = np.concatenate([np.ones(n_tris * n1), e21.ravel()])
            cond_out = sp.csr_matrix((vals, (rows, cols)), shape=(n_tris * npsi * nd, n))

        G = _bsr_from_blocks(np.concatenate(brow), np.concatenate(bcol),
                             np.concatenate(bdat), n_tris).tocsc()
        self.matrix = G
        self.lu = self._factorise(G)

        # -- residual -> coarse right-hand side (sparse), coarse -> state ------
        self._build_transfer(ctx, layout, mass, gam, lam, fcm, ttfc, phm, pw,
                             periodic_prolongation)
        if self.condensed:
            self.rhs_map = (cond_in @ self.rhs_map).tocsr()
            self.restrict = (self.restrict @ cond_out).tocsr()

    # ..................................................................
    @staticmethod
    def _factorise(G):
        """Sparse LU.  The symmetric-structure minimum-degree ordering with
        threshold pivoting gives a third of the fill of COLAMD here; the
        factorisation is checked on a test vector and redone with full
        partial pivoting if the threshold pivoting was not stable enough."""
        rng = np.random.default_rng(1234)
        b = rng.standard_normal(G.shape[0])
        nb = float(np.linalg.norm(b))
        attempts = (dict(permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.1,
                         options=dict(SymmetricMode=True)),
                    dict(permc_spec="COLAMD"))
        last = None
        for kw in attempts:
            try:
                lu = spla.splu(G, **kw)
            except RuntimeError as e:          # singular / structurally deficient
                last = e
                continue
            rel = float(np.linalg.norm(G @ lu.solve(b) - b)) / nb
            if rel < 1.0e-8:
                return lu
            last = RuntimeError(f"unstable coarse factorisation (relative residual {rel:.1e})")
        raise AccelerationSetupError(str(last))

    # ..................................................................
    def _build_transfer(self, ctx, layout, mass, gam, lam, fcm, ttfc, phm, pw,
                        periodic_prolongation):
        nd, n_tris, ndir, npsi = layout.nd, layout.n_tris, layout.ndir, self.npsi
        k = nd * n_tris
        n = n_tris * npsi * nd
        psi = self.psi
        # coarse unknown index of (element i, mode j, dof l)
        cidx = ((np.arange(n_tris)[:, None] * npsi + np.arange(npsi)[None, :])[:, :, None] * nd
                + np.arange(nd)[None, None, :])                          # (N, np, nd)
        # state index of moment a, dof l, element i
        midx = (np.arange(3)[:, None, None] * k + np.arange(nd)[None, :, None] * n_tris
                + np.arange(n_tris)[None, None, :])                      # (3, nd, N)

        rows, cols, vals = [], [], []
        # b[i, j, m] = sum_l mass[l, m, i] * Gam[j, a] * r_a[l, i]
        v = np.einsum('ja,lmi->ijmal', gam, mass)                        # (N, np, m, a, l)
        r = np.broadcast_to(cidx[:, :, :, None, None], v.shape)
        c = np.broadcast_to(np.transpose(midx, (2, 0, 1))[:, None, None, :, :], v.shape)
        rows.append(r.ravel()); cols.append(c.ravel()); vals.append(v.ravel())

        # restriction: dm_a[l, i] = Lam[a, k] U[i, k, l]
        rrows, rcols, rvals = [], [], []
        v = np.broadcast_to(lam[None, :, :, None], (n_tris, 3, npsi, nd))   # (N, a, k, l)
        r = np.broadcast_to(np.transpose(midx, (2, 0, 1))[:, :, None, :], v.shape)
        c = np.broadcast_to(cidx[:, None, :, :], v.shape)
        rrows.append(r.ravel()); rcols.append(c.ravel()); rvals.append(v.ravel())

        o = 3 * k
        if layout.n_w:
            wtri, wlfc = self.wtri, self.wlfc
            nw = wtri.size
            widx = o + np.arange(nw)[:, None] * nd + np.arange(nd)[None, :]     # (nw, m)
            # b[wtri, j, m] -= zeta[w, j] * r_fw[w, m]
            v = np.broadcast_to(-self.zeta[:, :, None], (nw, npsi, nd))
            r = cidx[wtri]                                                      # (nw, np, m)
            c = np.broadcast_to(widx[:, None, :], v.shape)
            rows.append(r.ravel()); cols.append(c.ravel()); vals.append(v.ravel())
            # dfw[w, m] = -(1/D) eta[w, k] fcm[w, m, l] U[wtri, k, l]
            v = -np.einsum('wk,wml->wkml', self.eta / self.dwall[:, None], fcm[wtri, wlfc])
            r = np.broadcast_to(widx[:, None, :, None], v.shape)
            c = np.broadcast_to(cidx[wtri][:, :, None, :], v.shape)
            rrows.append(r.ravel()); rcols.append(c.ravel()); rvals.append(v.ravel())
            o += layout.n_w

        if layout.n_p:
            recv, lfc, src, mask = layout.per_recv, layout.per_recv_lfc, layout.per_src, layout.per_mask
            nper = recv.size
            # state index of p[d, w, l] for masked (d, w)
            pidx = np.full((ndir, nper, nd), -1, dtype=np.int64)
            pidx[mask] = o + np.arange(int(mask.sum()) * nd).reshape(-1, nd)
            # inflow source: b[recv, j, m] += ttfc[recv, lfc, m, l] * sum_d dom psi_j |w-_d| p[d, w, l]
            dsel, wsel = np.nonzero(mask)                                  # inflow (direction, face) pairs
            wminus = -(ctx.cxv[dsel] * ctx.nx[recv[wsel], lfc[wsel]]
                       + ctx.cyv[dsel] * ctx.ny[recv[wsel], lfc[wsel]])     # (ns,) > 0
            coef = pw[dsel] * wminus[:, None]                              # (ns, np)
            v = np.einsum('sj,sml->sjml', coef, ttfc[recv[wsel], lfc[wsel]])   # (ns, np, m, l)
            r = np.broadcast_to(cidx[recv[wsel]][:, :, :, None], v.shape)
            c = np.broadcast_to(pidx[dsel, wsel][:, None, None, :], v.shape)
            rows.append(r.ravel()); cols.append(c.ravel()); vals.append(v.ravel())
            if periodic_prolongation:
                # dp[d, w, l] = psi[d, k] U[src(w), k, l]
                v = np.broadcast_to(psi[dsel][:, :, None], (dsel.size, npsi, nd))
                r = np.broadcast_to(pidx[dsel, wsel][:, None, :], v.shape)
                c = cidx[src[wsel]]                                         # (ns, np, l)
                rrows.append(r.ravel()); rcols.append(c.ravel()); rvals.append(v.ravel())

        self.rhs_map = sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                                     shape=(n, layout.n))
        self.rhs_map.sum_duplicates()
        self.restrict = sp.csr_matrix((np.concatenate(rvals), (np.concatenate(rrows), np.concatenate(rcols))),
                                      shape=(layout.n, n))
        self.restrict.sum_duplicates()

    # ..................................................................
    def apply(self, r: np.ndarray) -> np.ndarray:
        """The two-level correction ``(I - K_c)^{-1} r``."""
        u = self.lu.solve(self.rhs_map @ r)
        return r + self.restrict @ u

    def solve_residual(self, r: np.ndarray) -> np.ndarray:
        """Coarse-space correction only (for diagnostics)."""
        return self.lu.solve(self.rhs_map @ r)


# ---------------------------------------------------------------------------
# the Krylov solve
# ---------------------------------------------------------------------------
@dataclass
class KrylovResult:
    iterations: int                 # transport sweeps performed
    converged: bool
    residuals: np.ndarray           # relative preconditioned residual per GMRES step
    coarse_order: int
    periodic_prolongation: bool
    coarse_unknowns: int
    coarse_nnz: int
    state_size: int
    final_sweep: bool


def choose_coarse_order(tau_r: float, tau_n: float) -> int:
    """P1 (diffusion-like) unless normal scattering dominates, in which case
    the slow modes are the momentum modes and their damping is controlled by
    the fourth angular moments, which need P2."""
    normal_fraction = tau_r / (tau_r + tau_n)       # = tau_C / tau_N
    return 2 if normal_fraction > 0.9 else 1


def choose_periodic_prolongation(ctx, mesh, layout: StateLayout, tau_c: float,
                                 threshold: float = 2.0) -> bool:
    """Prolongate the coarse correction onto the lagged periodic traces only
    when the receiving elements are optically thick across the periodic face
    (then the inflow's fine angular structure is damped inside the element and
    its P_N reconstruction is accurate); otherwise leave those traces to the
    Krylov iteration, which follows the streaming exactly."""
    if not layout.has_periodic:
        return False
    recv = layout.per_recv
    height = 2.0 * mesh.tri_area[recv] / mesh.face_len[layout.per_faces]
    chi = float(np.median(height)) / tau_c
    return chi >= threshold


def krylov_solve(solver, tol: float, tmax: int, order: int | None = None,
                 periodic_prolongation: bool | None = None,
                 store_sweeps: int = 64, callback=None) -> KrylovResult:
    """Solve the fixed-point problem of ``solver`` by preconditioned GMRES.

    On return ``solver.vdf`` holds the converged distribution and
    ``solver.mom`` the moments computed from it, exactly as after a sweep of
    the shipped outer iteration.
    """
    from .moments import compute_moments

    ctx, mesh, bcdata = solver.ctx, solver.mesh, solver.bcdata
    case = solver.case
    mom, vdf = solver.mom, solver.vdf
    cv = case.flow.cv

    layout = build_state_layout(ctx, mesh, bcdata)
    if order is None or order <= 0:
        order = choose_coarse_order(case.flow.tau_r, case.flow.tau_n)
    if periodic_prolongation is None:
        periodic_prolongation = choose_periodic_prolongation(ctx, mesh, layout, ctx.tau_c)
    coarse = AngularCoarseOperator(ctx, mesh, layout, order, periodic_prolongation)

    bc_temp = ctx.bc_temp
    zero_temp = np.zeros_like(bc_temp)
    sweeps = 0

    def apply_map(v, with_bc):
        """``K v`` (``with_bc=False``) or ``K v + c`` (``with_bc=True``)."""
        nonlocal sweeps
        layout.unpack(v, mom, ctx.flux_wall, vdf)
        ctx.bc_temp = bc_temp if with_bc else zero_temp
        try:
            ctx.sweep(mom, vdf)
        finally:
            ctx.bc_temp = bc_temp
        sweeps += 1
        if ctx.mode == "onthefly":
            solver.factorisation_count += solver.ndir * solver.n_tris
        compute_moments(vdf, ctx.cxv, ctx.cyv, ctx.domega, solver.integrals.int_tri, cv, mom)
        if layout.has_wall:
            bcdata.update_wall_flux(vdf, ctx.cxv, ctx.cyv, ctx.domega,
                                    solver.integrals.int_tri_fc, mesh)
        return layout.pack(mom, ctx.flux_wall, vdf)

    # -- initial guess: zero, or whatever a restart put into vdf -------------
    x0 = None
    if np.any(vdf):
        compute_moments(vdf, ctx.cxv, ctx.cyv, ctx.domega, solver.integrals.int_tri, cv, mom)
        if layout.has_wall:
            bcdata.update_wall_flux(vdf, ctx.cxv, ctx.cyv, ctx.domega,
                                    solver.integrals.int_tri_fc, mesh)
        x0 = layout.pack(mom, ctx.flux_wall, vdf)

    c = apply_map(np.zeros(layout.n), True)
    vdf_c = vdf.copy()
    if x0 is not None:
        r0 = c - (x0 - apply_map(x0, False))
        vdf_x0 = vdf.copy()
    else:
        r0 = c
        vdf_x0 = None

    z0 = coarse.apply(r0)
    beta = float(np.linalg.norm(z0))
    scale = float(np.linalg.norm(coarse.apply(c))) if x0 is not None else beta
    if scale == 0.0:
        scale = 1.0

    maxit = max(0, tmax - sweeps)
    V = [z0 / beta] if beta > 0.0 else []
    H = np.zeros((maxit + 1, maxit))
    sweep_out = []          # vdf produced by K applied to each Krylov vector
    residuals = [beta / scale]
    y = np.zeros(0)
    converged = beta / scale < tol
    j = 0
    while not converged and j < maxit:
        kv = apply_map(V[j], False)
        if len(sweep_out) < store_sweeps:
            sweep_out.append(vdf.copy())
        w = coarse.apply(V[j] - kv)
        for i in range(j + 1):
            h = float(V[i] @ w)
            H[i, j] = h
            w -= h * V[i]
        hn = float(np.linalg.norm(w))
        H[j + 1, j] = hn
        e1 = np.zeros(j + 2)
        e1[0] = beta
        y, *_ = np.linalg.lstsq(H[:j + 2, :j + 1], e1, rcond=None)
        res = float(np.linalg.norm(H[:j + 2, :j + 1] @ y - e1)) / scale
        residuals.append(res)
        j += 1
        if callback is not None:
            callback(sweeps, res, solver)
        if res < tol:
            converged = True
            break
        if hn == 0.0:       # happy breakdown: exact solution in the space
            converged = True
            break
        V.append(w / hn)

    # -- assemble the solution and the consistent distribution ----------------
    x = np.zeros(layout.n) if x0 is None else x0.copy()
    for i in range(y.size):
        x += y[i] * V[i]

    final_sweep = len(sweep_out) < y.size or y.size == 0
    if not final_sweep:
        # linearity of the sweep: f(x) = f(0; bc) + sum_i y_i f(V_i; no bc)
        vdf[:] = vdf_c
        if vdf_x0 is not None:
            vdf += vdf_x0
        for i in range(y.size):
            vdf += y[i] * sweep_out[i]
        compute_moments(vdf, ctx.cxv, ctx.cyv, ctx.domega, solver.integrals.int_tri, cv, mom)
        if layout.has_wall:
            bcdata.update_wall_flux(vdf, ctx.cxv, ctx.cyv, ctx.domega,
                                    solver.integrals.int_tri_fc, mesh)
    else:
        apply_map(x, True)
    del sweep_out

    return KrylovResult(iterations=sweeps, converged=converged,
                        residuals=np.asarray(residuals), coarse_order=order,
                        periodic_prolongation=periodic_prolongation,
                        coarse_unknowns=coarse.n, coarse_nnz=int(coarse.matrix.nnz),
                        state_size=layout.n, final_sweep=final_sweep)
